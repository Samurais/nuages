/*
 * @(#)repros.h	4.6 97/04/03
 */


/************************************************************************
 *									*
 * REPROS-REconstruction from Planar cROss-Sections  V 4.1  Oct 30 1996 *
 *									*
 *  constant and type definitions for REPROS				*
 *  copyright (c) 1993 Bernhard Geiger					*
 ************************************************************************/
/************************************************************************
 *			Modification History				*
 *									*
 *  May 15 1996 flag for options -intf -inte added			*
 *									*
 ************************************************************************/


#define MAXPOINT    5000             /* max points per plane */
#define MAXPLUS      500             /* max number of added points p plane */
#define MAX_INT      500             /* max internal points p plane*/

#define MAXVERTEX (MAXPOINT+MAXPLUS+MAX_INT+4)

#define MAXTRI 2*(MAXVERTEX-3)   /* max number of triangles per plane */
#define MAXV (3*MAXVERTEX-7)     /* max number of voronoi edges per plane */
#define MAX_T12 ((2 * MAXTRI) + MAX_EXTRA)

#define MAX4 (2*MAXTRI+MAX_T12)  /* max tetrahedra between 2 planes */

#define MAX_WINKEL 0.11          /* max oeffnungswinkel 0 = 90grad,1 = 180grad*/

#define DOUBLE			/*use double precision!*/

#ifdef DOUBLE
#define REAL double
#define THR_1 (1.0E-6)  /* threshhold co_circularity */
#define THR_2 (1.0E-3)  /* threshhold to perturbe co_circular points */
#define THR_3 (1.0E-6)  /* threshhold error radius-center */
#define THR_4 (1.0E-15) /* 0 theshhold */
#define THR_5 (1.0E-9)  /* threshhold co-sphericallity */
#define THR_6 (1.0E-9)  /* threshhold intersection test*/
#else /*sigh!!!!*/
#define REAL float
#define THR_1 (5.0E-5)  /* threshhold co_circularity */
#define THR_2 (1.0E-2)  /* threshhold to perturbe co_circular points */
#define THR_3 (5.0E-5)  /* threshhold error radius-center */
#define THR_4 (1.0E-15) /* 0 theshhold */
#define THR_5 (1.0E-5)  /* threshhold co-sphericallity */
#define THR_6 (1.0E-5)  /* threshhold intersection test*/
#endif

#define EXEPTION_VAL 100000.0

#define INTER_SEUIL 0.01  /* put_internal */
#define SSIP 0.000001     /* tridep */

#define MAXHELP      50   /* range of help-array */
#define MAX_EXTRA  2000   /* nb of extra_intersections */
#define ADJMAX     2000   /* max of adjacent eliminated tetrahedra (correct())*/
#define MINSEUIL (1.0E-15)/* precision  */

#define MAX_TNODE (2 * MAX_T12)			/* maximum number of tnodes */
#define NODE_MAX  (2*MAXV+3*MAXTRI+2*MAXPOINT)	/*maximum number of nodes*/

#define MAXRECYCL 1000  /* nb of refused points */
#define MAXTDEL    300  /* nb of elim triangles by inserting a new point */
#define MAXTTG     300  /* nb of triangles tangent to a new point */
#define MAXPILE    500  /* for update2 */
#define MAXBORD    400  /* for update2 */
#define MAX_INC    500  /* Increment Bounds at overflow (realloc) */


#define POSITIVE 1
#define NEGATIVE -1
#define ZERO 0
#define OK   0
#define TNODE_OVERFLOW 1
#define NORMAL1   0
#define NORMAL2   1
#define INTERNAL1 2
#define INTERNAL2 3

#define Sign(x) \
	(((x) > 0) ? POSITIVE:(((x) == 0) ? ZERO:(NEGATIVE)))
#define Abs(x) \
	(((x) < 0) ? -(x):(x))
#define Max(a,b) \
	(((a) > (b)) ? (a):(b))
#define Min(a,b) \
	(((a) < (b)) ? (a):(b))
#define InfinityNorm(x,y,z) \
	((((x) > (y)) & ((x) > (z))) ? (x):(((y) > (z)) ? (y):(z))) 
#define Min3(x,y,z) \
	((((x) < (y)) & ((x) < (z))) ? (x):(((y) < (z)) ? (y):(z))) 

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif


#define T1	0x1
#define T2	0x2
#define T12	0x4
#define ELIM	0x8
#define MARKED	0x10

#define Elim(S,i)	((*(S->ityps))[i] & ELIM)
#define Is_t1(S,i)	((*(S->ityps))[i] & T1)
#define Is_t2(S,i)	((*(S->ityps))[i] & T2)
#define Is_t12(S,i)	((*(S->ityps))[i] & T12)
#define Marked(S,i)	((*(S->ityps))[i] & MARKED)
#define Not_Elim(S,i)	 (!Elim(S,i))
#define No_t1(S,i)	(!Is_t1(S,i))
#define No_t2(S,i)	(!Is_t2(S,i))
#define No_t12(S,i)	(!Is_t12(S,i))
#define Not_Marked(S,i)	(!Marked(S,i))

#ifdef DEBUG
#define DEBUGF(args) if (debug)  printf args 
#else
#define DEBUGF(args)
#endif
  

#define ERRCHK(a,b)  if(a == NULL) { fprintf(stderr, b); exit(1);}

#define REALLOC(tab,dim,nb,msg) \
   { char *ptr; \
     DEBUGF((msg, dim)); \
     dim = dim+nb; \
     ptr = (char *)realloc((char *)tab,dim*sizeof(int)); \
     tab = (int *)ptr; \
   } 



typedef float Coord [MAXVERTEX][2];        /* coordinates x,y */
typedef int   Order [MAXVERTEX];
typedef int   Simp  [MAXTRI][3];        /* triangles */
typedef REAL  Rayon [MAXTRI];
typedef REAL  Centre[MAXTRI][2];

typedef int   Simp4  [MAX4][4];
typedef unsigned char Ityps  [MAX4];

typedef int   Elist[MAX_EXTRA][4];

typedef
  struct tnode {
    int  s1,s2,sx;
    struct tnode *next; /*pointer to next tnode */
 } Tnode;

typedef
  struct snode {        /* to form list of triangles containing a point */
    int  simp;          /* nb of triangle containing the point */
    struct snode *next; /*pointer to next SNODE */
 } Snode;

typedef Snode  *(List[MAXVERTEX]); /* for each point one list of triangles*/
typedef Tnode  *(Intable[2*MAXTRI][3]);


typedef
   struct x_section {
     int    nb,
            nbpt,      /* # contour points */
            nb_plus,   /* # additional contour points to constrained Del_Tri */
            nb_int,    /* # points interior to contours */
            nbs;       /* # triangles */
     Coord  *point;
     Order  *succ, *pred;
     List   *simplist, *pointlist;
     Simp   *simp,*vois;
     Centre *centre;
     Rayon  *rayon;
     Snode  *list_base, *list_ptr;
     int    nb_essai;
     float  z;
   } X_section;
    
 
typedef
   struct slice {
     int nb_t1, nb_t2, nb_t12, nbs;
     Simp4  *simp, *vois;
     Ityps  *ityps;
   } Slice;
     
typedef 
  struct Flags {
    char  do_minimize,
          minimize_all,
          automatic,
          do_voronoi,
          fill_all,
          w_test,
          do_delaunay,
          do_debug,
          do_correct,
          interior,
          read_interior,
          write_interior,
          calc_interior,
          tetrahedra_out,
          do_min_vol,
          do_max_vol,
          do_stretch,
          all_tetras,
          new_format,
          internal_endchk,
          internal_framechk;
  } Flags;

typedef
   struct Object {
     int       nb_sections;
     int       nbpt;
     double    seuil[10];
     X_section *s1,*s2,*s3;
     Slice     *slice;
     Intable   *intable;
     Tnode     *it_ptr, *it_max;
     Elist     *extralist;
     int       e_ptr; 
     float     cent[3];
     float     ray;
     Flags     flag;
     char      *fnam[8];
     FILE      *fp_coord;
     FILE      *fp_coord_int;
     FILE      *fp_coord_out;
     FILE      *fp_tetra_out, *fp_tri_out;
     float     min_volume, max_volume;
     int       z_direction;
#ifdef STATISTICS
     int 	nb_w_add;
     int	nb_i_add;
     int	nb_pts_in;
     int	nb_pts_out;
     float	per_cent_add;
#endif
   } Object;


extern int Maxpoint, Maxplus, Max_int, Maxvertex, Maxtri, Maxv, Max_t12, Max4,
           Max_tnode, Maxhelp, Max_extra, Adjmax, Maxrecycl, Maxtdel, Maxttg,
           Maxpile, Maxbord, Max_increment;
extern float max_stretch;
extern int debug;

extern void alloc_local_2D(void);
extern void put_internal(Object *obj, X_section *s1, X_section *s2);
extern void tri_3d(Object *obj);
extern void elim_stretched(Object *obj);
extern void file_close(Object *obj);
extern void init_files(Object *obj);
extern void read_section(Object *obj, X_section *s, int nb);
extern void write_section(Object *obj, X_section *s);
extern void write_slice(Object *obj);
extern void write_tetrahedra(Object *obj, int all);
extern void toggle(Object *obj);
extern void free_slice(Object *obj);
extern void init_mem_X_section(X_section **sect);
extern void init_mem_Slice(Slice **Sl);
extern void init_seuil(Object *obj);
extern void tri_2d(Object *obj, X_section *s, int ind);
extern void minimize(Object *obj);
extern float volume(Object *obj);
extern int test_edge_new(int, int, Coord point, Order succ, Order pred, X_section *);
extern void realloc_x_sections(Object *, char);
extern int connected(int a, int b, List (*list));
extern int Isclockwise(int p, Coord (*point), Order (*succ), int nb);
extern void plist(X_section *);
extern void slist(X_section *);
