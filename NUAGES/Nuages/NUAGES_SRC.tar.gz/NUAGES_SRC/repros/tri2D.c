#ifndef lint
static  char *sccsid = "@(#)tri2D.c	4.8 97/04/10";
#endif

/************************************************************************
 *									*
 * REPROS-REconstruction from Planar cROss-Sections  V 4.0  Sep 29 1993 *
 *									*
 *  module tri2D.c							*
 *  copyright (c) 1993 Bernhard Geiger					*
 ************************************************************************/
/************************************************************************
 *			Modification History				*
 *									*
 * Dec  8 1996 general speedup                                          *
 * May 15 1996 inter_seuil dynamic (-mindist)				*
 * May 15 1996 additional checks when adding internal vertices		*
 * Mar 17 1995 Some fewer warnings when compiling                       *
 * Jan 25 1995 translated to ANSI C                                     *
 * Dec 29 1994 #ifndef VMS_NUAGES added					*
 * Nov 23 1994 handle deadlock in tridep()				*
 * Sep  5 1994 #include <malloc.h> added				*
 *	       read_interior simplified					*
 *									*
 ************************************************************************/

#include  <stdio.h>
#include  <stdlib.h>
#include  <math.h>
#ifndef VMS_NUAGES
#include  <memory.h>
#include  <malloc.h>
#endif
#include  "repros.h"



void alloc_local_2D(void);
void free_local_2D(void);
void trian2(Object *, X_section *, int, int *, int *);
void elim_point(Coord, Order, Order, int *, int *);
void contest_(Object *, X_section *, int *);
void winkeltest_(Object *, X_section *, int *);
int lieu2(X_section *, int, int, int *, int *, double);
void updat2(X_section *, int, int, double, double, int *);
int tridep(X_section *s, int ip, int nsdep, int *nsfin);
void boul2(Coord, int *, double *, double *, double, double, int *);
int too_close(float *, float *, float *, double);
void add_new_point(X_section *, int, int, int *);


/*GLOBALS: Various working arrays*/
int *ndet, *ntan, *voisin, *voy, *suiv1, *recycl;
int *mbord, *mbortr, *voyeur, *nisnew, *nsimp2, *nvois2; 
int *npile;
REAL *centr2, *rayon2;
char *traite, *detrui;

#ifndef VMS_NUAGES
  extern double drand48(void);
#else
  double drand48(void)
  {
    return ( (double)rand()/(double)2147483647);
  }
#endif



void cadr2(Object *obj, X_section *s, short int iturn)
/*    initialise la triangulation en construisant un cadre carre
c     sense contenir les pts a mesurer de cote 4*raysc
c     les pts du cadre sont ranges a partir de nbtop+1
c     si iturn = 1 on tourne le cadre de 45 degrees
*/
{
 float xmi,xma,ymi,yma;
    

 if(! (iturn) ) {
   xmi = obj->cent[0]-2 * obj->ray;
   xma = obj->cent[0]+2 * obj->ray;
   ymi = obj->cent[1]-2 * obj->ray;
   yma = obj->cent[1]+2 * obj->ray;
   (*(s->point))[Maxvertex-4][0] = xmi;
   (*(s->point))[Maxvertex-3][1] = ymi;
   (*(s->point))[Maxvertex-2][0] = xma;
   (*(s->point))[Maxvertex-1][1] = yma;
 }
 else {
   xmi = obj->cent[0]-2* obj->ray*1.41;
   xma = obj->cent[0]+2* obj->ray*1.41;
   ymi = obj->cent[1]-2* obj->ray*1.41;
   yma = obj->cent[1]+2* obj->ray*1.41;
   (*(s->point))[Maxvertex-4][0] = obj->cent[0];
   (*(s->point))[Maxvertex-3][1] = obj->cent[1];
   (*(s->point))[Maxvertex-2][0] = obj->cent[0];
   (*(s->point))[Maxvertex-1][1] = obj->cent[1];
 }
 (*(s->point))[Maxvertex-4][1] = ymi;
 (*(s->point))[Maxvertex-3][0] = xma;
 (*(s->point))[Maxvertex-2][1] = yma;
 (*(s->point))[Maxvertex-1][0] = xmi;

 
 (*(s->simp))[0][0] = Maxvertex-3;
 (*(s->simp))[0][1] = Maxvertex-2;
 (*(s->simp))[0][2] = Maxvertex-1;
 (*(s->simp))[1][0] = Maxvertex-3;
 (*(s->simp))[1][1] = Maxvertex-1;
 (*(s->simp))[1][2] = Maxvertex;
 (*(s->vois))[0][0] = 0;
 (*(s->vois))[0][1] = 2;
 (*(s->vois))[0][2] = 0;
 (*(s->vois))[1][0] = 0;
 (*(s->vois))[1][1] = 0;
 (*(s->vois))[1][2] = 1;
 (*(s->centre))[0][0] = obj->cent[0];
 (*(s->centre))[0][1] = obj->cent[1];
 (*(s->centre))[1][0] = (*(s->centre))[0][0];
 (*(s->centre))[1][1] = (*(s->centre))[0][1];
 (*(s->rayon))[0] = ((xma-xmi)*(xma-xmi)+(yma-ymi)*(yma-ymi))*0.25;
 (*(s->rayon))[1] = (*(s->rayon))[0];
 s->nbs = 2;
}


/*
c     makes the frame ( cadre2 ) and calls trian2 which computes 
c     the 2D Delaunay-Triangulation
c     Computes the list of adjacent points (plist) and inserts points if a
c     contour-segment is not contained in the triangulation (contest).
c     If there are eliminated points pred and succ are updated (elim)
*/

void tri_2d(Object *obj, X_section *s, int ind)
{
  int iturn;
  int ier;

  int i;
  int nbelim, nbelim2;

  if (ind == NORMAL1 || ind == INTERNAL1) {
    alloc_local_2D();
  }

  iturn = !(s->nb & 1);

  if (ind == NORMAL1 || ind == NORMAL2) {
    cadr2(obj,s,iturn);
    s->nb_essai = 0;
  }

  nbelim = 0;

  if (ind == NORMAL1 || ind == NORMAL2) {
    for (i= 1 ; i < s->nbpt+1 ; i++) {
      trian2(obj,s, i, &nbelim, &ier);
    }
    /* c     recyclage des points elimines au 1er passage */
    if(nbelim > 0) {
      nbelim2 = nbelim;
      nbelim = 0;
      for (i=0 ; i < nbelim2 ; i++) 
        trian2(obj,s, recycl[i], &nbelim, &ier);
    }
    if(nbelim > 0) {
      elim_point(*(s->point), *(s->succ), *(s->pred), &nbelim, recycl);
    }
    if (s->nb_essai > 0 ) DEBUGF(("   nb perturb: %d\n",s->nb_essai));
    if (nbelim != 0) printf("   nbelim = %d\n", nbelim);

    /* do not insert twice! we call that with option I1/I2
    if(obj->flag.read_interior) {
      nbelim = 0;
      for (i = Maxpoint+Maxplus+1 ; i < Maxpoint+Maxplus+s->nb_int+1; i++)
        trian2(obj, s, i, &nbelim, &ier);
    }
    */
  }
  else { /*ADD internal points*/
    nbelim = 0;
      for (i = Maxpoint+Maxplus+1 ; i < Maxpoint+Maxplus+s->nb_int+1; i++)
        trian2(obj, s, i, &nbelim, &ier);
  }
  plist(s);

  contest_(obj, s, &ier);
  if (obj->flag.w_test) {
    winkeltest_(obj, s, &ier);
    contest_(obj, s, &ier);
  }
  if (ind == INTERNAL1 || ind == INTERNAL2) {
    free_local_2D();
#ifdef STATISTICS
    obj->nb_pts_in = obj->nb_pts_in + s->nbpt;
    obj->nb_w_add  = obj->nb_w_add  + s->nb_plus;
    obj->nb_i_add  = obj->nb_i_add  + s->nb_int;
#endif
  }
  slist(s);
}


/*
c actualise la triangulation de delaunay en dimension 2
c apres introduction du point i
c messages d'erreur sur u.l. 55
c les coordonnees du pt i peuvent etre modifiees de seuil2
c plus le simplexe numero nsdep a son centre voisin du point i,
c plus la routine sera rapide; si on ne connait pas de simplexe voisin
c de i prendre nsdep pres du c.d.g.
c nbs nb de simplexes nsimp; nvois leurs relations de voisinages
c leurs centre et rayon
c doit etre initialise avec au moins 3 points dont l'enveloppe
c convexe contient le nouveau point
c seuil1=seuil pour la tangence (cf. lieu2)
c seuil2=distance max. dont on peut bouger le pt i pour eliminer les cas
c tangents (i.e. plus de 3 pts cocycliques)
c seuil3=erreur max toleree pour le calcul des centres et rayons
c des simplexes (cf. boul2); en principe seuil3=seuil1
c seuil4=seuil sur l'aplatissement du simplexe (cf. boul2)
c si le point ne peut etre insere nbelim=nbelim+1 et le point est range
c dans recycl pour un recyclage ulterieur eventuel
c traite est un tableau de travail de booleens qui doit etre initialise
c avant le premier appel a triang
c a .false. de dimension >= nbs; il est remis a .false. en sortie
c idem detrui
c suiv, voisin, voy tab. d'entiers de dim >=nb de pts de point
c ierr=1 si debordement de tab.
*/

void trian2(Object *obj, X_section *s, int i, int *nbelim, int *ierr)
{
  float  spoint[2];
  int ier, iessai, nbdet,nbtan;
  register int  j, end;



  *ierr = 0;
  iessai = 0;
  spoint[0] = (*(s->point))[i-1][0];
  spoint[1] = (*(s->point))[i-1][1];
  end = FALSE;

  while(!end) {
    switch( lieu2(s,i,s->nbs,&nbdet,&nbtan, obj->seuil[0])){
      case  0:  /*all right*/
                end = TRUE; break;
      case -1:  /*vertex incident*/
                if(*nbelim == Maxrecycl) {
                  REALLOC(recycl,Maxrecycl,100,"   Maxrecycl overflow at %d. realloc\n");
                  ERRCHK(recycl, "trian2: no mem space\n");
                }
                recycl[(*nbelim)++] = i;
                s->nb_essai = s->nb_essai + iessai;
                return;
      case  1:  /*vertex tangent*/
                for( j=0 ; j<nbdet ; j++)
                  detrui[ndet[j]-1] = 0;
      case  2:  /*no triangle to start*/
                if( iessai > 20 ) {
                  if(nbtan == 0)
                    DEBUGF(("   no triangle to start, pt %d deleted\n",i));
                  else
                    DEBUGF(("point co_cyclic  pt %d deleted\n",i));
                  if(*nbelim == Maxrecycl) {
                    REALLOC(recycl,Maxrecycl,100,"   Maxrecycl overflow at %d. realloc\n");
                    ERRCHK(recycl, "trian2: no mem space\n");
                  }
                  recycl[(*nbelim)++] = i;
                  s->nb_essai = s->nb_essai + iessai;
                  return;
                }
                iessai++;
                (*(s->point))[i-1][0] = 
                                    spoint[0]+(drand48()-0.5)*2.0*obj->seuil[1];
                (*(s->point))[i-1][1] =
                                    spoint[1]+(drand48()-0.5)*2.0*obj->seuil[1];
                break;
    }
  }
  s->nb_essai = s->nb_essai + iessai;

  updat2(s, i, nbdet, obj->seuil[2], obj->seuil[3], &ier);

  if(ier == 1) {
    DEBUGF(("   err calc radius  pt %d deleted\n",i));
    if(*nbelim == Maxrecycl) {
      REALLOC(recycl,Maxrecycl,100,"   Maxrecycl overflow at %d. realloc\n");
      ERRCHK(recycl, "trian2: no mem space\n");
    }
    recycl[(*nbelim)++] = i;
    return;
  }
}


int lieu2(X_section *s, int ip, int nsdep, int *nbdet, int *nbtan, double seuil1)
/*
   Looks for triangles that have to be deleted when vertex ip
   is inserted.
   return_code: 
     0  ok
    -1  vertex incident 
     1  vertex tangent to nbtan triangles
     2  found no triangles to delete
   A vertex is tangent to a triangle if
   distance(pt-centre)**2-rayon(s)**2 < seuil1
   nsdep is the  triangle where we start to search, so we should take
   it as near as possible to vertex ip.
*/
{

  int nsc,nvc,itopil,nbspil;
  register int i;
  double dist,derr,dpt;

  *nbdet=0;
  *nbtan=0;
  dist=0.0;

  /* recherche du simplexe de depart=simplexe contenant ip*/

  if( tridep(s,ip,nsdep,&nsc) == 0 ) {
    *nbdet = -1;
    return(-1);  /*pt confondu */
  }

  dpt = (double)((*(s->point))[ip-1][0])-(double)((*(s->centre))[nsc-1][0]);
  dist = dist+dpt*dpt;
  dpt = (double)((*(s->point))[ip-1][1])-(double)((*(s->centre))[nsc-1][1]);
  dist = dist+dpt*dpt;

  derr = (dist-(double)((*(s->rayon))[nsc-1]))/(double)((*(s->rayon))[nsc-1]);
  if(derr >= -(seuil1)) {
    return(2);     /*pas de simplex pour demarrer*/
  }

  itopil = 0;
  nbspil = 0;
  *(npile + itopil) = nsc;
  traite[nsc-1] = 1;
  *(ndet + (*nbdet)++) = nsc;
  detrui[nsc-1] = 1;
  for( i=0 ; i<3 ; i++) {
    nvc = (*(s->vois))[nsc-1][i];
    if (nvc < 1) continue;
    if (traite[nvc-1]) continue;
    traite[nvc-1] = 1;
    nbspil++;
    if (nbspil >= Maxpile){
      REALLOC(npile, Maxpile, 100, "   Maxpile overflow at %d. realloc\n");
      ERRCHK(npile, "lieu2: no memory space\n");
    }
    *(npile + nbspil) =  nvc;
  }
  itopil++;
  while(nbspil >= itopil) {
    nsc = *(npile + itopil);
    if ((*(s->simp))[nsc-1][0] > 0) {
      dist=0.0;
      dpt = (double)((*(s->point))[ip-1][0])-(double)((*(s->centre))[nsc-1][0]);
      dist = dist+dpt*dpt;
      dpt = (double)((*(s->point))[ip-1][1])-(double)((*(s->centre))[nsc-1][1]);
      dist = dist+dpt*dpt;
      derr = (dist-(double)((*(s->rayon))[nsc-1]))/(double)((*(s->rayon))[nsc-1]);
      if(fabs(derr) <= seuil1) {
        if(*nbtan >= Maxttg){
          REALLOC(ntan,Maxttg,100, "   Maxttg overflow at %d. realloc\n");
          ERRCHK(ntan, "lieu2: no mem space\n");
        }
        *(ntan + (*nbtan)++) = nsc;
      }
      else {
        if(derr <= seuil1) {
          if(*nbdet >= Maxtdel){
            REALLOC(ndet,Maxtdel,100,"   Maxtdel overflow at %d. realloc\n");
            ERRCHK(ndet, "lieu2: no mem space\n");
          }
          *(ndet + (*nbdet)++) = nsc;
          detrui[nsc-1] = 1;
          for( i=0 ; i<3 ; i++) {
            nvc = (*(s->vois))[nsc-1][i];
            if (nvc < 1) continue;
            if (traite[nvc-1]) continue;
            traite[nvc-1] = 1;
            nbspil++;
            if (nbspil >= Maxpile) {
              REALLOC(npile,Maxpile,100,"   Maxpile overflow at %d. realloc\n");
              ERRCHK(npile, "lieu2: no memory space\n");
            }
            *(npile + nbspil) =  nvc;
          }
        }
      }
    }
    itopil++;
  }
  for( i=0 ; i<=nbspil ; i++) {
    traite[*(npile + i) - 1] = 0;
  }
  return( *nbtan != 0 );
}

/*
c special dimension 2
c met a jour nsimp et nvois apres l'arrivee du point ipnew
c ainsi que centre et rayon
c ndet et ntan sont les num. des simplexes a detruire et tangents
c (cf. lieu2)
c si le nb de nouveaux simplexes <= nbdet on range les nouveauxx a la
c place des simplexes detruits; si < on met a -1 le 1er sommet des
c simplexes detruits non remplaces; si > on met le complement a la
c fin de nsimp et on incremente nbs
c seuil=precision voulue sur le calcul des centres et rayons (cf. boul2)
c si cette precision n'est pas obtenue ier=1
c seuil4=min d'aplatissement tolere des simplexes (cf. boul2)
c si seuil4 non respecte ier=1
c ier=1 si erreur ds calcul de la boul2
c ier=2 si tab. sous dimensionne
c suiv, voisin, voy tab.d'entiers de dim. >=nb de pts de point
c
*/

void updat2(X_section *s, int ipnew, int nbdet, double seuil3, double seuil4, int *ier)
{

  int nbsnew, nbs0, nsc, nvc;
  register int i, j, l, jp1, jm1, is, nvoy, ip1, im1;

  *ier = 0;
  nbsnew = 0;
  nbs0 = s->nbs;

/*  recherche des triangles non detruits voisins et chainage des points
     mbord du bord de la zone detruite */

  for (i=0 ; i<nbdet ; i++) {
    nsc = ndet[i];
    for (j=0,jp1=1,jm1=2 ; j<3 ; j++,jp1=(jp1==2)?0:jp1+1,jm1=(jm1==2)?0:jm1+1) {
      nvc = (*(s->vois))[nsc-1][j];
      if ( nvc == 0  || !detrui[nvc-1] ) {  /*1*/
        nbsnew++;
        if (nbsnew > Maxbord) {
          char *ptr;
          DEBUGF(("   Maxbord overflow at %d. realloc\n", Maxbord));
          Maxbord = Maxbord + 100;
          ptr = (char *)realloc((char *)mbord, (Maxbord+2)*sizeof(int));
          ERRCHK(ptr, "mbord: no mem space\n");
          mbord = (int *)ptr;
          ptr = (char *)realloc((char *)mbortr, (Maxbord+2)*sizeof(int));
          ERRCHK(ptr, "mbortr: no mem space\n");
          mbortr = (int *)ptr;
          ptr = (char *)realloc((char *)nisnew, Maxbord*sizeof(int));
          ERRCHK(ptr, "nisnew: no mem space\n");
          nisnew = (int *)ptr;
          ptr = (char *)realloc((char *)voyeur, Maxbord*sizeof(int));
          ERRCHK(ptr, "voyeur: no mem space\n");
          voyeur = (int *)ptr;
          ptr = (char *)realloc((char *)nsimp2, Maxbord*3*sizeof(int));
          ERRCHK(ptr, "nsimp2: no mem space\n");
          nsimp2 = (int *)ptr;
          ptr = (char *)realloc((char *)nvois2, Maxbord*3*sizeof(int));
          ERRCHK(ptr, "nvois2: no mem space\n");
          nvois2 = (int *)ptr;
          ptr = (char *)realloc((char *)centr2, Maxbord*2*sizeof(REAL));
          ERRCHK(ptr, "centr2: no mem space\n");
          centr2 = (REAL *)ptr;
          ptr = (char *)realloc((char *)rayon2, Maxbord*sizeof(REAL));
          ERRCHK(ptr, "rayon2: no mem space\n");
          rayon2 = (REAL *)ptr;
        }
        *(mbord + nbsnew - 1)=(*(s->simp))[nsc-1][jp1];
        suiv1[*(mbord+nbsnew-1)-1] = (*(s->simp))[nsc-1][jm1];
        voisin[*(mbord+nbsnew-1)-1] = nvc;
        if (nvc > 0) {
          l = -1;
          do {
            l++;
            if (l > 2) {
              printf("   updat2: error\n");
              return;
            }
          } while ( (*(s->vois))[nvc-1][l]  != nsc );
          voy[*(mbord+nbsnew-1)-1] = l;
        }
        else voy[*(mbord+nbsnew-1)-1] = 0; 
        if( nbsnew > nbdet ) {
          s->nbs++;
          *(nisnew+nbsnew-1) = s->nbs;
        }
        else *(nisnew+nbsnew-1) = ndet[nbsnew-1];
      }
    }
  }

  /*tri des points du bord */


  *mbortr = *mbord;
  *nvois2 = voisin[*(mbortr)-1];
  *voyeur = voy[*(mbortr)-1];
  for (i=1; i < nbsnew ; i++) {
    *(mbortr+i) = suiv1[*(mbortr+i-1)-1];
    *(nvois2+i*3+0) = voisin[*(mbortr+i)-1];
    *(voyeur+i)=voy[*(mbortr+i)-1];
  }

  /* creation des nouveaux triangles */

  for (i=0; i < nbsnew ; i++) {
    ip1 = i+1;
    if (ip1 >= nbsnew ) ip1 = 0;
    im1 = i-1;
    if (im1 < 0  ) im1 = nbsnew-1;
    *(nsimp2+i*3+0) = ipnew; 
    *(nsimp2+i*3+1) = *(mbortr+i); 
    *(nsimp2+i*3+2) = *(mbortr+ip1); 
    *(nvois2+i*3+1) = *(nisnew+ip1); 
    *(nvois2+i*3+2) = *(nisnew+im1); 
  }
  /* calcul du centre et du rayon et test de non degenerescence*/

  for (i=0; i < nbsnew ; i++) {
    boul2(*(s->point),(nsimp2+i*3),(centr2+i*2),
                   (rayon2+i),seuil3,seuil4,ier);
    if (*ier == 1) {
      s->nbs = nbs0;
      for (i=0 ; i< nbdet ;  i++) detrui[ndet[i]-1] = 0;
      return;
    }
  }

  /* rangement*/

  for (i=0; i < nbsnew ; i++) {
    is = *(nisnew+i)-1;
    (*(s->rayon))[is] = *(rayon2+i);
    (*(s->centre))[is][0] = *(centr2+i*2+0);
    (*(s->centre))[is][1] = *(centr2+i*2+1);
    for (j=0; j < 3 ; j++) {
      (*(s->vois))[is][j] = *(nvois2+i*3+j);
      (*(s->simp))[is][j] = *(nsimp2+i*3+j);
    }
    nvoy = *(nvois2+i*3+0);
    if (nvoy > 0) (*(s->vois))[nvoy-1][*(voyeur+i)] = is + 1;
  }
  for (i=0 ; i< nbdet ;  i++) detrui[ndet[i]-1] = 0;
}



void boul2(Coord point, int *isom, double *centre, double *rayon, double seuil3, double seuil4, int *ier)

/*
calcul par les formules
calcule le centre et le rayon du cercle circonscrit au triangle nsc
seuil=erreur toleree sur le calcul = max des ecarts entre les
seuil4=seuil d'aplatissement du simplexe
doit etre >0 sinon division par 0 possible
si ces seuils ne sont pas respectes ier=1
distances(centre-sommets)**2 =err
*/
{
  double r[3],err;

  int    ia,ib,ic;

  double p0[2],p1[2],p2[2];
  double p1p0[2],p2p0[2],p2p1[2];
  double div;
  double c1,c2;


  *ier=0;
  ia=isom[0]-1;
  ib=isom[1]-1;
  ic=isom[2]-1;

  p0[0] = point[ia][0];
  p0[1] = point[ia][1];
  p1[0] = point[ib][0];
  p1[1] = point[ib][1];
  p2[0] = point[ic][0];
  p2[1] = point[ic][1];
  p1p0[0] = p0[0]-p1[0];
  p1p0[1] = p0[1]-p1[1];
  p2p0[0] = p0[0]-p2[0];
  p2p0[1] = p0[1]-p2[1];
  p2p1[0] = p1[0]-p2[0];
  p2p1[1] = p1[1]-p2[1];
  if( p1p0[0] == 0 && p1p0[1] == 0 ) {
    DEBUGF(("   points %d %d confondu\n",ia+1,ib+1));
    *ier = 1; return;
  } 
  if( p2p0[0] == 0 && p2p0[1] == 0 ) {
    DEBUGF(("   points %d %d confondu\n",ia+1,ic+1));
    *ier = 1; return;
  } 
  if( p2p1[0] == 0 && p2p1[1] == 0 ) {
    DEBUGF(("   points %d %d confondu\n",ib+1,ic+1));
    *ier = 1; return;
  } 
  div = p2p0[0]*p1p0[1] - p1p0[0]*p2p0[1];
  if( fabs(div) < seuil4 ) {
    DEBUGF(("   points %d %d %d  co_linear\n",ia+1, ib+1,ic+1));
    *ier = 1; return;
  } 
    
  c1 = p1p0[0]*(p0[0]+p1[0]) + p1p0[1]*(p0[1]+p1[1]);
  c2 = p2p0[0]*(p0[0]+p2[0]) + p2p0[1]*(p0[1]+p2[1]);
 
  centre[0] = 0.5*( p1p0[1]*c2 - p2p0[1]*c1 ) / div;
  centre[1] = 0.5*( p2p0[0]*c1 - p1p0[0]*c2 ) / div;
 
  r[0]=(centre[0]-p0[0])*(centre[0]-p0[0]) +(centre[1]-p0[1])*(centre[1]-p0[1]);
  r[1]=(centre[0]-p1[0])*(centre[0]-p1[0]) +(centre[1]-p1[1])*(centre[1]-p1[1]);
  r[2]=(centre[0]-p2[0])*(centre[0]-p2[0]) +(centre[1]-p2[1])*(centre[1]-p2[1]);

  *rayon=(r[0]+r[1]+r[2])/3.0;
    err=InfinityNorm(fabs(r[0]-r[1]),fabs(r[1]-r[2]),fabs(r[2]-r[0])) / *rayon;

  if(err > seuil3) {
    DEBUGF(("   err %e radius %e %e %e pts %d %d %d\n",err,r[0],r[1],r[2],
                 ia+1,ib+1,ic+1));
    *ier = 1;
    return;
  }
}

int tridep(X_section *s, int ip, int nsdep, int *nsfin)

/*c   recherche le triangle contenant le point ip en partant de nsdep
      resultat=nsfin*/
{
  int i1,i2,i3, j, jp1, jp2;
  double x2p, y2p, x3p, y3p,x23, y23;
  float sip;
  int h, rapell, deja_vu = -100;

  *nsfin = nsdep;

/*
c calcul de l'orientation de nsfin; ce calcul peut etre reporte au
c moment de la creation du simplexe (cf. updat2)
*/

DEBUT:

  i1 = (*(s->simp))[*nsfin-1][2]-1;
  i2 = (*(s->simp))[*nsfin-1][0]-1;
  i3 = (*(s->simp))[*nsfin-1][1]-1;

/*
c recherche du voisin de nsfin a prendre pour continuer:
c celui qui est ds le demi plan s'appuyant sur un cote de nsfin
c et contenant ip
*/
      x3p = (*(s->point))[i2][0]-(*(s->point))[ip-1][0];
      y3p = (*(s->point))[i2][1]-(*(s->point))[ip-1][1];
 
      for( j=0,jp1=1 ; j<3 ; j++,jp1=(jp1==2)?0:jp1+1) {
        x2p = x3p;
        y2p = y3p;
        x3p = (*(s->point))[i3][0]-(*(s->point))[ip-1][0];
        y3p = (*(s->point))[i3][1]-(*(s->point))[ip-1][1];
        x23 = (*(s->point))[i3][0]-(*(s->point))[i2][0];
        y23 = (*(s->point))[i3][1]-(*(s->point))[i2][1];
  
        if(x2p == 0 && y2p == 0) {
          DEBUGF(("   points %d %d confondus\n",i2+1,ip));
          return(0);
        }
        if(x3p == 0 && y3p == 0) {
          DEBUGF(("   points %d %d confondus\n",i3+1,ip));
          return(0);
        }
        sip = x23*y2p-x2p*y23;
        if(fabs(sip) < SSIP ) {
          if( (x23 > 0 && ((*(s->point))[i2][0] < (*(s->point))[ip-1][0]
                        && (*(s->point))[ip-1][0] < (*(s->point))[i3][0]) )
           || (x23 < 0 && ((*(s->point))[i2][0] > (*(s->point))[ip-1][0]
                        && (*(s->point))[ip-1][0] > (*(s->point))[i3][0]) )
           || (y23 > 0 && ((*(s->point))[i2][1] < (*(s->point))[ip-1][1]
                        && (*(s->point))[ip-1][1] < (*(s->point))[i3][1]) )
           || (y23 < 0 && ((*(s->point))[i2][1] > (*(s->point))[ip-1][1]
                        && (*(s->point))[ip-1][1] > (*(s->point))[i3][1]) ) ) {
            /*printf("on segment\n");*/
            return(1);
          }
      }
      if(sip > SSIP) {
        jp2 = jp1+1;
        if (jp2 == 3) jp2 = 0;
         rapell = *nsfin;
         *nsfin = (*(s->vois))[*nsfin-1][jp2];
         if (*nsfin == deja_vu) {
           DEBUGF(("   dead lock\n"));
           return(0);
         }
         else {
           deja_vu = rapell;
         }
         goto DEBUT;
      }
      h = i2; i2 = i3; i3 = i1; i1 = h;
    }
 return(1);
}





void slist(X_section *s)
{
  int i,j;
  Snode *pn;
  

  for (i=0 ; i< s->nbpt ; i++)
    (*(s->simplist))[i] = NULL;
  for (i=Maxpoint ; i< Maxpoint + s->nb_plus ; i++)
    (*(s->simplist))[i] = NULL;
  for (i=Maxpoint+Maxplus ; i< Maxpoint+Maxplus + s->nb_int ; i++)
    (*(s->simplist))[i] = NULL;
  for (i=Maxvertex-4 ; i< Maxvertex ; i++)
    (*(s->simplist))[i] = NULL;

  for (i=0 ; i< s->nbs ; i++)  {
    for (j=0; j<3 ; j++) {
      pn = (s->list_ptr)++;
      /* if !!!!*/
      pn->simp = i+1;
      pn->next = (*(s->simplist))[(*(s->simp))[i][j]-1];
      (*(s->simplist))[(*(s->simp))[i][j]-1] = pn;
    }
  }
}

void plist(X_section *s)
{
  int i,j,j1,j2;
  Snode *pn;
  static char *mark;

  if (s->nbs == 0) return;

  mark = (char *)malloc(s->nbs*sizeof(char));
  ERRCHK(mark, "plist: no mem space");
  
  s->list_ptr = s->list_base;

  memset(mark, 1, s->nbs);

/*
  for (i=0 ; i<s->nbs ; ++i)
    mark[i] = 1;
*/

  for (i=0 ; i< s->nbpt ; i++)
    (*(s->pointlist))[i] = NULL;
  for (i=Maxpoint ; i< Maxpoint + s->nb_plus ; i++)
    (*(s->pointlist))[i] = NULL;
  for (i=Maxpoint+Maxplus ; i< Maxpoint+Maxplus + s->nb_int ; i++)
    (*(s->pointlist))[i] = NULL;
  for (i=Maxvertex-4 ; i< Maxvertex ; i++)
    (*(s->pointlist))[i] = NULL;

  for (i=0 ; i< s->nbs ; i++)  {
    for (j=0,j1=1,j2=2; j<3 ; j++,j1=(j1==2)?0:j1+1,j2=(j2==2)?0:j2+1) {
      if ((*(s->vois))[i][j] == 0 || mark[(*(s->vois))[i][j]-1]) {
        pn = (s->list_ptr)++;
        /* if !!!!*/
        pn->simp = (*(s->simp))[i][j1];
        pn->next = (*(s->pointlist))[(*(s->simp))[i][j2]-1];
        (*(s->pointlist))[(*(s->simp))[i][j2]-1] = pn;
        pn = (s->list_ptr)++;
        /* if !!!!*/
        pn->simp = (*(s->simp))[i][j2];
        pn->next = (*(s->pointlist))[(*(s->simp))[i][j1]-1] ;
        (*(s->pointlist))[(*(s->simp))[i][j1]-1] = pn;
      }
    }
    mark[i] = 0;
  }
  free(mark);
}



void contest_(Object *obj, X_section *s, int *ier)
{
  int i,k;
  int nbelim;
  int z2;
  int newvertex;
  int maximum;
  float px,py;


  z2 = Maxpoint + s->nb_plus;
  newvertex = 0;           /* no new vertices added */
  nbelim = 0;              /* no points eliminated */

  if(s->nbpt == 0) return; /* do nothing if no vertices */
     /* for all vertices of the plane */
  for ( i=0 ; i<Maxpoint+s->nb_plus ; i=(i==s->nbpt-1)?i=Maxpoint:i+1) {
     /* if edge i / succ[i] not contained and i is not an elim. point */
    if (!(connected(i+1,(*(s->succ))[i],s->pointlist)) )
    if ( (*(s->point))[i][1] < EXEPTION_VAL ) {      /* not eliminated */
      DEBUGF(("     edge %d,%d not in tri ",
                                                 i+1,(*(s->succ))[i]));
      if(z2 >= Maxpoint + Maxplus) {
        realloc_x_sections(obj, 'p');
        free_local_2D();
        alloc_local_2D();
      }
      /* add new point in the middle */
      (*(s->point))[z2][0] = ((*(s->point))[(*(s->succ))[i]-1][0] + 
                                              (*(s->point))[i][0])/2.0;
      (*(s->point))[z2][1] = ((*(s->point))[(*(s->succ))[i]-1][1] + 
                                              (*(s->point))[i][1])/2.0;
      (*(s->succ))[z2] = (*(s->succ))[i];
      (*(s->pred))[(*(s->succ))[i]-1] = z2+1;
      (*(s->pred))[z2] = i+1;
      (*(s->succ))[i] = z2+1;
      DEBUGF(("  new pt: %10.3f%10.3f%10.3f # %d\n",
                  (*(s->point))[z2][0], (*(s->point))[z2][1], s->z,z2+1));
      ++(z2);
      newvertex = 1;       /* new vertex added */
    }
  }

 if (newvertex) {   /* forget old pointlist */
   for (k=Maxpoint+s->nb_plus ; k< z2 ; ++k) {
     /* insert new vertices */
     px = (*(s->point))[k][0];
     py = (*(s->point))[k][1];
     maximum = 20;
     do {
       nbelim = 0;
       trian2(obj,s, k+1, &nbelim, ier);
       if(nbelim>0) { /* move the vertex along the edge that is not contained */
         (*(s->point))[k][0] = (*(s->point))[k][0]+
             ((*(s->point))[(*(s->succ))[k]-1][0]-(*(s->point))[k][0])/10.0;
         (*(s->point))[k][1] = (*(s->point))[k][1]+
             ((*(s->point))[(*(s->succ))[k]-1][1]-(*(s->point))[k][1])/10.0;
       }
     } while((nbelim > 0) && (--maximum > 0));

     maximum = 20;
     if (nbelim >0) {
       (*(s->point))[k][0] = px;
       (*(s->point))[k][1] = py;
       do {
         nbelim = 0;
         trian2(obj,s, k+1, &nbelim, ier);
         if(nbelim>0) {/* move the vertex aint the edge that is not contained */
           (*(s->point))[k][0] = (*(s->point))[k][0]+
             ((*(s->point))[(*(s->pred))[k]-1][0]-(*(s->point))[k][0])/10.0;
           (*(s->point))[k][1] = (*(s->point))[k][1]+
             ((*(s->point))[(*(s->pred))[k]-1][1]-(*(s->point))[k][1])/10.0;
         }
       } while((nbelim > 0) && (--maximum > 0));
       if (nbelim >0) {
         i = (*(s->pred))[k];
         z2 = (*(s->succ))[k];
         while(i > Maxpoint )  i = (*(s->pred))[i-1];
         while(z2 > Maxpoint )  z2 = (*(s->succ))[z2-1];
         fprintf(stderr,"   error: cannot triangulate line segment %d %d \n",i,z2);
         exit(1);
       }  
     }
   }

  /* update list of adjacent points */
  s->nb_plus = z2 - Maxpoint;

  plist( s );

  /* test, if new contour is contained in triangulation */

  contest_(obj, s, ier);
  }
  else {
    DEBUGF(("   contour o.k. \n"));
  }
}      /* contest */



int connected(int a, int b, List (*list))
{
  Snode *pn;
  pn = (*list)[a-1];             /* begin at adjacent points of a */
  while ( (pn != NULL) ) {  /* while adj. points and not found */
    if (pn->simp == b) return(1);/* if b = adjacent point of a */
    pn = pn->next;                /* else next point */
  }
  return(0);
}
 





void winkeltest_(Object *obj, X_section *s, int *ier)
{
  int i,k;
  int b = 0;
  int z2;
  int nbelim;
  int newvertex;
  int maximum;
  float px,py;
  Snode *pn;
  float norm, v1[2], v2[2];
  float scal, cos2, smin;
  int p, pmin;


  z2 = Maxpoint + s->nb_plus;
  newvertex = 0;           /* no new vertices added */
  nbelim = 0;              /* no points eliminated */

  if(s->nbpt == 0) return; /* do nothing if no vertices */
  /* for all vertices of the plane */
  for ( i=0 ; i<Maxpoint+s->nb_plus ; i=(i==s->nbpt-1)?i=Maxpoint:i+1) {
    if ( (*(s->point))[i][1] < EXEPTION_VAL ) {   /* not eliminated */
      b = 0;
      smin = 0.0;
      pmin = -1;
      pn = (*(s->pointlist))[i];
      do {
        if( pn->simp != (*(s->succ))[i] && 
                  connected(pn->simp,(*(s->succ))[i],s->pointlist)) {
          p = pn->simp;
          v1[0] =(*(s->point))[(*(s->succ))[i]-1][0]-(*(s->point))[p-1][0];
          v1[1] =(*(s->point))[(*(s->succ))[i]-1][1]-(*(s->point))[p-1][1];
          v2[0] = (*(s->point))[ i][0] - (*(s->point))[ p-1][0];
          v2[1] = (*(s->point))[ i][1] - (*(s->point))[ p-1][1];
          scal = v1[0] * v2[0] + v1[1]*v2[1];
          if ( scal < 0.0 ) {
            norm = (v1[0]*v1[0]+v1[1]*v1[1])*(v2[0]*v2[0]+v2[1]*v2[1]);
            cos2 = scal*scal/norm;
            if ( cos2 > smin ) {
              pmin = p;
              smin = cos2;
            } 
          }
        }
        pn = pn->next;
      } while ( pn != NULL );
      if (pmin == -1) continue;
      if( sqrt((double)smin)  > MAX_WINKEL ) {
        DEBUGF(("     > %6.2f: %d %d %d",
          acos((double)(-sqrt(smin)))*180.0/3.1415,i,(*(s->succ))[i],pmin));
        b = 1;
      }
      if (b) {
        if(z2 >= Maxpoint + Maxplus) {
          if( pmin > Maxpoint + Maxplus ) pmin = pmin + Max_increment;
          realloc_x_sections(obj,'p');
          free_local_2D();
          alloc_local_2D();
        }
        add_new_point(s,i,pmin,&z2);
        newvertex = 1;        /* new vertex added */
      }
    }
  }
  if (newvertex) {   /* forget old pointlist */
    for (k=Maxpoint+s->nb_plus ; k< z2 ; ++k) {
      /* insert new vertices */
      px = (*(s->point))[k][0];
      py = (*(s->point))[k][1];
      maximum = 20;
      do {
        nbelim = 0;
        trian2(obj, s, k+1, &nbelim, ier);
        if(nbelim>0) {/* move the vertex along the edge that is not contained */
          (*(s->point))[k][0] = (*(s->point))[k][0]+
              ((*(s->point))[(*(s->succ))[k]-1][0]-(*(s->point))[k][0])/10.0;
          (*(s->point))[k][1] = (*(s->point))[k][1]+
              ((*(s->point))[(*(s->succ))[k]-1][1]-(*(s->point))[k][1])/10.0;
        }
      } while((nbelim > 0) && (--maximum > 0));
      maximum = 20;
      if (nbelim >0) {
        (*(s->point))[k][0] = px;
        (*(s->point))[k][1] = py;
        do {
          nbelim = 0;
          trian2(obj, s, k+1, &nbelim, ier);
          if(nbelim>0) {/*move the vertex aint the edge that is not contained */
            (*(s->point))[k][0] = (*(s->point))[k][0]+
                 ((*(s->point))[(*(s->pred))[k]-1][0]-(*(s->point))[k][0])/10.0;
            (*(s->point))[k][1] = (*(s->point))[k][1]+
                 ((*(s->point))[(*(s->pred))[k]-1][1]-(*(s->point))[k][1])/10.0;
          }
        } while((nbelim > 0) && (--maximum > 0));
        if (maximum == 0) {
          /*no success, elim point*/
          (*(s->point))[k][1] = EXEPTION_VAL;
          (*(s->succ))[(*(s->pred))[k]-1] = (*(s->succ))[k];
          (*(s->pred))[(*(s->succ))[k]-1] = (*(s->pred))[k];
        }
      }
    }
    /* update list of adjacent points */
    s->nb_plus = z2 - Maxpoint;
    plist(s);
  }
  else {
    DEBUGF(("   angle o.k. \n"));
  }
}      /* winkeltest */




void add_new_point(X_section *s, int i, int p, int *z2)
{
  float p1[2], p3[2], g[2], lambda;

  p1[0] = (*(s->point))[i][0];
  p1[1] = (*(s->point))[i][1];
  p3[0] = (*(s->point))[p-1][0];
  p3[1] = (*(s->point))[p-1][1];
  g[0] = (*(s->point))[ (*(s->succ))[i]-1][0] - p1[0];
  g[1] = (*(s->point))[ (*(s->succ))[i]-1][1] - p1[1];
  lambda = (p3[1]*g[1]+p3[0]*g[0]-g[0]*p1[0]-g[1]*p1[1])/(g[0]*g[0]+g[1]*g[1]);

  (*(s->point))[*z2][0] = p1[0] + lambda * g[0];
  (*(s->point))[*z2][1] = p1[1] + lambda * g[1];
  (*(s->succ))[*z2] = (*(s->succ))[i];
  (*(s->pred))[(*(s->succ))[i]-1] = *z2+1;
  (*(s->pred))[*z2] = i+1;
  (*(s->succ))[i] = *z2+1;
  DEBUGF(("  new pt: %10.3f%10.3f%10.3f # %d\n",
           (*(s->point))[*z2][0],(*(s->point))[*z2][1],s->z,*z2+1));
  ++(*z2);
}



void elim_point(Coord point, Order suiv, Order pred, int *nbelim, int *ptelim)
/*
     rechaine le contour decrit par suiv et pred apres elimination des
     nbelim points ptelim i.e. redefinit suiv et pred du point i
*/
{
  int i,is,nb;

  nb = 0;
  for (i=0 ; i< *nbelim ; i++) {
    if (ptelim[i] < Maxpoint+Maxplus && point[ ptelim[i]-1 ][1] < EXEPTION_VAL) {
      suiv[pred[ptelim[i]-1]-1] = suiv[ptelim[i]-1];
      pred[suiv[ptelim[i]-1]-1] = pred[ptelim[i]-1];
      point[ ptelim[i]-1 ][1] = EXEPTION_VAL;
      is = suiv[ptelim[i]-1];
      if (suiv[suiv[is-1]-1] == is) {
        printf("   contour eliminated\n");
     /*   point[ is-1 ][1] = EXEPTION_VAL; */
     /*   point[ suiv[is-1]-1 ][1] = EXEPTION_VAL; */
        nb = nb + 2;
      }
    }
  }
  *nbelim = *nbelim + nb;
}



void put_internal(Object *obj, X_section *s1, X_section *s2)
{
   int ip, nsc, go_on = TRUE;
   register int i,j,j1,j2,j3,k;
   int nb;
   extern int tridep(X_section *s, int ip, int nsdep, int *nsfin);
   extern double inter_seuil;

   for (i=0 ; i< s1->nbs ; i++) {
     /* check if triangles of frame */
     for (j=0 ; j<3 ; j++) {
       if ((*(s1->simp))[i][j] > Maxvertex-4) {go_on = FALSE; break;}
     }
     if (!go_on) { go_on = TRUE; continue; }

     /* check if external tri */
     for (j=0,j1=1 ; j<3 ; j++, j1=(j1==2)?0:j1+1) {
       if ( test_edge_new( (*(s1->simp))[i][j], (*(s1->simp))[i][j1],
                 *(s1->point),*(s1->succ),*(s1->pred), s1 ) == -1)
       { go_on = FALSE; break; }
     }
     if (go_on) { continue; }

     if (obj->flag.internal_endchk) {
       j2 = j1+1; if (j2 == 3) j2 = 0;
       j3 = j2+1; if (j3 == 3) j3 = 0;
       /* do not insert point if tri has two contour edges */
       if (test_edge_new( (*(s1->simp))[i][j1], (*(s1->simp))[i][j2],
              *(s1->point),*(s1->succ),*(s1->pred), s1 ) == 0 &&
           test_edge_new( (*(s1->simp))[i][j2], (*(s1->simp))[i][j3],
              *(s1->point),*(s1->succ),*(s1->pred), s1 ) == 0 ) {
             go_on = TRUE;
             continue;
       }
     }
     else {
       if (obj->flag.internal_framechk) {
         j2 = j1+1; if (j2 == 3) j2 = 0;
         j3 = j2+1; if (j3 == 3) j3 = 0;
         /* do not insert point if tri has two contour edges , and the nbor
            opposite to the eliminated edge has a framepoint */
         if (test_edge_new( (*(s1->simp))[i][j1], (*(s1->simp))[i][j2],
                *(s1->point),*(s1->succ),*(s1->pred), s1 ) == 0 &&
             test_edge_new( (*(s1->simp))[i][j2], (*(s1->simp))[i][j3],
                *(s1->point),*(s1->succ),*(s1->pred), s1 ) == 0 ) {
           /* check if triangles of frame */
           nb = (*(s1->vois))[i][j2]-1;
           for (k=0 ; k<3 ; k++) {
             if ((*(s1->simp))[nb][k] > Maxvertex-4) {
               go_on = TRUE;
               break;
             }
           }
         }
         if (go_on) { continue; }
       }
     }

     if(s2->nb_int >= Max_int) {
       realloc_x_sections(obj, 'i');
       free_local_2D();
       alloc_local_2D();
     }
     ip =  Maxpoint+Maxplus+s2->nb_int;
     (*(s2->point))[ip][0] = (*(s1->centre))[i][0];
     (*(s2->point))[ip][1] = (*(s1->centre))[i][1];

     if( tridep(s2,ip+1,1,&nsc) == 0)
       {go_on = TRUE; continue;}

     go_on = TRUE;
     for (j=0 ; j<3 ; j++) {
       if ((*(s2->simp))[nsc-1][j] > Maxvertex-4) {go_on = FALSE; break;}
     }
     if (!go_on) { continue; }

     for (j=0,j1=1 ; j<3 ; j++, j1=(j1==2)?0:j1+1) {
       if (test_edge_new((*(s2->simp))[nsc-1][j],(*(s2->simp))[nsc-1][j1],
                        *(s2->point),*(s2->succ),*(s2->pred), s2 ) == -1)
       { go_on = FALSE; break; }
     }
     if (!go_on) { continue; }

     for (j=0,j1=1 ; j<3 ; j++, j1=(j1==2)?0:j1+1) {
       if ( (*(s2->succ))[(*(s2->simp))[nsc-1][j]-1] ==
            (*(s2->simp))[nsc-1][j1] ||
            (*(s2->pred))[(*(s2->simp))[nsc-1][j]-1] ==
            (*(s2->simp))[nsc-1][j1] )
          if( too_close(&( (*(s2->point))[(*(s2->simp))[nsc-1][j]-1][0]),
                       &( (*(s2->point))[(*(s2->simp))[nsc-1][j1]-1][0]),
                       &( (*(s2->point))[ip][0]), inter_seuil ) ) {
            go_on = FALSE; break;}
     }
     if (!go_on) { continue; }

     s2->nb_int++;
   }
}


int too_close(float *p1, float *p2, float *p3, double seuil)
{
  double p1p3[2], p1p2[2], n, h;

  p1p3[0] = p3[0] - p1[0];
  p1p3[1] = p3[1] - p1[1];
  p1p2[0] = p2[0] - p1[0];
  p1p2[1] = p2[1] - p1[1];
  n = sqrt(p1p2[0]*p1p2[0] + p1p2[1]*p1p2[1]);
  h = fabs((p1p3[0]*p1p2[1] - p1p3[1]*p1p2[0])/n);
  if ( h < seuil) {
    return(1);
  }
  else return(0);
}

void alloc_local_2D(void)
{
  traite = (char *)calloc(Maxtri, sizeof(char));
  ERRCHK(traite, "tri2D: no mem available (traite)");
  detrui = (char *)calloc(Maxtri, sizeof(char));
  ERRCHK(detrui, "tri2D: no mem available (detrui)");

  ndet = (int *)calloc(Maxtdel, sizeof(int));
  ERRCHK(ndet, "tri2D: no mem space (ndet)");
  ntan = (int *)calloc(Maxttg, sizeof(int));
  ERRCHK(ntan, "tri2D: no mem space (ntan)");

  suiv1 = (int *)calloc(Maxvertex, sizeof(int));
  ERRCHK(suiv1, "tri2D: no mem available (suiv1)");
  voisin = (int *)calloc(Maxvertex, sizeof(int));
  ERRCHK(voisin, "tri2D: no mem available (voisin)");
  voy = (int *)calloc(Maxvertex, sizeof(int));
  ERRCHK(voy, "tri2D: no mem available (voy)");

  recycl = (int *)calloc(Maxrecycl, sizeof(int));
  ERRCHK(recycl, "tri2D: no mem available (recycl)");

  mbord = (int *)calloc(Maxbord+2, sizeof(int));
  ERRCHK(mbord, "tri2D: no mem available (mbord)");
  mbortr = (int *)calloc(Maxbord+2, sizeof(int));
  ERRCHK(mbortr, "tri2D: no mem available (mbortr)");
  voyeur = (int *)calloc(Maxbord, sizeof(int));
  ERRCHK(voyeur, "tri2D: no mem available (voyeur)");
  nisnew = (int *)calloc(Maxbord, sizeof(int));
  ERRCHK(nisnew, "tri2D: no mem available (nisnew)");
  nsimp2 = (int *)calloc(Maxbord*3, sizeof(int));
  ERRCHK(nsimp2, "tri2D: no mem available (nsimp2)");
  nvois2 = (int *)calloc(Maxbord*3, sizeof(int));
  ERRCHK(nvois2, "tri2D: no mem available (nvois2)");
  centr2 = (REAL *)calloc(Maxbord*2, sizeof(REAL));
  ERRCHK(centr2, "tri2D: no mem available (centr2)");
  rayon2 = (REAL *)calloc(Maxbord, sizeof(REAL));
  ERRCHK(centr2, "tri2D: no mem available (centr2)");
  npile = (int *)calloc(Maxpile, sizeof(int));
  ERRCHK(npile, "tri2D: no mem space for npile\n");
}

void free_local_2D(void)
{
  free((char *)traite);
  free((char *)detrui);
  free((char *)suiv1);
  free((char *)voisin);
  free((char *)voy);
  free((char *)recycl);
  free((char *)ndet);
  free((char *)ntan);
  free((char *)mbord);
  free((char *)mbortr);
  free((char *)voyeur);
  free((char *)nisnew);
  free((char *)nsimp2);
  free((char *)nvois2);
  free((char *)centr2);
  free((char *)rayon2);
  free((char *)npile);
}
