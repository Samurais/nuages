#ifndef lint
static  char *sccsid = "@(#)correct.c	4.4 97/04/10";
#endif

/************************************************************************
 *									*
 * REPROS-REconstruction from Planar cROss-Sections  V 4.0  Sep 29 1993 *
 *									*
 *  module correct.c							*
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *			Modification History				*
 *									*
 * Jan 25 1995 translated to ANSI C					*
 * Sep  5 1994 #include <malloc.h> added				*
 * Dec 29 1994 #ifndef VMS_NUAGES added					*
 ************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifndef VMS_NUAGES
#include <memory.h> 
#include <malloc.h>
#endif

#include "repros.h"


void reject(Slice *S, int t, int *nb, int *tab, int (*nvois)[4], unsigned char *ityps);
int  tx(Slice *S, int t, int *x);
void test_cell(Slice *, int, int, int, int *, int);
int  contain(Slice *, int, int, int);
void test_all(Slice *, int, int, int, int *);


static char *mark1;   /* array for marking visited terahedra*/ 
static char *mark2;   /* " */
static char *mark12;  /* " */
static int  *list;

float volume(Object *obj)
{
  Slice *S;
  X_section *s[2];
  float a[3], b[3], c[3];
  float x,vol;
  register i,j;

  S = obj->slice;
  s[0] = obj->s1; 
  s[1] = obj->s2; 
  vol = 0; 
  for (i=0 ; i<S->nb_t1 ; i++){
    if (Not_Elim(S,i)) {
      for (j=0 ; j<2 ; j++) {
        a[j] = (*(s[0]->point))[(*(S->simp))[i][1]-1][j] - 
               (*(s[0]->point))[(*(S->simp))[i][0]-1][j]; 
        b[j] = (*(s[0]->point))[(*(S->simp))[i][2]-1][j] - 
               (*(s[0]->point))[(*(S->simp))[i][0]-1][j]; 
        c[j] = (*(s[1]->point))[(*(S->simp))[i][3]-1][j] - 
               (*(s[0]->point))[(*(S->simp))[i][0]-1][j]; 
      }
      a[2] = 0.0;
      b[2] = 0.0;
      c[2] = s[1]->z - s[0]->z;
      x = fabs(  (a[1]*b[2]-a[2]*b[1]) * c[0]  - 
                 (a[0]*b[2]-a[2]*b[0]) * c[1]  + 
                 (a[0]*b[1]-a[1]*b[0]) * c[2] ) / 6.0;
      vol = vol + x;
    }
  } 
  for (i=S->nb_t1 ; i<S->nb_t1 + S->nb_t2 ; i++){
    if (Not_Elim(S,i)) {
      for (j=0 ; j<2 ; j++) {
        a[j] = (*(s[1]->point))[(*(S->simp))[i][1]-1][j] - 
               (*(s[1]->point))[(*(S->simp))[i][0]-1][j]; 
        b[j] = (*(s[1]->point))[(*(S->simp))[i][2]-1][j] - 
               (*(s[1]->point))[(*(S->simp))[i][0]-1][j]; 
        c[j] = (*(s[0]->point))[(*(S->simp))[i][3]-1][j] - 
               (*(s[1]->point))[(*(S->simp))[i][0]-1][j]; 
      }
      a[2] = 0.0;
      b[2] = 0.0;
      c[2] = s[0]->z - s[1]->z;
      x = fabs(  (a[1]*b[2]-a[2]*b[1]) * c[0]  - 
                 (a[0]*b[2]-a[2]*b[0]) * c[1]  + 
                 (a[0]*b[1]-a[1]*b[0]) * c[2] ) / 6.0;
    
      vol = vol + x;
    }
  } 
  for (i=S->nb_t1 + S->nb_t2 ; i<S->nbs ; i++){
    if (Not_Elim(S,i)) {
      for (j=0 ; j<2 ; j++) {
        a[j] = (*(s[1]->point))[(*(S->simp))[i][1]-1][j] - 
               (*(s[1]->point))[(*(S->simp))[i][0]-1][j]; 
        b[j] = (*(s[0]->point))[(*(S->simp))[i][2]-1][j] - 
               (*(s[1]->point))[(*(S->simp))[i][0]-1][j]; 
        c[j] = (*(s[0]->point))[(*(S->simp))[i][3]-1][j] - 
               (*(s[1]->point))[(*(S->simp))[i][0]-1][j]; 
      }
      a[2] = 0.0;
      b[2] = s[0]->z - s[1]->z;
      c[2] = s[0]->z - s[1]->z;
      x = fabs(  (a[1]*b[2]-a[2]*b[1]) * c[0]  - 
                 (a[0]*b[2]-a[2]*b[0]) * c[1]  + 
                 (a[0]*b[1]-a[1]*b[0]) * c[2] ) / 6.0;
    
      vol = vol + x;
    }
  } 
  return(vol);
}



void solid_test(Object *obj, int (*nvois)[4], unsigned char *ityps)

/*****************************************************************************
*eliminates tetrahedra which are not solid.                                  *
*****************************************************************************/
{
  Slice *S;
  int *n_list, n_ptr = 0;
  int i,t,m,count = 0;
  int  solid(Slice *S, int e, int *n_ptr, int *n_list, int size, int (*nvois)[4]);
  int size;
  unsigned mem_size;

  S = obj->slice;
  size = Max(S->nb_t1,S->nb_t2);
  size = Max(size,100);
  mem_size = size*sizeof(int);
  n_list = (int *)malloc(mem_size);
  if (n_list == NULL) {
    fprintf(stderr,"solid_test: no memory (need %dk)\n", mem_size/1024);
    fflush(stderr);
    exit(1);
  }
  /*DEBUGF(("solid_test:  %dk allocated\n",mem_size/1024));*/
 
  count = 0;
  do {
    m=0;
    for (t = S->nb_t1+S->nb_t2 ; t<  S->nbs ; ++t ) /* for each tetrahedra t12*/
      if (Not_Elim(S,t)) { /* if t of type t12 and not yet eliminated */
                            /* get the edges of t */
      n_ptr = 1;
      *n_list = t;

      if (!solid(S,0,&n_ptr,n_list,size,nvois) &&
          !solid(S,1,&n_ptr,n_list,size,nvois)) { /* edge e1,e2 not solid */
            for (i=0 ; i<n_ptr-1 ; i++) {
              ityps[*(n_list + i)] = ityps[*(n_list + i)] | ELIM;
              /*DEBUGF(("    solid_test: -simplexe %d\n" , n_list[i] ));*/
              ++count;
            }
            m = 1;    /* rejected tetrahedra */
            --count;
        continue;
      }
      if(!solid(S,2,&n_ptr,n_list,size,nvois) &&
         !solid(S,3,&n_ptr,n_list,size,nvois)) { /* edge e3,e4 not solid */
            for (i=0 ; i<n_ptr-1 ; i++) {
              ityps[*(n_list + i)] = ityps[*(n_list + i)] | ELIM;
              /*DEBUGF(("    solid_test: -simplexe %d\n" , n_list[i] ));*/
              ++count;
            }
            m = 1;    /* rejected tetrahedra */
            --count;
        continue;
      }
    }   /*if t12 */
  } while (m);       /* repeat until no tetrahedra rejected */

  for (t = 0 ; t < S->nb_t1+S->nb_t2 ; ++t) /*for each tetrahedra t1/2*/
    if ( !(ityps[t] & (ELIM | MARKED))) {/* if t of type t1 or t2 and not yet rejected */
      reject(S,t,&n_ptr,n_list,nvois,ityps);
      count = count + n_ptr;
    }
  for (t = 0 ; t < S->nb_t1+S->nb_t2 ; ++t)
    if(ityps[t] & MARKED) ityps[t] = ityps[t] & ~MARKED;
  if (count > 0) {
    printf("   solid_test:   %d" , count);
    printf(" tetrahedra deleted \n");
  }
  free((char *)n_list);
  /*DEBUGF(("solid_test:  %dk free\n",mem_size/1024));*/
}


int solid(Slice *S, int e, int *n_ptr, int *n_list, int size, int (*nvois)[4])
{
  int h,j,nbstart;
  int start;

  nbstart = e;
  start = (*(S->simp))[n_list[*n_ptr-1]][nbstart];
  
  do {
    for ( j= (nbstart&2) ; j< (nbstart&2) +2 ; j++) {
      if (start == (*(S->simp))[n_list[*n_ptr-1]][j]) {
        nbstart = j; break;
      } 
    }

    h = nvois[n_list[*n_ptr-1]][nbstart];
    if (h == 0 || ((*(S->ityps))[h-1] & ELIM)) {
      if (*n_ptr >= size) {
        fprintf(stderr,"solid: n_list overflow #=%d\n",*n_ptr);
        fflush(stderr);
        exit(1);
      }
      n_list[(*n_ptr)++] = n_list[0];
      return(0);
    }
    if (h-1 < S->nb_t1+S->nb_t2) {
      *n_ptr = 1;
      return(1);
    }
    /* continue */

    nbstart = nbstart - nbstart%2 + (nbstart+1)%2;
    start = (*(S->simp))[n_list[*n_ptr-1]][nbstart];
    if (*n_ptr >= size) {
      fprintf(stderr,"solid: n_list overflow #=%d\n",*n_ptr);
      fflush(stderr);
      exit(1);
    }
    n_list[(*n_ptr)++] = h-1;
  } while(TRUE);
}





void correct(Object *obj)
{
  Slice *S;
  int typ, i, x;
  int countall;
  int v[4];

  S = obj->slice;
  countall = 0;
  mark1 = (char *)malloc(S->nbs*sizeof(char));
  ERRCHK(mark1, "correct: no mem space\n");
  mark2 = (char *)malloc(S->nbs*sizeof(char));
  ERRCHK(mark2, "correct: no mem space\n");
  mark12 = (char *)malloc(S->nbs*sizeof(char));
  ERRCHK(mark12, "correct: no mem space\n");

  list = (int *)calloc(Adjmax, sizeof(int));
  ERRCHK(list, "correct: no mem space\n");
  
  memset(mark1,  0, S->nbs*sizeof(char));
  memset(mark2,  0, S->nbs*sizeof(char));
  memset(mark12, 0, S->nbs*sizeof(char));


  for ( i=0 ; i< S->nb_t1+S->nb_t2 ; ++i ) {
    if ( Elim(S,i) &&  !(*(mark1+i)) ) {
      typ = tx(S, i, &x);
      test_cell(S,i, typ, x,&countall,1);
    }
  }
  for ( i = S->nb_t1+S->nb_t2; i<S->nbs; ++i )
    if( Elim(S,i) ) {
      if( *(mark12+i) != 10) {
        v[0] = (*(S->simp))[i][0]; 
        v[1] = (*(S->simp))[i][1]; 
        v[2] = (*(S->simp))[i][2]; 
        v[3] = (*(S->simp))[i][3]; 
        if( *(mark12+i) == 2 || *(mark12+i) == 6) {
          test_cell(S,i, 1, v[0],&countall,0);
          test_cell(S,i, 1, v[1],&countall,0);
        } 
        else
          if( *(mark12+i) == 8 || *(mark12+i) == 9) {
            test_cell(S,i,2, v[2],&countall,0);
            test_cell(S,i,2, v[3],&countall,0);
          } 
        else {
          test_cell(S,i, 1, v[0],&countall,0);
          test_cell(S,i, 1, v[1],&countall,0);
          test_cell(S,i, 2, v[2],&countall,0);
          test_cell(S,i, 2, v[3],&countall,0);
        }
      }
    }
  if (countall != 0)
    printf( "   correct:   %5d tetrahedra added\n",countall);
  free(mark1);
  free(mark2);
  free(mark12);
  free((char *)list);
}       /*----------- correct -----------------*/

  

int tx(Slice *S, int t, int *x)
{
  *x = (*(S->simp))[t][3];

  if( t < S->nb_t1 ) return(1);
  if( t >= S->nb_t1 && t < S->nb_t1+S->nb_t2 ) return(2);
  return(0);
}


void adjacent(Slice *S, int t, int *ok, int *count, int x, int typ)
{
  int j,nb;

  /*printf("%4d", t+1);*/
  *(mark2+t) = 1;      /* mark t */ 
  if (*count >= Adjmax) {
    char *ptr;
    DEBUGF(("   adjacent: realloc for max_adjacent at %d\n", *count));
    Adjmax = Adjmax + 500;
    ptr = (char *)list;
    list = (int *)realloc(ptr, Adjmax * sizeof(int));
    ERRCHK(list, "realloc for max_adjacent failed\n");
  }
  list[(*count)++] = t; 
  for( j=0 ; j<4 ; ++j) {
    nb = (*(S->vois))[t][j];
    if (nb == 0) {

      if((t >= S->nb_t1+S->nb_t2 && (j>>1)+1 != typ) || j != 3 )
        *ok = 1;
    }
    else
      if((Elim(S,(nb-1)))&&(!(*(mark2+nb-1)))&&contain(S,nb-1,x,!(typ-1)))
        adjacent(S,nb-1,ok,count,x,typ);
  }
}




int contain(Slice *S, int t, int x, int plane)
/* returns 1 if tetra t contains vertex x in x-section plane (0,1) */
{
 if (Is_t1(S,t))
  return (
          (!plane && ((*(S->simp))[t][0] == x || (*(S->simp))[t][1] == x || 
                       (*(S->simp))[t][2] == x)) ||
          (plane && (*(S->simp))[t][3] == x ));
 if (Is_t2(S,t))
  return (
          (plane && ((*(S->simp))[t][0] == x || (*(S->simp))[t][1] == x || 
                       (*(S->simp))[t][2] == x)) ||
          (!plane && (*(S->simp))[t][3] == x ));
 return ( (*(S->simp))[t][ (plane==0)<<1 ] == x ||
                  (*(S->simp))[t][ ((plane==0)<<1)+1 ] == x );
}


double distance3D(int p1, int p2, X_section *s1, X_section *s2)
{
  return( 
                ((*(s2->point))[p1-1][0] - (*(s1->point))[p2-1][0]) * 
                ((*(s2->point))[p1-1][0] - (*(s1->point))[p2-1][0]) 
              + ((*(s2->point))[p1-1][1] - (*(s1->point))[p2-1][1]) * 
                ((*(s2->point))[p1-1][1] - (*(s1->point))[p2-1][1]) 
              + (s2->z - s1->z) * (s2->z - s1->z) );
}


void minimize(Object *obj)
{
  Slice *S;
  X_section *se1,*se2;
  int t,j,c1,c2,s1[4],s2[4];
  int flag;
  int nb,one_more_once;

  S = obj->slice;
  se1 = obj->s1;
  se2 = obj->s2;

  flag = obj->flag.minimize_all; 
  nb = 0;
  do {
    one_more_once  = 0;
    for( t=S->nb_t1+S->nb_t2 ; t<S->nbs ; ++t) {
      if( Not_Elim(S,t)) {
        c1 = 0;
        c2 = 0;
        for( j=0 ; j<4 ; ++j )
          if( ((*(S->vois))[t][j] == 0) || (Elim(S,((*(S->vois))[t][j]-1))))
            s1[c1++] = (*(S->simp))[t][j];
          else
            s2[c2++] = (*(S->simp))[t][j];
          if(c1 == 2) {
            if (flag || distance3D( s2[0],s2[1],se1,se2) >=
                distance3D( s1[0],s1[1],se1,se2) ) {
              (*(S->ityps))[t] = (*(S->ityps))[t] | ELIM;
              one_more_once++;
            }
          }
        }
     }
    nb = nb + one_more_once;
  } while (one_more_once);
  printf("   min:          %d tetrahedra deleted\n",nb);
}





void test_cell(Slice *S, int i, int typ, int x, int *countall, int test_12)
{
  int tt,count,ok,l;

  count = 0; ok = 0;
  adjacent(S,i,&ok,&count,x, typ);
  *(mark1+i) = 1;

  for( l = 0; l<count ; ++l)
     *(mark2 + *(list+l)) = 0;

  for( l = 0; l<count ; ++l) {
     tt = tx(S,*(list+l), &x);
     if( tt == (3-typ) ) ok = 1;
     else *(mark1 + *(list+l)) = 1;
     if( typ == 1 ) {
       if ( test_12 ) (*(mark12 + *(list+l)))++;
     }
     else {
       if ( test_12 ) *(mark12 + *(list+l))= *(mark12 + *(list+l)) + 4;
     }
  }
  if( !ok ) {
    for( l = 0; l<count ; ++l) {
       (*(S->ityps))[*(list+l)] = (*(S->ityps))[*(list+l)] & ~ELIM;
       ++(*countall);
    }
  } 
}




void correct_h(Object *obj)
{
  Slice *S;
  int typ, i, x;
  int countall;

  S = obj->slice;
  countall = 0;
  mark1 = (char *)malloc(S->nbs*sizeof(char));
  ERRCHK(mark1, "correct_h: no mem space\n");
  mark2 = (char *)malloc(S->nbs*sizeof(char));
  ERRCHK(mark2, "correct_h: no mem space\n");
  mark12 = (char *)malloc(S->nbs*sizeof(char));
  ERRCHK(mark12, "correct_h: no mem space\n");

  list = (int *)calloc(Adjmax, sizeof(int));
  ERRCHK(list, "correct_h: no mem space\n");
  
  memset(mark1, 0, S->nbs*sizeof(char));
  memset(mark2, 0, S->nbs*sizeof(char));

  for ( i=0 ; i< S->nbs ; ++i ) {
    if ( Elim(S,i) &&  !(mark1[i]) ) {
      typ = tx(S, i, &x);
      test_all(S,i, typ, x,&countall);
    }
  }
  if (countall != 0)
    printf( "   correct_h: %5d tetrahedra added\n",countall);
  free(mark1);
  free(mark2);
  free(mark12);
  free((char *)list);
}       /*----------- correct_h -----------------*/


void all_adjacent(Slice *S, int t, int *ok, int *count, int x)
{
  int j,nb;
  /*printf("%4d", t);*/
  mark2[t] = 1;      /* mark t */ 
  if (*count >= Adjmax) {
    char *ptr;
    DEBUGF(("   all_adjacent: realloc for max_adjacent at %d\n", *count));
    Adjmax = Adjmax + 500;
    ptr = (char *)list;
    list = (int *)realloc(ptr, Adjmax * sizeof(int));
    ERRCHK(list, "realloc for max_adjacent failed\n");
  }
  list[(*count)++] = t; 
  for( j=0 ; j<4 ; ++j) {
    nb = (*(S->vois))[t][j];
    if (nb == 0) {
      if(t >= S->nb_t1+S->nb_t2 || j != 3)
        *ok = 1;
      }
      else
        if( (Elim(S,(nb-1))) && (!(mark2[nb-1])) /*&& contain(nb,x,simp)*/)
          all_adjacent(S,nb-1,ok,count,x);
  }
}



void test_all(Slice *S, int i, int typ, int x, int *countall)
{
  int tt,count,ok,l;


  count = 0; ok = 0;
  all_adjacent(S,i,&ok,&count,x);
  *(mark1+i) = 1;

  for( l = 0; l<count ; ++l)
    *(mark2 + *(list+l)) = 0;

  for( l = 0; l<count ; ++l) {
    tt = tx(S,*(list+l), &x);
    if( tt == (3-typ) ) ok = 1;
    else *(mark1 + *(list+l)) = 1;
  }
  if( !ok ) {
    for( l = 0; l<count ; ++l) {
      (*(S->ityps))[*(list+l)] = (*(S->ityps))[*(list+l)] & ~ELIM;
      ++(*countall);
    }
  }
}


void reject(Slice *S, int t, int *nb, int *tab, int (*nvois)[4], unsigned char *ityps)

{
  int b,i;
  int h;
  int start, stop;


  *nb = 0;
  stop = 1;
  start = 0;
  tab[0] = t;
  b = TRUE;
  do {
      for (i=0; i<3 ; i++) {
        h = nvois[tab[start]][i];
        if ((h!=0) &&  !(ityps[h-1] & (ELIM | MARKED)) ) {
          if (h > S->nb_t1+S->nb_t2)
            b = FALSE; /*do not reject*/
          else {
            ityps[h-1] = ityps[h-1] | MARKED;
            tab[stop++] = h-1;
          }
        }
      }
    start++;
  } while(start < stop);
  if (b) {
    *nb = stop;
    for (i=0 ; i< stop; i++) ityps[tab[i]] = ityps[tab[i]] | ELIM;
    /*DEBUGF(("    solid_test - t1 t2: -simplexe %d\n" , tab[i]+1));*/
  }
}
