#ifndef lint
static  char *sccsid = "@(#)repros.c	4.6 96/10/31";
#endif

/************************************************************************
 *									*
 * REPROS-REconstruction from Planar cROss-Sections  V 4.0  Sep 29 1993 *
 *									*
 * main()								*
 * copyright (c) 1993 Bernhard Geiger					*
 ************************************************************************/
/************************************************************************
 *			Modification History				*
 *									*
 * May 15 1996 options -intf -inte and -mindist added 			*
 * Jan 25 1995 translated to ANSI C                                     *
 * Dec 29 1994 #ifndef VMS_NUAGES (srand) added				*
 * Sep  9 1994 print volume						*
 ************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "repros.h"


#ifndef VMS_NUAGES
extern void  srand48(long int);            /*random numbers*/
#endif

void grab_arguments(int, char **, Object *);

int Maxpoint, Maxplus, Max_int, Maxvertex, Maxtri, Maxv, Max_t12, Max4,
    Max_tnode, Maxhelp, Max_extra, Adjmax, Maxrecycl, Maxtdel, Maxttg, Maxpile,
    Maxbord, Max_increment;
float max_stretch;
double inter_seuil = INTER_SEUIL;
int debug = FALSE;

main(int argc, char **argv)
{
  int       i;
  Object    *obj, object;

  obj			= &object;

  obj->flag.do_correct       = FALSE;
  obj->flag.do_minimize      = FALSE;
  obj->flag.minimize_all     = FALSE;
  obj->flag.automatic        = FALSE;
  obj->flag.do_voronoi       = FALSE;
  obj->flag.w_test           = TRUE;
  obj->flag.do_delaunay      = FALSE;
  obj->flag.do_debug         = FALSE;
  obj->flag.interior         = FALSE;
  obj->flag.read_interior    = FALSE;
  obj->flag.write_interior   = FALSE;
  obj->flag.calc_interior    = TRUE;
  obj->flag.tetrahedra_out   = FALSE;
  obj->flag.do_max_vol       = FALSE;
  obj->flag.do_min_vol       = FALSE;
  obj->flag.new_format       = TRUE;
  obj->flag.all_tetras       = TRUE;
  obj->flag.do_stretch       = FALSE;
  obj->flag.internal_framechk = TRUE;
  obj->flag.internal_endchk = FALSE;
  obj->max_volume = 0.0;
  obj->min_volume = 0.0;

  init_seuil( obj);

  Maxplus	= MAXPLUS;
  Max_int	= MAX_INT;
  Maxhelp	= MAXHELP;
  Max_extra	= MAX_EXTRA;
  Adjmax	= ADJMAX;
  Maxrecycl	= MAXRECYCL;
  Maxtdel	= MAXTDEL;
  Maxttg	= MAXTTG;
  Maxpile	= MAXPILE;
  Maxbord	= MAXBORD;
  Max_t12	= MAX_T12;
  Max_tnode	= MAX_TNODE;
  Max_increment = MAX_INC;

#ifdef STATISTICS
  obj->nb_pts_in = 0;
  obj->nb_i_add  = 0;
  obj->nb_w_add  = 0;
#endif


  DEBUGF(("nuages-repros version 4.0\n"));
  grab_arguments(argc, argv, obj);

  init_files(obj);

  init_mem_X_section(&(obj->s1));
  init_mem_X_section(&(obj->s2));
  init_mem_X_section(&(obj->s3));
  init_mem_Slice(&(obj->slice));

#ifndef VMS_NUAGES
  srand48((long)0);
#endif

  read_section( obj, obj->s1, 0);

  printf("tri2D section #1   %d+%d points\n",obj->s1->nbpt,obj->s1->nb_int);  
  tri_2d(obj, obj->s1, NORMAL1);

  read_section( obj, obj->s2, 1);

  printf("tri2D section #2   %d+%d points\n",obj->s2->nbpt,obj->s2->nb_int);  
  tri_2d(obj, obj->s2, NORMAL2);

  if ( obj->flag.calc_interior || obj->flag.write_interior) {
    put_internal(obj,obj->s1,obj->s2);
    put_internal(obj,obj->s2,obj->s1);
  }

  tri_2d(obj, obj->s1, INTERNAL2);



  write_section( obj, obj->s1);

  for ( i=2 ; i<obj->nb_sections ; ++i) {
    read_section( obj, obj->s3, i);
    printf("tri2D section #%d   %d+%d points\n",
                    i+1,obj->s3->nbpt,obj->s3->nb_int);  
    tri_2d(obj, obj->s3, NORMAL1);

    if ( obj->flag.calc_interior || obj->flag.write_interior) {
      put_internal(obj,obj->s2,obj->s3);
      put_internal(obj,obj->s3,obj->s2);
    }

    tri_2d(obj, obj->s2, INTERNAL2);
    write_section( obj, obj->s2);


    printf("tri3D sections #%d#%d   %d+%d+%d,   %d+%d+%d points\n",
            i-1,i,obj->s1->nbpt,obj->s1->nb_int,obj->s1->nb_plus,
                  obj->s2->nbpt,obj->s2->nb_int,obj->s2->nb_plus);  

    tri_3d(obj);
    
    if( obj->flag.do_max_vol ) 
      obj->max_volume = obj->max_volume  + volume(obj);
    if( obj->flag.do_minimize)
      minimize(obj);
    if( obj->flag.do_min_vol ) 
      obj->min_volume = obj->min_volume + volume(obj);

    write_slice(obj);

    if (obj->flag.tetrahedra_out)
      write_tetrahedra(obj, obj->flag.all_tetras);

    free_slice(obj);
    toggle(obj);
  }

  tri_2d(obj, obj->s2, INTERNAL1);
  write_section( obj, obj->s2);

  printf("tri3D sections #%d#%d   %d+%d+%d,   %d+%d+%d points\n",
          obj->nb_sections-1,obj->nb_sections,
          obj->s1->nbpt,obj->s1->nb_int,obj->s1->nb_plus,
          obj->s2->nbpt,obj->s2->nb_int,obj->s2->nb_plus);  

  tri_3d(obj);
  if( obj->flag.do_max_vol )
    obj->max_volume = obj->max_volume  + volume(obj);
  if( obj->flag.do_minimize)
    minimize(obj);
  if( obj->flag.do_min_vol )
    obj->min_volume = obj->min_volume + volume(obj);

  write_slice(obj);

  if (obj->flag.tetrahedra_out)
    write_tetrahedra(obj, obj->flag.all_tetras);

  free_slice(obj);


#ifdef STATISTICS
  obj->nb_pts_out = obj->nb_pts_in + obj->nb_i_add + obj->nb_w_add;
  printf("#pts in: %d  #pts out: %d (+%6.2f%%)  contour: %6.2f%% interior: %6.2f%%\n",
          obj->nb_pts_in,obj->nb_pts_out,
            100.0*(float)(obj->nb_i_add + obj->nb_w_add)/(float)obj->nb_pts_in,
            100.0*(float)(obj->nb_w_add)/(float)obj->nb_pts_in,
            100.0*(float)(obj->nb_i_add)/(float)obj->nb_pts_in);
#endif
  if (obj->flag.do_max_vol) printf("volume: %f  (max)\n", obj->max_volume);
  if (obj->flag.do_min_vol) printf("volume: %f  (min)\n", obj->min_volume);
  file_close(obj);
  exit(0);
}

void Usage(void)
{
  fprintf(stderr,"Usage: repros <in-file> <out-file> [-t <tetra-file>] [-m] [-v] [-V] [-w] [-sn <value>] [-max_increment <nb>] [-no_int] [-int <file>] [+int <file>] [-intf] [-mindist <value>] [-inside] [-stretch <value>] [-debug]\n");
  fprintf(stderr,"       -m      minimize volume\n");
  fprintf(stderr,"       -V      do maximum volume calculation\n");
  fprintf(stderr,"       -v      do minimum volume calculation (sets -m)\n");
  fprintf(stderr,"       -w      no test for obtuse angles\n");
  fprintf(stderr,"       -sn <value> set theshold n to value (n=1..6)\n");
  fprintf(stderr,"       -t      tetrahedra output\n");
  fprintf(stderr,"       -max_increment <nb> set realloc increment to <nb> (Default=500)\n");
  fprintf(stderr,"       -no_int don't add internal vertices\n");
  fprintf(stderr,"       +int <file> read internal vertices from file\n"); 
  fprintf(stderr,"       -int <file> write internal vertices to file\n");
  fprintf(stderr,"       -intf       turn framecheck for int vertices off\n");
  fprintf(stderr,"       -inside don't output tetras outside the object\n");
  fprintf(stderr,"       -stretch <value> delete tetras which are too stretched\n");
  fprintf(stderr,"       -mindist <value> min. distance of internal vertices to contours (default = 0.01)\n");
  fprintf(stderr,"       -debug  diagnostic output\n");
  exit(1);
}


void grab_arguments(int argc, char **argv, Object *obj)
{
  int i;

  if (argc < 3)  Usage();
  obj->fnam[0] = argv[1];
  obj->fnam[1] = argv[2];

  for (i = 3; i < argc; i++) {
    if (strcmp(argv[i], "-M") == 0) {
      obj->flag.do_minimize  = TRUE;
      obj->flag.minimize_all = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-m") == 0) {
      obj->flag.do_minimize = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-V") == 0) {
      obj->flag.do_max_vol = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-debug") == 0) {
      debug = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-w") == 0) {
      obj->flag.w_test = FALSE;
      continue;
    }
    if (strcmp(argv[i], "-v") == 0) {
      obj->flag.do_min_vol = TRUE;
      obj->flag.do_minimize = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-t") == 0) {
      if (++i >= argc) Usage();
      obj->fnam[2] = argv[i];
      obj->flag.tetrahedra_out = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-inside") == 0) {
      obj->flag.all_tetras = FALSE;
      continue;
    }
    if (strcmp(argv[i], "-intf") == 0) {
      obj->flag.internal_framechk = FALSE;
      continue;
    }
    if (strcmp(argv[i], "-inte") == 0) {
      obj->flag.internal_endchk = TRUE;
      obj->flag.internal_framechk = FALSE;
      continue;
    }
    if (strcmp(argv[i], "-no_int") == 0) {
      obj->flag.read_interior = FALSE;
      obj->flag.write_interior = FALSE;
      obj->flag.calc_interior = FALSE;
      obj->flag.do_correct       = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-int") == 0) {
      obj->flag.read_interior = FALSE;
      obj->flag.write_interior = TRUE;
      obj->flag.calc_interior = FALSE;
      if (++i >= argc) Usage();
      obj->fnam[3] = argv[i];
      continue;
    }
    if (strcmp(argv[i], "+int") == 0) {
      obj->flag.read_interior = TRUE;
      obj->flag.write_interior = FALSE;
      obj->flag.calc_interior = FALSE;
      if (++i >= argc) Usage();
      obj->fnam[3] = argv[i];
      continue;
    }
    if (strcmp(argv[i], "-mindist") == 0) {
      if (++i >= argc) Usage();
      inter_seuil = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-stretch") == 0) {
      if (++i >= argc) Usage();
      max_stretch = atof(argv[i]);
      max_stretch = max_stretch*max_stretch;
      obj->flag.do_stretch = TRUE;
      continue;
    }
    if (strncmp(argv[i], "-s", 2) == 0) {
      if (++i >= argc) Usage();
      sscanf(argv[i],"%lf",&(obj->seuil[ argv[i-1][2]-49]));
      continue;
    }
    if (strcmp(argv[i], "-max_point") == 0) {
      if (++i >= argc) Usage();
      Maxpoint = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_plus") == 0) {
      if (++i >= argc) Usage();
      Maxplus = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_int") == 0) {
      if (++i >= argc) Usage();
      Max_int = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_t12") == 0) {
      if (++i >= argc) Usage();
      Max_t12 = atoi(argv[i]);
      Max_tnode = 2*Max_t12;
      continue;
    }
    if (strcmp(argv[i], "-max_adjacent") == 0) {
      if (++i >= argc) Usage();
      Adjmax = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_help") == 0) {
      if (++i >= argc) Usage();
      Maxhelp = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_extra") == 0) {
      if (++i >= argc) Usage();
      Max_extra = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_recycl") == 0) {
      if (++i >= argc) Usage();
      Maxrecycl = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_tdel") == 0) {
      if (++i >= argc) Usage();
      Maxtdel = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_ttg") == 0) {
      if (++i >= argc) Usage();
      Maxttg = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_pile") == 0) {
      if (++i >= argc) Usage();
      Maxpile = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_bord") == 0) {
      if (++i >= argc) Usage();
      Maxbord = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-max_increment") == 0) {
      if (++i >= argc) Usage();
      Max_increment = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-help") == 0) {
      Usage();
    }
    Usage();
  }
}
