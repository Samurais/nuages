#ifndef lint
static  char *sccsid = "@(#)tri3D.c	4.9 97/04/17";
#endif

/************************************************************************
 *									*
 * REPROS-REconstruction from Planar cROss-Sections  V 4.0  Sep 29 1993 *
 *									*
 *  module tri3D.c							*
 *  copyright (c) 1993 Bernhard Geiger					*
 ************************************************************************/
/************************************************************************
 *			Modification History				*
 *									*
 * Apr 10 1997 inclusion of stdlib.h                                    *
 * Dec  8 1996 general speedup                                          *
 * May 15 1996 elim_stretched() completely ouverhauled			*
 * Mar 17 1995 Some fewer warnings when compiling			*
 * Jan 25 1995 translated to ANSI C                                     *
 * Dec 29 1994 #ifndef VMS_NUAGES added					*
 * Sep  5 1994  missing initalization in cospherique			*
 *              txin() inserting 0 instead of -1			*
 * Jul 26 1994  nearest() replaced by nearest_p() (for IBM6000 compat)	*
 ************************************************************************/

#include <stdio.h>               /* io library */
#include <math.h>                /* math library */
#ifndef VMS_NUAGES
#include <malloc.h>
/*#include <stdlib.h>*/
#include <memory.h>
#endif
#include "repros.h"

int *help;

int intsearch(Object *, int, int, int, double, double, double, double);
int searchextra(Object *, int, int, int, int *, int *, int *);
int intersection(int, int, double, double, double, double, Centre (*centre), double);
int tin(Object *, int, int, int, int, int, int, int);
int vois(int s, int sn, Simp (*nvois));
int newpoint(int p, int s1, Simp nsimp, int nv);
int tin_test(Object *, int, int, int, int, int, int, int);
int slanted(Slice *S, X_section *s1, X_section *s2, int t);

extern void correct(Object *obj);
extern solid_test(Object *obj, int (*nvois)[4], unsigned char *ityps);
extern void correct_h(Object *obj);
extern void realloc_slice(Object *obj, int inc);
extern void alloc_slice(Object *obj);
extern void free_intable(Object *obj);


double distance(int p1, double px, double py, Coord (*point))
{
   double dx,dy;

   dx = (double)(*point)[p1-1][0] - px;
   dy = (double)(*point)[p1-1][1] - py;
   return( (dx*dx) + (dy*dy) );
}


int nearest_p(double *p, X_section *sect, int start, double seuil, int *p1, int *p2, int *p3, int flag)
{
  double px,py;
  double xa,xn;
  int nbcos;
  int i,s;
  int b,end2,c3;
  Snode *pl;

  px = p[0];
  py = p[1];
  b = 0;
  nbcos = 1;                /* number of points with same distance to (px,py) */
  s = start;                /* search begins at point s */

  xa = distance(s,px,py,sect->point);
  pl = (*(sect->pointlist))[s-1];

  do {         /* look for smaller distance among adjacent points */
    i = pl->simp;
    xn = distance(i,px,py,sect->point);
    if ( xn < ( xa - seuil ) ) { /* smaller distance */
      xa = xn;
      s = i;                  /* continue at point i */
      pl = (*(sect->pointlist))[s-1];
    }
    else {
      if ( fabs(xn -xa) <= seuil ) { /* same distance */
        /* s and i have same distance to (px,py).If another point with
           same or smaller distance exists,it can be reached from s.
           so we continue at point s */

        end2 = 0;
        *p1 = s;
        *p2 = i;
        c3 = 0;
        nbcos = 2;
        while ( (pl->next !=NULL) && !end2 ) { 
                         /* there are still other points connected with s */
          pl = pl->next;
          i = pl->simp;
          xn = distance(i,px,py,sect->point);
          if ( fabs(xn-xa) <= seuil ) {    /* same distance again */
            c3 = 1;
            nbcos = 3;
            *p3 = i;
          }
          else
            if ( xn < xa - seuil) {         /* smaller distance */
              xa = xn;
              s = i;                         /* continue at i */
              pl = (*(sect->pointlist))[s-1];
              nbcos = 1;
              c3 = 0;
              end2 = 1;
            }
        }
        if (!end2) {        /* no better point found */
          b = 1;
          if (c3) {
            if (flag) DEBUGF((" \n   6 points cospherique\n" ));
          }
          else {
            if (flag) DEBUGF((" \n   5 points cospherique\n"));
          }
        }
      }
      else {     /* larger distance */ 
        if ( pl->next == NULL )  /* if no more points */
          b = 1;                       /* end */
        else {
          pl = pl->next;          /* else continue with next point */
        }
      }
    }
  } while( !b );                  /* while nearest point not found */
  *p1 = s;
  return(nbcos);
}



void try(Object *obj, int *p, int *p1, int *v0, int a, int b, int *s1a, int *s2a, int offset, int *error, int *found)

/******************************************************************************
* if in Voronoi-cell of point p no intersection found,we look in adjacent     *
*  cells or in the extralist.                                                 *
*****************************************************************************/

{
  *found = 0;
  *error = 0;
  DEBUGF(("   no intersection cell %d/simplex %d %d\n" , *p,a,b));
  if (*p > Maxvertex-4) {
              /* we are now in the cell of a point of the frame and find no
                 intersection.If there is an intersection with an infinite
                 Voronoi-edge,it would lead us to a adjacent point of the 
                 frame :  */
    if (*v0 == 0) {     /* first try */
      *p1 = *p;         /* save original point */
                        /* get adjacent point of frame */
      if (connected(*p1,*p1+1,obj->s1->pointlist))
        *p = *p1 + 1;
      else
        *p = *p1-3;
      ++(*v0);
    }
    else
      if (*v0 == 1) {   /* 2-nd try */
                        /* get other adjacent point of frame */
      if (connected(*p1,*p1-1,obj->s1->pointlist))
        *p = *p1 - 1;
      else
        *p = *p1+3;
      ++(*v0);
    }
    else {/* no intersection with infinite V-edge.Look in list of
             extra intersections  */
      *p = searchextra( obj,*p1,a+offset,b+offset, s1a,s2a,found );
      *v0 = 0;
      if ( *p == 0 ) {   /* no matching intersection */
        *error = 1;
      }
    }
  }
  else { /* look in list of extra intersections */
    *p = searchextra( obj,*p,a+offset,b+offset, s1a,s2a,found );
    if ( *p == 0 ) {   /* no matching intersection found */
      *error = 1;
    }
  }
}   /* try */




int intsearch(Object *obj, int a, int b, int nv, double x1, double y1, double x2, double y2)

/*******************************************************************************
* for a voronoi line of plane 2 we search the intersections with               *
*   Voronoi lines of plane 1.                                                  *
*  INPUT   :a,b :      2 triangles of plane 2.We search the intersections of   *
*                      their Voronoi-edge.                                     *
*           nv:        b is neighbour number nv of a;                          *
*           x1,y1 :    coordinates of the centre of a;                         *
*           x2,y2 :    coordinates of the centre of b;                         *
*******************************************************************************/
{
  int offset;
  int a1,b1;
  int error;
  int found;
  int ii,k;
  int j,s1,s2,s1a,s2a,p,p1,v0,bb;
  Snode *pn;
  X_section *se1,*se2;
  Slice *S;
  double seuil;
  int ret;


  se1 = obj->s1;
  se2 = obj->s2;
  S   = obj->slice;
  offset = se1->nbs;
  seuil = obj->seuil[5];
  error = 0;                        /* no error */
  a1 = (*(S->simp))[a+offset-1][3];       /* 4-th point of a in plane 1 */
  b1 = (*(S->simp))[b+offset-1][3];       /* 4-th point of b in plane 1 */
  if ( a1 != b1) {/* if they are not the same there will be intersections */
    s1a = 0;
    s2a = 0;
    v0 = 0;   /* number of visited adjacent Voronoi-cells */
    p = b1;   /* start in Voronoi-cell of point b1 */
    do {   /* let's have a look at all triangles having point p in common */
      pn = (*(se1->simplist))[p-1];
      bb = 0;      /* no intersection found */
      while ( (pn != NULL) && !bb) {
                  /* while there are still triangles containing p and
                     no intersection found visit all pairs (s1,s2) of adjacent
                     triangles having p in common  */
        s1 = pn->simp;
        j = 0;
        while ( (j<3) && !bb) {
          s2 = (*(se1->vois))[s1-1][j];
          if ((s2 != 0)  && (((s1 != s2a) || (s2 != s1a))&&
             ((s1 != s1a) || (s2 != s2a))) && connected(p,s2,se1->simplist) )
              if ( intersection(s1,s2,x1,y1,x2,y2,se1->centre,seuil) ) {
                        /* if intersection of v(s1,s2) with v(a,b) make
                           4 entries in table of intersection      */
                 ret = tin(obj,s1,s2,0,a+offset,nv,b+offset,vois(b,a,se2->vois));
                 ret = tin(obj,a+offset,b+offset,0,s1,vois(s1,s2,se1->vois),
                                              s2,vois(s2,s1,se1->vois));
                 if(ret == TNODE_OVERFLOW) 
                   return(TNODE_OVERFLOW);
                 bb = 1;      /* intersection found */
                 s1a = s1;    /* save Voronoi-edge which has been entrance */ 
                 s2a = s2;    /* in new V-cell */
                 v0 = 0;      /* no adjacent cells visited */
              }
             ++j;
        }
        pn = pn->next;
      }
      if (bb)                             /* if intersection found */
        p = newpoint(p,s1,*(se1->simp),j-1);    /* get new Voronoi-cell */
      else {                              /* no intersct. in cell p */
        try(obj,&p,&p1,&v0,a,b,&s1a,&s2a,offset,&error,&found);
        if (found) {
          ret = tin(obj,s1a,s2a,0,a+offset,nv,b+offset,vois(b,a,se2->vois));
          ret = tin(obj,a+offset,b+offset,0,s1a,vois(s1a,s2a,se1->vois),
                                       s2a,vois(s2a,s1a,se1->vois));
          if(ret == TNODE_OVERFLOW) 
            return(TNODE_OVERFLOW);
        }
      }
 
    } while ( (p != a1) && ! error );
                 /* until we arrive in cell of point a1 or error occured */
    if (error) {             /* error */
      DEBUGF(("   error at intersection-search\n"));
      DEBUGF(("   start at other end\n"));
      /* above we started with the intersection search in point b1 and came
        to the cell p where no intersection was found.To find missing
        intersections,we start now in cell of a1.Because we get now the
        intersections in the inverse order,we store them in array 'help' */
      ii = 0;
      s1a = 0;
      s2a = 0;
      error = 0;
      v0 = 0;   /* number of visited adjacent Voronoi-cells */
      p = a1;    /* this time start in a1 */
      do {   /* let's have a look at all triangles having point p in common */
        pn = (*(se1->simplist))[p-1];
        bb = 0;          /* no intersection found */
        while ( (pn != NULL) && !bb) {
                  /* while there are still triangles containing p and
                     no intersection found visit all pairs (s1,s2) of adjacent
                     triangles having p in common  */
          s1 = pn->simp;
          j = 0;
          while ( (j<3) && !bb) {
            s2 = (*(se1->vois))[s1-1][j];
            if ((s2 != 0)  && (((s1 != s2a) || (s2 != s1a))&&
                ((s1 != s1a) || (s2 != s2a))) && connected(p,s2,se1->simplist))
              if ( intersection(s1,s2,x1,y1,x2,y2,se1->centre,seuil) ) {
                       /* if intersection of v(s1,s2) with v(a,b) save s1,s2 */
                if (ii >= Maxhelp) {
                  char *ptr;
                  DEBUGF(("   intsearch: realloc for help\n"));
                  Maxhelp = Maxhelp + 20;
                  ptr = (char *)help;
                  help = (int *)realloc(ptr, Maxhelp*2*sizeof(int));
                  ERRCHK(help, "realloc failed on help\n");
                }
                *(help + ii*2) = s1;
                *(help + ii*2 + 1) = s2;
                ii++;

                bb = 1;      /* intersection found */
                s1a = s1;    /* save Voronoi-edge which has been entrance */ 
                s2a = s2;    /* in new V-cell */
                v0 = 0;      /* no adjacent cells visited */
              }
              ++j;
          }
          pn = pn->next;
        }
        if (bb)                             /* if intersection found */
          p = newpoint(p,s1,*(se1->simp),j-1);    /* get new Voronoi-cell */
        else {                              /* no intersct. in cell p */
          try(obj,&p,&p1,&v0,a,b,&s1a,&s2a,offset,&error,&found);
          if (found) {
            if (ii >= Maxhelp) {
              char *ptr;
              DEBUGF(("   intsearch: realloc for help\n"));
              Maxhelp = Maxhelp + 20;
              ptr = (char *)help;
              help = (int *)realloc(ptr, Maxhelp*2*sizeof(int));
              ERRCHK(help, "realloc failed on help\n");
            }
            *(help + ii*2) = s1a;
            *(help + ii*2 + 1) = s2a;
            ii++;
          }
        }
      } while ( (p != b1) && ! error );
                 /* until we arrive in cell of point b1 or error occured */

      for ( k=ii-1 ; k>=0 ; --k) {
        /* for each intersection we get 4 entries in table of intersections: */
        s1 = *(help + k * 2 );
        s2 = *(help + k * 2 + 1 );
        ret = tin_test(obj,s1,s2,0,a+offset,nv,b+offset,vois(b,a,se2->vois));
        ret = tin_test(obj,a+offset,b+offset,0,s1,vois(s1,s2,se1->vois),
                                          s2,vois(s2,s1,se1->vois));
        if(ret == TNODE_OVERFLOW) 
          return(TNODE_OVERFLOW);
      }
    }             /* error */
  }      /* a1=b1 */
  return(OK);
}    /* intesarch */




/* intersection */
/******************************************************************************/


int intersection(int p1, int q1, double x1, double y1, double x2, double y2, Centre (*centre), double intseuil)

/*******************************************************************************
* intersection test of line p1,q1 (coordinates in centre) with line          *
*   (x1,y1),(x2,y2).                                                           *
*                                                                              *
*  INPUT   : p1,q1 :  2 adjacent triangles of plane 1;                         *
*            x1,y1 :  coordinates of a centre of a triangle in plane 2;        *
*            x2,y2 :  coordinates of a centre of a triangle in plane 2;        *
*                          ( triangle adjacent to triangle of x1,y1 )          *
*            centre : list of centres of triangles plane 1;                    *
*            intseuil:threshold for intersection test;                         *
*  OUTPUT  : returns 1 if Voronoi-edge of triangles p1,q1 intersect with       *
*                      line (x1,y1)(x2,y2);                                    *
*                    0 else;                                                   *
*******************************************************************************/
{
double a11,a12,a21,a22,b1,b2,det,l1,l2;
int b;


a11 = (*centre)[q1-1][0] - (*centre)[p1-1][0];
a12 = x1 - x2;
 b1 = x1 - (*centre)[p1-1][0];
a21 = (*centre)[q1-1][1] - (*centre)[p1-1][1];
a22 = y1 - y2;
 b2 = y1 - (*centre)[p1-1][1];
det = a11*a22 - a12*a21;

if (fabs(det) > 20.0*intseuil)    /* lines not parallel */
  {
   l1 = (b1*a22 - a12*b2)/det;
   l2 = (a11*b2 - b1*a21)/det;
   if( (l1>intseuil) && (l1<1-intseuil) && (l2>intseuil) && (l2<1-intseuil) )
     b = 1;
   else
     b = 0;
  }
else
  b = 0;
return(b);
}




int newpoint(int p, int s1, Simp nsimp, int nv)

/*******************************************************************************
* returns the 2-nd common point of 2 adjacent triangles.                       *
*                                                                              *
*  INPUT  : p :  a point belonging to triangle s1 and his neighbour number nv; *
*           s1 : a triangle;                                                   *
*           nv : number of a neighbour of s1   (nv = 0,1 or 2);                *
*  OUTPUT : returns the other common point of s1 and neighbour nv;             *
*******************************************************************************/
{
  int nv1, nv2;
  switch(nv) {
    case 0: nv1 = 1; nv2 = 2; break;
    case 1: nv1 = 2; nv2 = 0; break;
    case 2: nv1 = 0; nv2 = 1; break;
  }
  if ( nsimp[s1-1][nv1] == p )
    return(nsimp[s1-1][nv2]);
  else
    return(nsimp[s1-1][nv1]);
}



int vois(int s, int sn, Simp (*nvois))

/*******************************************************************************
* returns position of a adjacent triangle                                      *
*                                                                              *
*  INPUT  : s,sn :  2 adjacent triangles;                                      *
*           nvois : list of adjacent triangles;                                *
*  OUTPUT : returns position of sn to s ( sn is 0,1-st or 2-nd neighbour of s )*
*******************************************************************************/
{
  if ((*nvois)[s-1][0] == sn) return(0);
  if ((*nvois)[s-1][1] == sn) return(1);
  return(2);
}




int tin(Object *obj, int s1, int s2, int sx, int s3, int nv3, int s4, int nv4)
{
  Tnode *pnew;

  if (obj->it_ptr >= obj->it_max) {
    return(TNODE_OVERFLOW);
    /*realloc_slice(obj, Max_increment);*/
  }
  pnew = obj->it_ptr++;
  pnew->next = (*(obj->intable))[s3-1][nv3];
  pnew->s1 = s1;
  pnew->s2 = s2;
  pnew->sx = sx;
  (*(obj->intable))[s3-1][nv3] = pnew;
  (*(obj->intable))[s4-1][nv4] = pnew;
  return(OK);
} /* end tin */


int tin_test(Object *obj, int s1, int s2, int sx, int s3, int nv3, int s4, int nv4)

/*******************************************************************************
*  inserts a new node of type tnode at the beginning of the queue if node      *
*  not already exists.                                                         *
*******************************************************************************/
{
  Tnode *pn;

  pn = (*(obj->intable))[s3-1][nv3];
  while ( (pn != NULL) ) {
    if ( ((pn->s1 != s1)||(pn->s2 != s2))&&((pn->s2 != s1)||(pn->s1 != s2)) )
      pn = pn->next;
    else {
      pn->sx = sx;
      return(OK);
    }
  }
  if (obj->it_ptr >= obj->it_max) {
    return(TNODE_OVERFLOW);
    /*realloc_slice(obj, Max_increment);*/
  }
  pn = obj->it_ptr++;
  pn->next = (*(obj->intable))[s3-1][nv3];
  pn->s1 = s1;
  pn->s2 = s2;
  pn->sx = sx;
  (*(obj->intable))[s3-1][nv3] = pn;
  (*(obj->intable))[s4-1][nv4] = pn;
  return(OK);
} /* end tin_end */



void arete1(int s1, int s2, Simp (*nsimp), Simp (*nvois), int *p1, int *p2)

/*******************************************************************************
*  finds the 2 common points of 2 adjacent triangles                           *
*                                                                              *
*  INPUT  : s1,s2 :  2 adjacent triangles;                                     *
*           nsimp :  list of triangles;                                        *
*           nvois :  list of adjacent triangles;                               *
*  OUTPUT : p1,p2 :  the 2 common points of s1 and s2.                         *
*******************************************************************************/
{
  int k;

  k = vois(s1,s2,nvois);
  switch (k) {
    case 0:   *p1 = (*nsimp)[s1-1][1];
              *p2 = (*nsimp)[s1-1][2];
              break;
    case 1:   *p1 = (*nsimp)[s1-1][2];
              *p2 = (*nsimp)[s1-1][0];
              break;
    case 2:   *p1 = (*nsimp)[s1-1][0];
              *p2 = (*nsimp)[s1-1][1];
              break;
  }
}

void sxin(Object *obj, int s, int nv, int s1, int s2, int sx)
/*******************************************************************************
*  inserts in intersection-table at intersection of voronoi-                   *
*   line belonging to tetrahedra (s,neighbour nv of s) with voronoi-           *
*   line belonging to tetrahedra (s1,s2) the number of the                     *
*   tetrahedron sx (type t12)                                                  *
*                                                                              *
*  INPUT :  s :    triangle of plane 1;                                        *
*           nv :   neighbour number nv of s;                                   *
*           s1,s2: 2 adjacent triangles in plane 2;                            *
*           sx :   number of a tetrahedron of type t12 belonging to intersection
*                  of s,neighbour nv of s / s1,s2;                             *
*  OUTPUT : intable : sx is written in the node representing the intersection  *
*                     s,neighbour nv of s / s1,s2 .                            *
*******************************************************************************/
{
  Tnode *pn;

  pn = (*(obj->intable))[s-1][nv];
  while(pn != NULL) {
   if ( ((s1==pn->s1) && (s2==pn->s2)) || ((s1==pn->s2) && (s2==pn->s1)) ) {
     pn->sx = sx;
     break;
   }
  pn = pn->next;
  }
}


void con(int p, int t1, int t2, int (*nsimp4)[4], int (*nvois4)[4])

/*******************************************************************************
*  connects in the list of adjacent tetrahedra the 2 tetrahedra t1,t2          *
*                                                                              *
*  INPUT :    p :    a common point in plane 2 of tetrahedra t1 and t2;both of *
*                    type t12.                                                 *
*           t1,t2 :  2 adjacent tetrahedra of type t12 having a common edge    *
*                    in plane 1;                                               *
*           nsimp4 : list of tetrahedra;                                       *
*  OUTPUT : nvois4 : list of adjacent terahedra is updated.                    *
*******************************************************************************/
{
  if (nsimp4[t1-1][0] == p)
    nvois4[t1-1][1] = t2;
  else
    nvois4[t1-1][0] = t2;
}



int vertex(int p, int s, Simp nsimp)

/******************************************************************************
* looks if point p is a vertex of triangle s                                  *
*                                                                             *
* INPUT :  p :   point;                                                       *
*          s :   triangle;                                                    *
*          nsimp:list of triangles;                                           *
* OUTPUT : returns 1 if p is a vertex of s;                                   *
*                  0 else;                                                    *
******************************************************************************/
{ if ((nsimp[s-1][0] == p) || (nsimp[s-1][1] == p) || (nsimp[s-1][2] == p))
    return(1);
  else
    return(0);
}



void get2simp(int p1, int p2, List (*simplist), Simp (*nsimp), int *s1, int *s2)

/******************************************************************************
* Looks for the 2 triangles having points p1 and p2 in common.                *
*   An error occurs if p1 and p2 are points of the frame.                     *
*                                                                             *
*  INPUT :  p1,p2 :  2 adjacent points;                                       *
*           simplist:list of triangles with a common point;                   *
*           nsimp :  list of triangles;                                       *
*  OUTPUT : s1,s2 :  2 triangles having p1 and p2 in common.                  *
******************************************************************************/
{
  Snode *pn;

  pn = (*simplist)[p1-1];
  while ( ! vertex(p2,pn->simp,*nsimp) )
    pn = pn->next;
  *s1 = pn->simp;
  pn = pn->next;
  while ( ! vertex(p2,pn->simp,*nsimp) )
    pn = pn->next;
  *s2 = pn->simp;
}



void get3simp(int p1, int p2, int p3, List (*simplist), Simp (*nsimp), int *s)

/*****************************************************************************
* gets triangle consisting of p1,p2,p3                                       *
*                                                                            *
*  INPUT :  p1,p2,p3 : 3 adjacent points;                                    *
*           simplist : list of triangles having a common point;              *
*           nsimp :    list of triangles;                                    *
*  OUTPUT:  s :        triangle consisting of p1,p2,p3.                      *
*****************************************************************************/
{
  Snode *pn;

  pn = (*simplist)[p1-1];
  while ( ! vertex(p2,pn->simp,*nsimp) )
    pn = pn->next;
  while ( ! vertex(p2,pn->simp,*nsimp) || ! vertex( p3,pn->simp,*nsimp) )
    pn = pn->next;
  *s = pn->simp;
}


void otcadr(Slice *slice)
/*c enleve le cadre dont les sommets commencent a icadr
c i.e. met a 0 le 1er elt des simplexes touchant le cadre et met a
c jour nvois*/
{
  register int i,j;
  int t1,t2,t12;
  int nbor;
  Simp4 *nsimp, *nvois;

  nsimp = slice->simp;
  nvois = slice->vois;
  t1 = slice->nb_t1;
  t2 = slice->nb_t2;
  t12 = slice->nb_t12;
  for (i=0 ; i<t1 ; i++) 
    for (j=0 ; j<4 ; j++) 
      if( (*nsimp)[i][j] > Maxvertex-4 ) {
        (*nsimp)[i][0] = 0;
        slice->nb_t1--;
        break;
      }
  for (i=t1 ; i<t1+t2 ; i++) 
    for (j=0 ; j<4 ; j++) 
      if( (*nsimp)[i][j] > Maxvertex-4 ) {
        (*nsimp)[i][0] = 0;
        slice->nb_t2--;
        break;
      }
  for (i=t1+t2 ; i<t1+t2+t12 ; i++) 
    for (j=0 ; j<4 ; j++) 
      if( (*nsimp)[i][j] > Maxvertex-4 ) {
        (*nsimp)[i][0] = 0;
        slice->nb_t12--;
        break;
      }
  for (i=0 ; i<slice->nbs ; i++) 
    for (j=0 ; j<4 ; j++) {
      nbor = (*nvois)[i][j];
      if( (nbor != 0) && (*nsimp)[nbor-1][0] == 0 ) 
        (*nvois)[i][j] = 0;
      }
}

void tasse(Slice *slice)
/*c  elimine les simplexes superflus dont le 1er elt=0
c  met a jour nbs et nvois
c newnum tab. de travail de dim.>=nbs */
{
  int *newnum;

  int nb0, i, j;
  Simp4 *nsimp, *nvois;
  unsigned mem_size;

  mem_size = slice->nbs * sizeof(int);
  newnum = (int *)malloc(mem_size);
  if (newnum == NULL) {
    fprintf(stderr,"tasse: no memory (need %dk)\n",slice->nbs*sizeof(int)/1024);
    fflush(stderr);
    exit(1);
  }
  /*DEBUGF(("tasse:  %dk allocated\n",slice->nbs*sizeof(int)/1024));*/
  for (i=0 ; i<slice->nbs ; i++) 
    *(newnum+i) = 0; 
  nsimp = slice->simp;
  nvois = slice->vois;

  nb0=0;
  for (i=0 ; i<slice->nbs ; i++) {
    if((*nsimp)[i][0] == 0)  nb0++;
    else {
      *(newnum+i) = i-nb0;
      for (j=0 ; j<4 ; j++) {
        (*nsimp)[*(newnum+i)][j] = (*nsimp)[i][j];
        (*nvois)[*(newnum+i)][j] = (*nvois)[i][j];
      }
    }
  } 
  slice->nbs = slice->nbs-nb0;
  for (i=0 ; i<slice->nbs ; i++) 
    for (j=0 ; j<4 ; j++) 
      if((*nvois)[i][j] > 0) (*nvois)[i][j]= *(newnum + (*nvois)[i][j]-1)+1;

  free((char *)newnum);
  /*DEBUGF(("tasse:  %dk free\n",mem_size/1024));*/
}
   

void intext(Object *obj)
   /* ityps = T1,T2,T12, | ELIM1 */
{
  Slice     *S;
  X_section *s1,*s2;
  Ityps     *ityps;
  int i,j,j1,m1,m2,typ,count;


  S = obj->slice;
  ityps = S->ityps;
  s1 = obj->s1;
  s2 = obj->s2;
  
  for (i=0 ; i< S->nb_t1; i++) {
    (*ityps)[i] = T1;
    count = 0;
    for (j=0, j1=1 ; j<3 ; j++, j1=(j1==2)?0:j1+1) {
      m1 = (*(S->simp))[i][j];
      m2 = (*(S->simp))[i][j1];
      typ = test_edge_new(m1,m2,*(s1->point),*(s1->succ),*(s1->pred),s1);
      if(typ < 0) {
        (*ityps)[i] = T1 | ELIM;
        count = 1;
        break;
      }
      count = count + typ;
    } 
    if( count == 0 ) {
      DEBUGF(("   3-vertex contour pt %d  ",m1));
      if (!Isclockwise(m1,s1->point,s1->succ,3)) {
        (*ityps)[i] = T1 | ELIM;
        DEBUGF(("ccw\n"));
      }
      else DEBUGF(("cw\n"));
    }
  }

  for (i=S->nb_t1 ; i< S->nb_t1 + S->nb_t2; i++) {
    (*ityps)[i] = T2;
    count = 0;
    for (j=0, j1=1 ; j<3 ; j++, j1=(j1==2)?0:j1+1) {
      m1 = (*(S->simp))[i][j];
      m2 = (*(S->simp))[i][j1];
      typ = test_edge_new(m1,m2,*(s2->point),*(s2->succ),*(s2->pred),s2);
      if(typ < 0) {
        (*ityps)[i] = T2 | ELIM; 
        count = 1;
        break;
      }
      count = count + typ;
    } 
    if( count == 0 ) {
      DEBUGF(("   3-vertex contour pt %d  ",m1));
      if (!Isclockwise(m1,s2->point,s2->succ,3)) {
        (*ityps)[i] = T2 | ELIM;
        printf(("ccw\n"));
      }
      else DEBUGF(("cw\n"));
    }
  }

  for (i=S->nb_t1+S->nb_t2 ; i< S->nbs; i++) {
    (*ityps)[i] = T12;
      m1 = (*(S->simp))[i][0];
      m2 = (*(S->simp))[i][1];
      if(test_edge_new(m1,m2,*(s2->point),*(s2->succ),*(s2->pred),s2) < 0) {
        (*ityps)[i] = T12 | ELIM;
        continue;
      }
      m1 = (*(S->simp))[i][2];
      m2 = (*(S->simp))[i][3];
      if(test_edge_new(m1,m2,*(s1->point),*(s1->succ),*(s1->pred),s1) < 0)
        (*ityps)[i] = T12 | ELIM;
    } 
} /* intext */


int test_edge_new(int m1, int m2, Coord point, Order succ, Order pred, X_section *sec)
{
  double p[2], s[2], k[2];
  double sp,sk,kp;

  /* internal point? */
  if( ((m1 > Maxpoint+Maxplus)  && (m1 <= Maxpoint+Maxplus + sec->nb_int)) ||
      ((m2 > Maxpoint+Maxplus)  && (m2 <= Maxpoint+Maxplus + sec->nb_int)) ) {
    return(1);  /*inside C*/
  }
  if( succ[m1-1] != m2 && succ[m2-1] != m1 ) {
    s[0] = point[succ[m1-1]-1][0] - point[m1-1][0];
    s[1] = point[succ[m1-1]-1][1] - point[m1-1][1];
    k[0] = point[m2-1][0] - point[m1-1][0];
    k[1] = point[m2-1][1] - point[m1-1][1];
    p[0] = point[pred[m1-1]-1][0] - point[m1-1][0];
    p[1] = point[pred[m1-1]-1][1] - point[m1-1][1];
    sp = s[0]*p[1] - s[1]*p[0];
    sk = s[0]*k[1] - s[1]*k[0];
    kp = k[0]*p[1] - k[1]*p[0];

    if( sp >= 0) {
      if ( sk > 0 && kp > 0 ) 
        return(-1);
      else
        return(1);
    }
    else {
      if ( sk < 0 && kp < 0 ) return(1);
      else return(-1);
    }
  }
  else return(0);
}


void deplacer(int nb, int x, double length, double *dx, double *dy)
{
  double b,vx,vy;


  if (nb < 10) { vx = nb ; vy = 10.;}
  else
    if (nb < 30) { vx = 10. ; vy = 19. - nb; }
  b = sqrt( vx*vx + vy*vy );
  *dx = vx/b * length;
  *dy = vy/b * length;
  if (x == 1)
  { /* the other way round,move in opposite direction */
   *dx = -(*dx);
   *dy = -(*dy);
   }
  DEBUGF( ("   dx,dy %e  %e\n",*dx,*dy));
}


void cospherique(Object *obj, int *nbcos, int i, int *p1, int *p2, int *p3, X_section *se1, X_section *se2, int start, int x)

/******************************************************************************
* tries at most 30times to shift the centre of triangle i.After a successfull *
* shift we search for the intersections of the shifted Voronoi-edges and write*
* them in the list of extra intersections.We return the new nearest point to  *
* the shifted centre.                                                         *
******************************************************************************/
{
  double dx=0.0, dy=0.0;       /* vector to move the centre */
   int s1,s2,j,k;
   int offset1,offset2;
   int p11,p22,p33;
   int nbcos1,p44,p55,p66;
   int nb;
   REAL nx,ny;
   double distance(int p1, double px, double py, Coord (*point));
   REAL c[2];
   double seuil;

   seuil = obj->seuil[4];
   /*printf("seuil : %f\n",seuil);
   printf("simplexe %d-- points %d %d %d    vois %d %d %d \n",i+1,nsimp1[i][0],
        nsimp1[i][1],nsimp1[i][2],nvois1[i][0],nvois1[i][1],nvois1[i][2]);
   printf("p1,p2,p3 %d %d %d\n",*p1,*p2,*p3);
   */
   c[0] = (*(se1->centre))[i][0];
   c[1] = (*(se1->centre))[i][1];

   nb = 0;                      /* number of try */
   if (x == 0) {                /* we are constructing t1 */
     offset1 = se1->nbs;
     offset2 = 0;
   }
   else {                  /* constructing t2 */
     offset1 = 0;
     offset2 = se2->nbs;
   }
   if (*nbcos == 2) {      /* 5 cospheric points */
     /* p1,p2 are 2 points having the same distance from centre of triangle
     i.If both p1 and p2 are points of the frame,there is an intersection
     with an infinite V-edge.We do nothing in this case  */
     if ( (*p1 < Maxvertex-3) || (*p2 < Maxvertex-3) ) {
       get2simp(*p1,*p2,se2->simplist,se2->simp,&s1,&s2);
       /* printf("s1,s2 : %d %d\n",s1,s2);
       printf("centre s1 : %f   centre s2 : %f\n",
                      centre2[s1-1][0],centre2[s2-1][0]);
       printf("            %f               %f\n",
                      centre2[s1-1][1],centre2[s2-1][1]);
       printf("centre i  : %f\n",centre1[i][0]);
       printf("            %f\n",centre1[i][1]);
       */
       do { /* move centre of i */
         deplacer(nb,x,seuil*2.0,&dx,&dy);
         c[0] = (*(se1->centre))[i][0]+dx;
         c[1] = (*(se1->centre))[i][1]+dy;
         /* now try with moved centre */
         *nbcos = nearest_p(c,se2,start, MINSEUIL*20.0,&p11,&p22,&p33,0);
         ++nb;    /* increment number of try */
       } while ((*nbcos > 1) && (nb < 29));  /* at most 30 tries */

       if (*nbcos > 1) 
         printf("   no good direction found\n");
       else { /* success, search intersections of moved V-edges */
         DEBUGF(("   successfully moved \n"));
         *p1 = p11;   /* but return new nearest point */

         for ( j=0 ; j<3 ; ++j) {            /* search intersections */
           if ( (*(se1->vois))[i][j] == 0 ) continue;
           nx = (*(se1->centre))[(*(se1->vois))[i][j]-1][0]+dx;
           ny = (*(se1->centre))[(*(se1->vois))[i][j]-1][1]+dy;
             if ( intersection(s1,s2,c[0],c[1],nx,ny,se2->centre,MINSEUIL) ) {
               if(obj->e_ptr >= Max_extra) {
                 char *ptr;
                 DEBUGF(("   max_extra : realloc at %d\n", obj->e_ptr));
                 Max_extra = Max_extra + 100;
                 ptr = (char *)realloc(obj->extralist, Max_extra*4*sizeof(int));
                 ERRCHK(ptr, "realloc for max_extra failed\n");
                 obj->extralist = (Elist *)ptr;
               }
               (*(obj->extralist))[obj->e_ptr][0] = s1+offset1; 
               (*(obj->extralist))[obj->e_ptr][1] = s2+offset1; 
               (*(obj->extralist))[obj->e_ptr][2] = i+1+offset2; 
               (*(obj->extralist))[obj->e_ptr++][3] = (*(se1->vois))[i][j]+offset2; 
               DEBUGF(("   extra:  %d %d %d %d\n",s1+offset1,
                 s2+offset1,i+1+offset2,(*(se1->vois))[i][j]+offset2));
             }
          }     /*  for   */
       }     /*  else  */
     }    /* if cadre */
     else {
       DEBUGF(("   intersection of infinit V-edge\n"));
     }

   }    /* cas 2 */
   else {  /*  nbcos == 3  */
     /* get triangle whose centre is equal to the centre of i */
     get3simp(*p1,*p2,*p3,se2->simplist,se2->simp,&s1);
     if ( ( fabs((*(se1->centre))[i][0]-(*(se2->centre))[s1-1][0]) > MINSEUIL*10.0) ||
       (fabs((*(se1->centre))[i][1]-(*(se2->centre))[s1-1][1])>MINSEUIL*10.0)) {
       *nbcos = nearest_p(&((*(se1->centre))[i][0]),se2,start,MINSEUIL*40.0,&p11,&p22,&p33,0);
       nbcos1 = nearest_p( &((*(se2->centre))[s1-1][0]),se1,
                         (*(se1->simp))[i][0],MINSEUIL*40.0,&p44,&p55,&p66,0 );
       while( ((*nbcos>1) || (nbcos1>1)) && (nb<29) ) {
         deplacer( nb,x,MINSEUIL*50.0,&dx,&dy );
         c[0] = (*(se2->centre))[s1-1][0]-dx;
         c[1] = (*(se2->centre))[s1-1][1]-dy;
         nbcos1 = nearest_p( c,se1,(*(se1->simp))[i][0],MINSEUIL*40.0,&p44,&p55,&p66,0 );
         c[0] = (*(se1->centre))[i][0]+dx;
         c[1] = (*(se1->centre))[i][1]+dy;
         *nbcos = nearest_p( c,se2,start, MINSEUIL*40.0,&p11,&p22,&p33,0 );
         ++nb;
       }
     }
     else  /*  centre1 = centre2  */
       do { /* get vector for moving centre */
         deplacer(nb,x,seuil*2.0,&dx,&dy);
         /* now try with moved centre */
         c[0] = (*(se2->centre))[s1-1][0]-dx;
         c[1] = (*(se2->centre))[s1-1][1]-dy;
         nbcos1 = nearest_p(c,se1, (*(se1->simp))[i][0],MINSEUIL*40.0,&p44,&p55,&p66,0 );
         c[0] = (*(se1->centre))[i][0]+dx;
         c[1] = (*(se1->centre))[i][1]+dy;
         *nbcos = nearest_p(c,se2,start,MINSEUIL*40.0,&p11,&p22,&p33,0);
         ++nb;    /* increment number of try */
       } while ( ((*nbcos>1) || (nbcos1>1)) && (nb<29) );  /* at most 30 tries */
     if ( *nbcos > 1 )
       printf("   no good direction found\n");
     else {
       DEBUGF(("   successfully moved\n"));
       *p1 = p11;     /* but return new nearest point */
       if ( x==0 )
         /* we search the intersections only one time,(x=0) else we
         would get every int. twice  */
         for ( j=0 ; j<3 ; ++j) {
 /*!!*/    if( (*(se1->vois))[i][j] == 0 ) continue;
           nx = (*(se1->centre))[(*(se1->vois))[i][j]-1][0]+dx;
           ny = (*(se1->centre))[(*(se1->vois))[i][j]-1][1]+dy;
           for ( k=0 ; k<3 ; ++k) {
   /*!!*/    if( (*(se2->vois))[s1-1][k] == 0 ) continue;
            /*if ( (*(se1->vois))[i][j] != 0 && (*(se2->vois))[s1-1][k] != 0 )*/
             if (intersection(s1,(*(se2->vois))[s1-1][k],c[0],c[1],nx,ny,
                               se2->centre,MINSEUIL) ) {
               if(obj->e_ptr >= Max_extra) {
                 char *ptr;
                 DEBUGF(("   max_extra : realloc at %d\n", obj->e_ptr));
                 Max_extra = Max_extra + 100;
                 ptr = (char *)realloc(obj->extralist, Max_extra*4*sizeof(int));
                 ERRCHK(ptr, "realloc for max_extra failed\n");
                 obj->extralist = (Elist *)ptr;
               }
               (*(obj->extralist))[obj->e_ptr][0] = s1+offset1; 
               (*(obj->extralist))[obj->e_ptr][1] = (*(se2->vois))[s1-1][k]+offset1; 
               (*(obj->extralist))[obj->e_ptr][2] = i+1+offset2; 
               (*(obj->extralist))[obj->e_ptr++][3] = (*(se1->vois))[i][j]+offset2; 
               DEBUGF(("   extra:  %d %d %d %d\n",
                            s1+offset1,(*(se2->vois))[s1-1][k]+offset1,
                            i+1+offset2,(*(se1->vois))[i][j]+offset2));
             }
           }   /* for k */
         }   /* for j */
     }   /*   else  */
   }     /* cas 3 */
}        /* cospherique */


int searchextra(Object *obj, int p, int a, int b, int *s1a, int *s2a, int *found)
/******************************************************************************
* If no intersection with Voronoi-edge of a,b was found in cell of point p,   *
*   we look in the list of extra intersections.                               *
******************************************************************************/
{
  int bb;
  int s1,s2;
  int pn;



  /* each node of extralist consists of 2 pairs of adjacent triangles
   corresponding to 2 Voronoi-edges that intersect.Thus we compare
   each pair of each node to the pair (a,b).If we find such a pair,we look
   if the other pair represents a Voronoi-edge of the cell of point p. */

  *found = 0;
  bb = 0;                     /* no intersection found */
  pn = 0;             /* start at 1-st intersection in extralist */

  while ( (pn < obj->e_ptr) && !bb ) {
                 /* there are still intersections and nothing found */
    s1 = (*(obj->extralist))[pn][2];
    s2 = (*(obj->extralist))[pn][3];
      /* look at 1-st pair of adjacent triangles */
    if ( ( ((*(obj->extralist))[pn][0] == a && (*(obj->extralist))[pn][1] == b) ||
         ((*(obj->extralist))[pn][1] == a && (*(obj->extralist))[pn][0] == b)) &&
          vertex(p,s1,*(obj->s1->simp)) && vertex(p,s2,*(obj->s1->simp)) ) {
         /* save Voronoi-edge that have been entrance in new cell */
         *s1a = s1;
         *s2a = s2;
         /* delete node */
         (*(obj->extralist))[pn][0] = 0;
         (*(obj->extralist))[pn][2] = 0;
         bb = 1;       /* intersection found */
    }
    else {
      s1 = (*(obj->extralist))[pn][0];
      s2 = (*(obj->extralist))[pn][1];
      /* look at 2-nd pair */
      if((((*(obj->extralist))[pn][2]==a && (*(obj->extralist))[pn][3]==b) ||
          ((*(obj->extralist))[pn][3]==a && (*(obj->extralist))[pn][2]==b)) &&
         vertex(p,s1,*(obj->s1->simp)) && vertex(p,s2,*(obj->s1->simp)) ) {
          /* save Voronoi-edge that has been entrance in new cell */
          *s1a = s1;
          *s2a = s2;
          /* delete node */
          (*(obj->extralist))[pn][0] = 0;
          (*(obj->extralist))[pn][2] = 0;
          bb = 1;              /* intersection found */
     }
     else {
       pn++;         /* look at next node */
     }
   }       /* else */
 }    /*    while       */

 if (bb) {     /* intersection found */
   *found = 1;
   return ( newpoint(p,s1,*(obj->s1->simp),vois(s1,s2,obj->s1->vois)) );
 }
 else
  return (0);
}





int Isclockwise(int p, Coord (*point), Order (*succ), int nb)
{
        int p1;
        float area=0;
        int i;
        for(i=0,p1 = p ; i<nb ; i++,p1 = (*succ)[p1-1] )
                area+=((*point)[(*succ)[p1-1]-1][0] - (*point)[p1-1][0]) *
                      ((*point)[(*succ)[p1-1]-1][1] + (*point)[p1-1][1]);
        return area<0 ? 0 : area>0 ? 1 : -1;
}

int make_t12(Object *obj, Slice *S, char *mark)
{
  X_section *se1, *se2;
  Simp4 *nsimp4, *nvois4;
  int i,j,predi,predj;
  int p1,p2,q1,q2,pa,pe,pnw,pnw1;
  int p11,p22;
  int nv,nbs1,nbs2,s1,s2;
  int error;
  Tnode *pn,*pn1;
  int nbs4;
  int over, ret;

  se1 = obj->s1;
  se2 = obj->s2;
  nbs1 = se1->nbs;
  nbs2 = se2->nbs;
  nsimp4 = S->simp;
  nvois4 = S->vois;
  nbs4 = nbs1+nbs2;
  over = nbs1 + nbs2 + Max_t12;

  /* initialize list of adjacent tetrahedra with 0 */
  memset( (*nvois4), 0, 4*Max4*sizeof(int));
  memset( mark, 0, nbs2*sizeof(char));

  /* We start with tetrahedra of type t2.If their faces in plane 2 are
   neighbours and their points in plane 1 are the same,they are
   neighbours .If their Points in plane 1 are not the same,
   we create for each intersection of the V-edge dual to the adjacent faces
   in plane 2 a tetrahedron of type t12.Here the intersections are in the 
   right order.We get all the tetrahedra of type t12, all the neighbours of
   We get all the tetrahedra of type t12 , all the neighbours of
   the tetrahedra of type t2 and the neighbours of t12 with a common
   edge in plane 2.
  */



  error = 0;
  for (i=0; i<nbs2 ; ++i) {/* for all pairs of adjacent triangles in plane 2 */
    for (j=0 ; j<3 ; ++j) {
      nv = (*(se2->vois))[i][j]; 
      if ( nv != 0 && !mark[nv-1] ) {
        if ( (*nsimp4)[i+nbs1][3] == (*nsimp4)[nv+nbs1-1][3] ) {
          /* their 4-th point in plane 1 is the same,thus they are neighbours */
        (*nvois4)[i+nbs1][j]=nv+nbs1;
        (*nvois4)[nv+nbs1-1][vois(nv,i+1,se2->vois)] = i+nbs1+1;
        }
        else {
          /* we take all the intersections with the Voronoi-edge of triangles
            i, neighbour j  of i */
          pn = (*(obj->intable))[i+nbs1][j];
          predi = i+nbs1;
          predj = j;
          pa = (*nsimp4)[i+nbs1][3];            /* 4-th point of triangle i */
          pe = (*nsimp4)[nv+nbs1-1][3];         /* 4-th point of neighbour j */
          arete1(i+1,nv,se2->simp,se2->vois,&q1,&q2);
                                              /* q1,q2 is edge in plane 2 */
            /* we search a path of edges beginning in pa and ending in pe */
          while (pn != NULL) {
            arete1(pn->s1,pn->s2,se1->simp,se1->vois,&p1,&p2);
                                 /* p1,p2 is edge in plane 1 */
                                 /* now we must connect this edge properly */
            if (p1 == pa) pnw = p2;
            else
              if (p2 == pa) pnw = p1;
              else { /* there is missing an intersection */
                error = 0;  
                p11 = 0;
                p22 = 0;
                if ( pn->next != NULL ) { /*we have got more intersections*/
                  pn1 = pn->next;
                  arete1(pn->s1,pn->s2,se1->simp,se1->vois,&p11,&p22);
                                    /* p11,p22 is following edge in plane 1 */
                }
                if ( (p1 == p11)||(p1 == p22)||(p1 == pe) ) {
                  pnw = p1;
                  pnw1 = p2;
                }
                else
                  if ( (p2 == p11)||(p2 == p22)||(p2 == pe) ) {
                    pnw = p2;
                    pnw1 = p1;
                  }
                  else { /* more than one missing intersection. */
                    error = 1;
                    pa = p2;
                    pnw = p1;
                  }
                if ( ! error ) { /* only 1 missing tetrahedron,we can recompose it */
                  if (connected(pa,pnw1,se1->pointlist)) {
                    if ( (pa <= Maxvertex-4) || (pnw1 <= Maxvertex-4) ) {
                      /* they are not both points of the frame,thus there
                        exist 2 triangles having pa,pnw1 in common */
                      get2simp(pa,pnw1,se1->simplist,se1->simp,&s1,&s2);
                              /* insert the missing intersection */
                      ret = tin_test(obj, i+nbs1+1,nv+nbs1,nbs4+1,
                               s1,vois(s1,s2,se1->vois),
                               s2,vois(s2,s1,se1->vois) );
                      if(ret == TNODE_OVERFLOW) 
                        return(TNODE_OVERFLOW);
                    }
                    DEBUGF(("   missing tetrahedron: %d %d %d %d\n",q1,q2,pa,pnw1));
                      /* construction of the missing tetrahedron */
                    if (nbs4 >= over) {
                      return(TNODE_OVERFLOW);
                    }
                    (*nsimp4)[nbs4][0] = q1;
                    (*nsimp4)[nbs4][1] = q2;
                    (*nsimp4)[nbs4][2] = pa;
                    (*nsimp4)[nbs4][3] = pnw1;
                    /* connect it to its predecessor */
                    (*nvois4)[predi][predj] = nbs4+1;
                    (*nvois4)[nbs4][3] = predi+1;
                    predi = nbs4;
                    predj = 2;
                    ++nbs4;
                    pa = pnw1;
                  }
                  else
                    error = 1;   /* more than 1 missing intersection */
                } /* end if not error */
              } /* end missing intersection */
              /* insert the number of the new tetrahedron at other intersections 
                 representing it */
              sxin(obj,pn->s1,vois(pn->s1,pn->s2,se1->vois),i+nbs1+1,nv+nbs1,nbs4+1);
              sxin(obj,pn->s2,vois(pn->s2,pn->s1,se1->vois),i+nbs1+1,nv+nbs1,nbs4+1);
              /* make new tetrahedron */
              if (nbs4 >= over) {
                return(TNODE_OVERFLOW);
              }
              (*nsimp4)[nbs4][0] = q1;
              (*nsimp4)[nbs4][1] = q2;
              (*nsimp4)[nbs4][2] = pa;
              (*nsimp4)[nbs4][3] = pnw;
              /* connect it with its predecessor */
              (*nvois4)[predi][predj] = nbs4+1;
              (*nvois4)[nbs4][3] = predi+1;
              predi = nbs4;
              predj = 2;
              nbs4++;
              pa = pnw;
              pn = pn->next;      /* next intersection */
          }
          if (pa == pe) { /* connect last tetrahedron with final tetrahedron of type t2 */
            (*nvois4)[predi][predj]= nv+nbs1;
            (*nvois4)[nv-1+nbs1][vois(nv,i+1,se2->vois)]=predi+1; 
          }
          else {
            /* missing intersection at the end; we try to recompose tetrahedron */
            if (connected(pa,pe,se1->pointlist)) {
              if ( (pa <= Maxvertex-4) || (pe <= Maxvertex-4) ) {
                get2simp(pa,pe,se1->simplist,se1->simp,&s1,&s2);
                         /* insert missing intersection */
                ret = tin_test(obj, i+nbs1+1,nv+nbs1,nbs4+1,
                          s1,vois(s1,s2,se1->vois),s2,vois(s2,s1,se1->vois) );
                if(ret == TNODE_OVERFLOW) 
                  return(TNODE_OVERFLOW);
              }
              DEBUGF(("   missing tetrahedron: %d %d %d %d\n",q1,q2,pa,pe));
                      /* make missing tetrahedron */
              if (nbs4 >= over) {
                return(TNODE_OVERFLOW);
              }
              (*nsimp4)[nbs4][0] = q1;
              (*nsimp4)[nbs4][1] = q2;
              (*nsimp4)[nbs4][2] = pa;
              (*nsimp4)[nbs4][3] = pe;
              /* connect it to its predecessor */
              (*nvois4)[predi][predj] = nbs4+1;
              (*nvois4)[nbs4][3] = predi+1;
              predi = nbs4;
              predj = 2;
              ++nbs4;
              pa = pe;
              /* connect it to the final tetrahedron of type t2 */
              (*nvois4)[predi][predj]= nv+nbs1;
              (*nvois4)[nv-1+nbs1][vois(nv,i+1,se2->vois)]=predi+1; 
            }
            else
              error = 1;      /* more than one missing intersection */
          }  /* else */
        } /* else ?if */
      } /*if */
    } /* for j */
    mark[i] = 1;
  } /* for i */


  /*
    We continue with the tetrahedra of type t1.Thouse with the same
    point in plane 2 are neighbours; the others are conected with
    tetrahedra of type t12.This time the tetrahedra are not in the right order.
  */
  if (error) printf("   error at make_t12\n");


  memset( mark, 0, nbs1*sizeof(char));

  for (i=0 ; i<nbs1 ; ++i) {
    for (j=0 ; j<3 ; ++j) {/* for all pairs of adjacent triangles in plane 1*/
      nv = (*(se1->vois))[i][j];
      if ( (nv != 0) && !mark[nv-1] ) {
        if ( (*nsimp4)[i][3] == (*nsimp4)[nv-1][3] ) {
          /* their 4-th points in plane 2 are the same,thus they are neighb.*/
          (*nvois4)[i][j] = nv;
          (*nvois4)[nv-1][vois(nv,i+1,se1->vois)] = i+1;
        }
        else {
          pn = (*(obj->intable))[i][j]; /* pn points to intersections of V-edge (i,j) */
          pa = (*nsimp4)[i][3];      /* 4-th point in plane 2 of triangle i */
          pnw = (*nsimp4)[nv-1][3];  /* 4-th point of neighbour j */
          while (pn != NULL) {
            /* get common edge in plane 2 corresponding to intersection */
            arete1(pn->s1-nbs1,pn->s2-nbs1,se2->simp,se2->vois,&p1,&p2);
            if ( (p1 == pa) || (p2 == pa) ) {
              /* tetrahedron is neighbour of first t1,connect it */
              (*nvois4)[i][j] = pn->sx;
              con(pa,pn->sx,i+1,*nsimp4,*nvois4);
            }
            if ( (p1 == pnw) || (p2 == pnw) ) {
              /* tetrahedron is neighbour of final t1,connect it */
              (*nvois4)[nv-1][vois(nv,i+1,se1->vois)] = pn->sx;
              con(pnw,pn->sx,nv,*nsimp4,*nvois4);
            }
            if ( (p1 != pa) && (p1 != pnw) ) {
              /* search intersection having p1 in common */
              pn1 = (*(obj->intable))[i][j];
              while (pn1 != NULL) {
                if (pn != pn1) {
                  arete1(pn1->s1-nbs1,pn1->s2-nbs1,se2->simp,se2->vois,&p11,&p22);
                  if ( (p11 == p1) || (p22 == p1) ) { /* connect it */
                    con(p1,pn->sx,pn1->sx,*nsimp4,*nvois4);
                    con(p1,pn1->sx,pn->sx,*nsimp4,*nvois4);
                  }
                }
                pn1 = pn1->next;
              }            /* while2 */
            }

            if ( (p2 != pa) && (p2 != pnw) ) {
              /* search intersections having p2 in common */
              pn1 = (*(obj->intable))[i][j];
              while (pn1 != NULL) {
                if (pn != pn1) {
                  arete1(pn1->s1-nbs1,pn1->s2-nbs1,se2->simp,se2->vois,&p11,&p22);
                  if ( (p11 == p2) || (p22 == p2) ) {  /* connect it */
                    con(p2,pn->sx,pn1->sx,*nsimp4,*nvois4);
                    con(p2,pn1->sx,pn->sx,*nsimp4,*nvois4);
                  }
                }
                pn1=pn1->next;
              }      /* while3 */
            }

            pn = pn->next;    /* next intersection */
          }    /* while1 */
        }     /* else */
      }    /* if */
    }  /* for j */
    mark[i] = 1;
  }   /* for i */
  S->nb_t12 = nbs4-nbs1-nbs2; 
  S->nbs = nbs4; 
  return(OK);
}    /* end make_t12 */



void tri_3d(Object *obj)
{
  Slice *S;
  int i,j;
  int nbs44;
  int nbcos;                      /* number of cospheric points */
  int start, p1,p2,p3;
  X_section *s1, *s2;
  char *mark;
  int ret;

  s1 = obj->s1;
  s2 = obj->s2;
  S = obj->slice;

  alloc_slice(obj);

  /* if no triangle at all return */
  if ( s1->nbs < 8 || s2->nbs < 8 ) {
    free_intable(obj);
    return;
  }

  mark = (char *)malloc(Maxtri);
  ERRCHK(mark, "tri3D: no mem space\n");

  help = (int *)malloc(Maxhelp*2*sizeof(int));
  ERRCHK(help,"tri_3d: help - no mem space\n");

  nbs44 = 0;
  start = Maxvertex;

  /* for each triangle of plane 1 we make a tetrahedron of type t1.
   * The 4. point is the nearest point in plane 2 to its centre.
   */

  for (i=0 ; i<s1->nbs ; ++i) {
    (*(S->simp))[nbs44][0] = (*(s1->simp))[i][0];
    (*(S->simp))[nbs44][1] = (*(s1->simp))[i][1];
    (*(S->simp))[nbs44][2] = (*(s1->simp))[i][2];

    /* seach nearest point in plane 2 */
    nbcos = nearest_p(&((*(s1->centre))[i][0]),s2,start,obj->seuil[4],&p1,&p2,&p3,1);
    if (nbcos > 1) {
       /* 2 or 3 points have same distance */
       cospherique(obj,&nbcos,i,&p1,&p2,&p3,s1,s2,start,0);
    }
    (*(S->simp))[nbs44][3] = p1;
    ++nbs44;
    /* next time begin nearest point search at point just found */
    start = p1;
  }
  S->nb_t1 = s1->nbs;
  DEBUGF(("   # t1: %10d\n", S->nb_t1));

  /* for each triangle of plane 2 we make a tetrahedron of type t2.
   * The 4. point is the nearest point in plane 1 to its centre.
   */
  start = Maxvertex;
  for (i=0 ; i<s2->nbs ; ++i) {
    (*(S->simp))[nbs44][0] = (*(s2->simp))[i][0];
    (*(S->simp))[nbs44][1] = (*(s2->simp))[i][1];
    (*(S->simp))[nbs44][2] = (*(s2->simp))[i][2];

    /* search nearest point in plane 1 */
    nbcos = nearest_p(&((*(s2->centre))[i][0]),s1,start,obj->seuil[4],&p1,&p2,&p3,1);
    if (nbcos > 1) { 
       /* 2 or 3 points with same distance */
       cospherique(obj,&nbcos,i,&p1,&p2,&p3,s2,s1, start,1);
      }
    (*(S->simp))[nbs44][3] = p1;
    ++nbs44;
    /* next time begin nearest point search at point just found */
    start = p1;
  }
  S->nb_t2 = s2->nbs;
  DEBUGF(("   # t2: %10d\n", S->nb_t2));

  do {
    ret = OK;
    memset(mark, 1, s2->nbs);

    for (i=0 ; i<s1->nbs+s2->nbs ; i++) 
      for (j=0 ; j<3 ; ++j)
        (*(obj->intable))[i][j] = NULL;
    /*for each voronoi-line of plane 2 we search the intersections with
     *voronoi lines in plane 1.
     */

    for (i=0 ; i<s2->nbs ; ++i) {
      for (j=0 ; j<3 ; ++j) {
        /* for all pairs of adjacent triangles search intersections of their
         * corresponding Voronoi-edge
         */
        if (((*(s2->vois))[i][j] != 0) &&
                     (*(mark + (*(s2->vois))[i][j]-1)) )

          ret = intsearch(obj,i+1,(*(s2->vois))[i][j],j,(*(s2->centre))[i][0],
             (*(s2->centre))[i][1], (*(s2->centre))[(*(s2->vois))[i][j]-1][0],
             (*(s2->centre))[(*(s2->vois))[i][j]-1][1]);
          if (ret == TNODE_OVERFLOW) break;
      }
      if (ret == TNODE_OVERFLOW) break;
      *(mark+i) = 0;
    }

    if (ret == TNODE_OVERFLOW) {
      realloc_slice(obj, Max_increment);
    }
    else {
      ret = make_t12(obj,S,mark);
      if (ret == TNODE_OVERFLOW) {
        realloc_slice(obj, Max_increment);
      }
    }
  } while (ret != OK);

  free((char *)help);
  free((char *)mark);
  free_intable(obj);

  DEBUGF(("   # t12:%10d\n", S->nb_t12));

  otcadr(S);

  tasse(S);

  intext(obj);

  if(obj->flag.do_stretch)
    elim_stretched(obj);

  if(obj->flag.do_correct) 
    correct_h(obj);

  solid_test(obj,*(S->vois),*(S->ityps));

  if(obj->flag.do_correct)
    correct(obj);

  DEBUGF(("\n   # t1 :%10d\n", S->nb_t1));
  DEBUGF(("   # t2 :%10d\n", S->nb_t2));
  DEBUGF(("   # t12:%10d\n", S->nb_t12));
}

#define DIST(a,b) \
       (((b[0]-a[0])*(b[0]-a[0])+(b[1]-a[1])*(b[1]-a[1])) > max_stretch)


void elim_stretched(Object *obj)
{
  Slice *S;
  X_section *s1, *s2;
  unsigned char *mark;
  int *list;
  int first, last;
  int tri;
  int ok;
  int nb;
  
  int i, j;

  S = obj->slice;
  s1 = obj->s1;
  s2 = obj->s2;

  mark = (unsigned char *)malloc(S->nbs*sizeof(char));
  if (mark == NULL) {
    perror("malloc");
    return;
  }
  list = (int *)calloc(S->nbs, sizeof(int));
  if (list == NULL) {
    perror("calloc");
    return;
  }
  memset(mark, 0, S->nbs*sizeof(char));

  for (i = 0 ; i < S->nbs ; ++i)  {
    if (Elim(S,i)) continue;            /*skip eliminated*/
    if (*(mark+i)) continue;            /*been there*/
    *(list) = i;
    first = 0; 
    last = 1;
    *(mark + i) = 1;
    ok = FALSE;
    while (first < last) {
      tri = *(list + first++);
      if ( !ok && !slanted(S, s1, s2, tri)) ok = TRUE;
      /* take a look at nbors */
      for( j=0 ; j<4 ; ++j) {
        nb = (*(S->vois))[tri][j] - 1;
        if (nb == -1 || Elim(S,nb) || *(mark + nb)) continue;
        *(list + last++) = nb;
        *(mark + nb) = 1;
      }
    }
    if (!ok) {
      for (j=0 ; j<last ; j++)
        (*(S->ityps))[*(list+j)] = (*(S->ityps))[*(list+j)] | ELIM;
      DEBUGF(("   stretch:    %d tetrahedra deleted\n", last));
    }
  }
  free(list);
  free(mark);
}

int slanted(Slice *S, X_section *s1, X_section *s2, int t)
{
  float p[6][2];

  if (Is_t1(S,t)) {
    p[0][0] = (*(s1->point))[ (*(S->simp))[t][0]-1][0];
    p[0][1] = (*(s1->point))[ (*(S->simp))[t][0]-1][1];
    p[1][0] = (*(s1->point))[ (*(S->simp))[t][1]-1][0];
    p[1][1] = (*(s1->point))[ (*(S->simp))[t][1]-1][1];
    p[2][0] = (*(s1->point))[ (*(S->simp))[t][2]-1][0];
    p[2][1] = (*(s1->point))[ (*(S->simp))[t][2]-1][1];
    p[3][0] = (*(s2->point))[ (*(S->simp))[t][3]-1][0];
    p[3][1] = (*(s2->point))[ (*(S->simp))[t][3]-1][1];
    p[4][0] = ( p[0][0] + p[1][0] + p[2][0] ) / 3.0;
    p[4][1] = ( p[0][1] + p[1][1] + p[2][1] ) / 3.0;

    if ( DIST(p[0],p[3]) && DIST(p[1],p[3]) && DIST(p[2],p[3]) && DIST(p[4],p[3]))
      return(1);
    else
      return(0);
  }
  if (Is_t2(S,t)) {
    p[0][0] = (*(s2->point))[ (*(S->simp))[t][0]-1][0];
    p[0][1] = (*(s2->point))[ (*(S->simp))[t][0]-1][1];
    p[1][0] = (*(s2->point))[ (*(S->simp))[t][1]-1][0];
    p[1][1] = (*(s2->point))[ (*(S->simp))[t][1]-1][1];
    p[2][0] = (*(s2->point))[ (*(S->simp))[t][2]-1][0];
    p[2][1] = (*(s2->point))[ (*(S->simp))[t][2]-1][1];
    p[3][0] = (*(s1->point))[ (*(S->simp))[t][3]-1][0];
    p[3][1] = (*(s1->point))[ (*(S->simp))[t][3]-1][1];
    p[4][0] = ( p[0][0] + p[1][0] + p[2][0] ) / 3.0;
    p[4][1] = ( p[0][1] + p[1][1] + p[2][1] ) / 3.0;

    if ( DIST(p[0],p[3]) && DIST(p[1],p[3]) && DIST(p[2],p[3]) && DIST(p[4],p[3]))
      return(1);
    else
      return(0);
  }
  if (Is_t12(S,t)) {
    p[0][0] = (*(s2->point))[ (*(S->simp))[t][0]-1][0];
    p[0][1] = (*(s2->point))[ (*(S->simp))[t][0]-1][1];
    p[1][0] = (*(s2->point))[ (*(S->simp))[t][1]-1][0];
    p[1][1] = (*(s2->point))[ (*(S->simp))[t][1]-1][1];
    p[2][0] = (*(s1->point))[ (*(S->simp))[t][2]-1][0];
    p[2][1] = (*(s1->point))[ (*(S->simp))[t][2]-1][1];
    p[3][0] = (*(s1->point))[ (*(S->simp))[t][3]-1][0];
    p[3][1] = (*(s1->point))[ (*(S->simp))[t][3]-1][1];
    p[4][0] = ( p[0][0] + p[1][0] ) / 2.0;
    p[4][1] = ( p[0][1] + p[1][1] ) / 2.0;
    p[5][0] = ( p[2][0] + p[3][0] ) / 2.0;
    p[5][1] = ( p[2][1] + p[3][1] ) / 2.0;

    if ( DIST(p[0],p[2]) && DIST(p[1],p[2]) && DIST(p[4],p[2]) &&
         DIST(p[0],p[3]) && DIST(p[1],p[3]) && DIST(p[4],p[3]) &&
         DIST(p[0],p[5]) && DIST(p[1],p[5]) && DIST(p[4],p[5]) )
           return(1);
         else
           return(0);
  }
}
