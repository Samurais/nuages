#ifndef lint
static  char *sccsid = "@(#)mem_alloc.c	4.4 97/04/10";
#endif

/************************************************************************
 *									*
 * REPROS-REconstruction from Planar cROss-Sections  V 4.0  Sep 29 1993 *
 *									*
 *  module mem_alloc.c							*
 *  copyright (c) 1993 Bernhard Geiger					*
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *									*
 * Jan 25 1995 translated to ANSI C                                     *
 * Dec 29 1994 #ifndef VMS_NUAGES added					*
 * Sep  5 1994 #include <malloc.h> added				*
 *									*
 ************************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#ifndef VMS_NUAGES
#include<memory.h>
#include <malloc.h>
#endif
#include "repros.h"                /*  type definitions */


void toggle(Object *obj)
{
  X_section  *x;
  x = obj->s1;
  obj->s1  =  obj->s2;
  obj->s2  =  obj->s3;
  obj->s3  =  x;
}


void init_mem_X_section(X_section **sect)
{
  X_section *s;
  unsigned int x_sect_mem_size;
  int sizeofCoord, sizeofOrder, sizeofList,
      sizeofSimp, sizeofCentre,sizeofRayon;

  sizeofCoord = Maxvertex * 2 * sizeof(float);
  sizeofOrder = Maxvertex * sizeof(int);
  sizeofList  = Maxvertex * sizeof(Snode *);
  sizeofSimp  = Maxtri * 3 * sizeof(int);
  sizeofRayon = Maxtri * sizeof(REAL);
  sizeofCentre= Maxtri * 2 * sizeof(REAL);

  x_sect_mem_size =
          sizeof(X_section) +
          sizeofCoord + /*point*/
          sizeofOrder + /*succ*/ 
          sizeofOrder + /*pred*/ 
          sizeofList  + sizeof(Snode) * Maxtri * 3 + /*simplist*/ 
          sizeofList  + sizeof(Snode) * Maxv * 2 +  /*pointlist*/ 
          sizeofSimp * 2 +  /*simp + vois */
          sizeofCentre +  /*centre*/
          sizeofRayon;    /*rayon*/

  s             = (X_section *)malloc( sizeof(X_section) );
  ERRCHK(s,"no memory for X_section\n");
  s->point      = (Coord     *)malloc( sizeofCoord );
  ERRCHK(s->point,"no memory for X_section\n");
  s->succ       = (Order     *)malloc( sizeofOrder );
  ERRCHK(s->succ,"no memory for X_section\n");
  s->pred       = (Order *)malloc( sizeofOrder );
  ERRCHK(s->pred,"no memory for X_section\n");
  s->simplist   = (List *)malloc( sizeofList);
  ERRCHK(s->simplist,"no memory for X_section\n");
  s->pointlist  = (List *)malloc( sizeofList);
  ERRCHK(s->pointlist,"no memory for X_section\n");
  s->simp       = (Simp  *)malloc( sizeofSimp);
  ERRCHK(s->simp,"no memory for X_section\n");
  s->vois       = (Simp  *)malloc( sizeofSimp);
  ERRCHK(s->vois,"no memory for X_section\n");
  s->centre     = (Centre *)malloc( sizeofCentre );
  ERRCHK(s->centre,"no memory for X_section\n");
  s->rayon      = (Rayon *)malloc( sizeofRayon);
  ERRCHK(s->rayon,"no memory for X_section\n");

  s->list_base  = (Snode *)malloc( sizeof(Snode) * Maxtri * 3 + 
                                  sizeof(Snode) * Maxv * 2);
  ERRCHK(s->list_base,"no memory for X_section\n");
  s->list_ptr  = s->list_base;
  s->z = 0.0;
  s->nbpt    = 0;
  s->nb_plus = 0;
  s->nb_int  = 0;
  s->nbs     = 0;
  *sect = s;
  DEBUGF(("   struct X_section: %7dk allocated\n",x_sect_mem_size/1024));
}

void init_mem_Slice(Slice **Sl)
{
  Slice *S;
  unsigned int  slice_mem_size;
  unsigned int sizeofSimp4, sizeofItyps;

  sizeofSimp4 = Max4 * 4 * sizeof(int);
  sizeofItyps = Max4 * sizeof(char);
  slice_mem_size  = sizeof(Slice);

  S = (Slice *)malloc( sizeof(Slice) );
  if (S == NULL) {
    fprintf(stderr,"no memory for Slice (need %d bytes)\n",sizeof(Slice));
    fflush(stderr);
    exit(1);
  }
  *Sl = S;
}

void init_seuil(Object *obj)
{
  obj->seuil[0] = THR_1;
  obj->seuil[1] = THR_2;
  obj->seuil[2] = THR_3;
  obj->seuil[3] = THR_4;
  obj->seuil[4] = THR_5;
  obj->seuil[5] = THR_6;
}

void realloc_slice(Object *obj, int inc)
{
  unsigned int slice_mem_size;
  unsigned int sizeofSimp4, sizeofItyps;
  unsigned int nbt1plust2;
  char *ptr;
  register int i, j;

  DEBUGF(("   Nb of t12 exceeding max_t12 (%d). Realloc\n",Max_t12));
    
  Max_t12 = Max_t12 + inc + Max_extra;
  Max_tnode = 2 * Max_t12;
  nbt1plust2 = obj->s1->nbs + obj->s2->nbs;

  ptr = (char *)realloc((char *)obj->intable,
                         nbt1plust2*3*sizeof(Tnode *) +
                         Max_tnode * sizeof(Tnode));
  ERRCHK(ptr, "realloc: not enough memory for tnodes\n");
  obj->intable = (Intable *)ptr;
  obj->it_ptr = (Tnode *)((char *)obj->intable+nbt1plust2*3*sizeof(Tnode *));
  obj->it_max = (Tnode *)((char *)obj->it_ptr + Max_tnode * sizeof(Tnode));

  DEBUGF(("   tri3D: %d k re-allocated\n",
          (nbt1plust2*3*sizeof(Tnode *) +
                                           Max_tnode*sizeof(Tnode))/1024));
  Max4 = obj->s1->nbs+obj->s2->nbs + Max_t12;
  sizeofSimp4 = Max4 * 4 * sizeof(int);
  sizeofItyps = Max4 * sizeof(char);
  slice_mem_size = 2*sizeofSimp4 + sizeofItyps;


  DEBUGF(("   Re-allocating Slice\n"));
  ptr = (char *)realloc((char *)obj->slice->simp, sizeofSimp4);
  ERRCHK(ptr, "realloc: not enough memory for simp\n");
  obj->slice->simp = (Simp4 *)ptr;
  ptr = (char *)realloc((char *)obj->slice->vois, sizeofSimp4);
  ERRCHK(ptr, "realloc: not enough memory for vois\n");
  obj->slice->vois = (Simp4 *)ptr;
  ptr = (char *)realloc((char *)obj->slice->ityps, sizeofItyps);
  ERRCHK(ptr, "realloc: not enough memory for Ityps\n");
  obj->slice->ityps = (Ityps *)ptr;
  for (i = Max4-1 ; i >= Max4-inc; i--) 
    for (j=0; j<4 ; j++)
      (*(obj->slice->vois))[i][j] = 0;
  DEBUGF(("   struct Slice:     %7dk re-allocated\n",slice_mem_size/1024));
  obj->slice->nb_t12 = 0;
  obj->slice->nbs    = 0;
}

void realloc_x_sections(Object *obj, char flag)
{
  X_section *s;
  char *ptr;
  register int i, j;
  unsigned int x_sect_mem_size;
  int sizeofCoord, sizeofOrder, sizeofList,
      sizeofSimp, sizeofCentre,sizeofRayon;
  int old_Maxplus, old_Max_int, diff;
  int stop;

  old_Maxplus = Maxplus;
  old_Max_int = Max_int;

  diff = Max_increment;

  if(flag == 'p') {
    DEBUGF(("\n   max_plus overflow at %d -> realloc\n",old_Maxplus));
    Maxplus = Maxplus + diff;
    stop = Maxpoint+old_Maxplus;
  }
  else {
    DEBUGF(("\n   max_int overflow at %d -> realloc\n",old_Max_int));
    Max_int = Max_int + diff;
    stop = Maxpoint+Maxplus+old_Max_int;
  }

  Maxvertex = Maxpoint + Maxplus + Max_int + 4;
  Maxtri    = 2 * (Maxvertex - 3);
  Maxv      = 3 * Maxvertex - 7;
  Max_t12   = 2 * Maxtri;
  Max4      = 2 * Maxtri + Max_t12;
  Max_tnode = 2 * Max_t12;


  sizeofCoord = Maxvertex * 2 * sizeof(float);
  sizeofOrder = Maxvertex * sizeof(int);
  sizeofList  = Maxvertex * sizeof(Snode *);
  sizeofSimp  = Maxtri * 3 * sizeof(int);
  sizeofRayon = Maxtri * sizeof(REAL);
  sizeofCentre= Maxtri * 2 * sizeof(REAL);

  x_sect_mem_size =
          sizeof(X_section) +
          sizeofCoord + /*point*/
          sizeofOrder + /*succ*/ 
          sizeofOrder + /*pred*/ 
          sizeofList  + sizeof(Snode) * Maxtri * 3 + /*simplist*/ 
          sizeofList  + sizeof(Snode) * Maxv * 2 +  /*pointlist*/ 
          sizeofSimp * 2 +  /*simp + vois */
          sizeofCentre +  /*centre*/
          sizeofRayon;    /*rayon*/
 
  s = obj->s1;
  ptr = (char *)s->point;
  s->point      = (Coord     *)realloc(ptr, sizeofCoord );
  ERRCHK(s->point,"no memory for re-allocating X_section\n");
  ptr = (char *)s->succ;
  s->succ       = (Order     *)realloc(ptr, sizeofOrder );
  ERRCHK(s->succ,"no memory for re-allocating X_section\n");
  ptr = (char *)s->pred;
  s->pred       = (Order *)realloc(ptr, sizeofOrder );
  ERRCHK(s->pred,"no memory for re-allocating X_section\n");
  ptr = (char *)s->simplist;
  s->simplist   = (List *)realloc(ptr, sizeofList);
  ERRCHK(s->simplist,"no memory for re-allocating X_section\n");
  ptr = (char *)s->pointlist;
  s->pointlist  = (List *)realloc(ptr, sizeofList);
  ERRCHK(s->pointlist,"no memory for re-allocating X_section\n");
  ptr = (char *)s->simp;
  s->simp       = (Simp  *)realloc(ptr, sizeofSimp);
  ERRCHK(s->simp,"no memory for re-allocating X_section\n");
  ptr = (char *)s->vois;
  s->vois       = (Simp  *)realloc(ptr, sizeofSimp);
  ERRCHK(s->vois,"no memory for re-allocating X_section\n");
  ptr = (char *)s->centre;
  s->centre     = (Centre *)realloc(ptr, sizeofCentre );
  ERRCHK(s->centre,"no memory for re-allocating X_section\n");
  ptr = (char *)s->rayon;
  s->rayon      = (Rayon *)realloc(ptr, sizeofRayon);
  ERRCHK(s->rayon,"no memory for re-allocating X_section\n");

  ptr = (char *)s->list_base;
  s->list_base  = (Snode *)realloc(ptr, sizeof(Snode) * Maxtri * 3 + 
                                  sizeof(Snode) * Maxv * 2);
  ERRCHK(s->list_base,"no memory for re-allocating X_section\n");
  s->list_ptr  = s->list_base;
  DEBUGF(("   struct X_section: %7dk re-allocated\n",x_sect_mem_size/1024));

  for(i= Maxpoint+old_Maxplus+old_Max_int+3, j=Maxvertex-1 ;
                       i >= stop ; i--,j--) {
    (*(s->point))[j][0] = (*(s->point))[i][0];
    (*(s->point))[j][1] = (*(s->point))[i][1];
  }
  for (i=0; i<s->nbs ; i++)
    for (j=0; j<3 ; j++)  {
      if( (*(s->simp))[i][j] > stop ) 
        (*(s->simp))[i][j] = (*(s->simp))[i][j] + diff;
    }
  plist(s);
  slist(s);

  s = obj->s2;
  ptr = (char *)s->point;
  s->point      = (Coord     *)realloc(ptr, sizeofCoord );
  ERRCHK(s->point,"no memory for re-allocating X_section\n");
  ptr = (char *)s->succ;
  s->succ       = (Order     *)realloc(ptr, sizeofOrder );
  ERRCHK(s->succ,"no memory for re-allocating X_section\n");
  ptr = (char *)s->pred;
  s->pred       = (Order *)realloc(ptr, sizeofOrder );
  ERRCHK(s->pred,"no memory for re-allocating X_section\n");
  ptr = (char *)s->simplist;
  s->simplist   = (List *)realloc(ptr, sizeofList);
  ERRCHK(s->simplist,"no memory for re-allocating X_section\n");
  ptr = (char *)s->pointlist;
  s->pointlist  = (List *)realloc(ptr, sizeofList);
  ERRCHK(s->pointlist,"no memory for re-allocating X_section\n");
  ptr = (char *)s->simp;
  s->simp       = (Simp  *)realloc(ptr, sizeofSimp);
  ERRCHK(s->simp,"no memory for re-allocating X_section\n");
  ptr = (char *)s->vois;
  s->vois       = (Simp  *)realloc(ptr, sizeofSimp);
  ERRCHK(s->vois,"no memory for re-allocating X_section\n");
  ptr = (char *)s->centre;
  s->centre     = (Centre *)realloc(ptr, sizeofCentre );
  ERRCHK(s->centre,"no memory for re-allocating X_section\n");
  ptr = (char *)s->rayon;
  s->rayon      = (Rayon *)realloc(ptr, sizeofRayon);
  ERRCHK(s->rayon,"no memory for re-allocating X_section\n");

  ptr = (char *)s->list_base;
  s->list_base  = (Snode *)realloc(ptr, sizeof(Snode) * Maxtri * 3 + 
                                  sizeof(Snode) * Maxv * 2);
  ERRCHK(s->list_base,"no memory for re-allocating X_section\n");
  s->list_ptr  = s->list_base;
  DEBUGF(("   struct X_section: %7dk re-allocated\n",x_sect_mem_size/1024));

  for(i= Maxpoint+old_Maxplus+old_Max_int+3, j=Maxvertex-1 ;
                       i >= stop ; i--,j--) {
    (*(s->point))[j][0] = (*(s->point))[i][0];
    (*(s->point))[j][1] = (*(s->point))[i][1];
  }
  for (i=0; i<s->nbs ; i++)
    for (j=0; j<3 ; j++) 
      if( (*(s->simp))[i][j] > stop ) {
        (*(s->simp))[i][j] = (*(s->simp))[i][j] + diff;
      }
  plist(s);
  slist(s);

  s = obj->s3;
  ptr = (char *)s->point;
  s->point      = (Coord     *)realloc(ptr, sizeofCoord );
  ERRCHK(s->point,"no memory for re-allocating X_section\n");
  ptr = (char *)s->succ;
  s->succ       = (Order     *)realloc(ptr, sizeofOrder );
  ERRCHK(s->succ,"no memory for re-allocating X_section\n");
  ptr = (char *)s->pred;
  s->pred       = (Order *)realloc(ptr, sizeofOrder );
  ERRCHK(s->pred,"no memory for re-allocating X_section\n");
  ptr = (char *)s->simplist;
  s->simplist   = (List *)realloc(ptr, sizeofList);
  ERRCHK(s->simplist,"no memory for re-allocating X_section\n");
  ptr = (char *)s->pointlist;
  s->pointlist  = (List *)realloc(ptr, sizeofList);
  ERRCHK(s->pointlist,"no memory for re-allocating X_section\n");
  ptr = (char *)s->simp;
  s->simp       = (Simp  *)realloc(ptr, sizeofSimp);
  ERRCHK(s->simp,"no memory for re-allocating X_section\n");
  ptr = (char *)s->vois;
  s->vois       = (Simp  *)realloc(ptr, sizeofSimp);
  ERRCHK(s->vois,"no memory for re-allocating X_section\n");
  ptr = (char *)s->centre;
  s->centre     = (Centre *)realloc(ptr, sizeofCentre );
  ERRCHK(s->centre,"no memory for re-allocating X_section\n");
  ptr = (char *)s->rayon;
  s->rayon      = (Rayon *)realloc(ptr, sizeofRayon);
  ERRCHK(s->rayon,"no memory for re-allocating X_section\n");

  ptr = (char *)s->list_base;
  s->list_base  = (Snode *)realloc(ptr, sizeof(Snode) * Maxtri * 3 + 
                                  sizeof(Snode) * Maxv * 2);
  ERRCHK(s->list_base,"no memory for re-allocating X_section\n");
  s->list_ptr  = s->list_base;
  DEBUGF(("   struct X_section: %7dk re-allocated\n",x_sect_mem_size/1024));

  for(i= Maxpoint+old_Maxplus+old_Max_int+3, j=Maxvertex-1 ;
                       i >= stop ; i--,j--) {
    (*(s->point))[j][0] = (*(s->point))[i][0];
    (*(s->point))[j][1] = (*(s->point))[i][1];
  }
  for (i=0; i<s->nbs ; i++)
    for (j=0; j<3 ; j++)  {
      if( (*(s->simp))[i][j] > stop ) 
        (*(s->simp))[i][j] = (*(s->simp))[i][j] + diff;
    }
  plist(s);
  slist(s);

}

void free_intable(Object *obj)
{
  free((char *)obj->extralist);
  free((char *)obj->intable);
  DEBUGF(("   tri3D: %d k free\n",
           ((obj->s1->nbs+obj->s2->nbs)*3*sizeof(Tnode *) + 
                                            Max_tnode*sizeof(Tnode))/1024));
}

void free_slice(Object *obj)
{
  free((char *)obj->slice->simp);
  free((char *)obj->slice->vois);
  free((char *)obj->slice->ityps);

  DEBUGF(("   tri3D: %d k free\n",
           (Max4*4*2*sizeof(int) + Max4*sizeof(char))/1024));
}


void alloc_slice(Object *obj)
{
  Slice *S;
  unsigned int  slice_mem_size;
  unsigned int sizeofSimp4, sizeofItyps;
  unsigned int nbt1plust2;

  nbt1plust2 = obj->s1->nbs + obj->s2->nbs;
  Max4 = nbt1plust2 + Max_t12;

  sizeofSimp4 = Max4 * 4 * sizeof(int);
  sizeofItyps = Max4 * sizeof(char);
  slice_mem_size  = sizeofSimp4 * 2 + sizeofItyps;

  S = obj->slice;

  S->nb_t1  = 0;
  S->nb_t2  = 0;
  S->nb_t12 = 0;
  S->nbs    = 0;

  S->simp = (Simp4 *)malloc( sizeofSimp4 );
  if (S->simp == NULL) {
    fprintf(stderr,"no memory for Slice (%d bytes)\n",sizeofSimp4);
    fflush(stderr);
    exit(1);
  }
  S->vois = (Simp4 *)malloc( sizeofSimp4 );
  if (S->vois == NULL) {
    fprintf(stderr,"no memory for Slice (%d bytes)\n",sizeofSimp4);
    fflush(stderr);
    exit(1);
  }
  S->ityps = (Ityps *)malloc( sizeofItyps );
  if (S->ityps == NULL) {
    fprintf(stderr,"no memory for Slice (%d bytes)\n",sizeofItyps);
    fflush(stderr);
    exit(1);
  }
  obj->intable = (Intable *)malloc(nbt1plust2*3*sizeof(Tnode *) +
                     Max_tnode * sizeof(Tnode));
  if (obj->intable == NULL) {
    fprintf(stderr,"no memory for intersection table (%d kbytes)\n",
        (nbt1plust2*3*sizeof(Tnode *)+ Max_tnode * sizeof(Tnode))/1024);
    fflush(stderr);
    exit(1);
  }
  DEBUGF(("   struct Slice:     %7dk allocated\n",slice_mem_size/1024));
  DEBUGF(("   tri3D:            %7dk allocated\n",
         (nbt1plust2*3*sizeof(Tnode *) + Max_tnode*sizeof(Tnode))/1024));
  obj->it_ptr = (Tnode *)((char *)obj->intable+nbt1plust2*3*sizeof(Tnode *));
  obj->it_max = (Tnode *)((char *)obj->it_ptr + Max_tnode * sizeof(Tnode));

  obj->extralist = (Elist *)calloc(Max_extra*4, sizeof(int));
  ERRCHK(obj->extralist, "tri3D: no mem space for extralist\n");
  obj->e_ptr = 0;
}
