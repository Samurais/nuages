#ifndef lint
static  char *sccsid = "@(#)in_out.c	4.7 97/04/03";
#endif

/************************************************************************
 *									*
 * REPROS-REconstruction from Planar cROss-Sections  V 4.1  Oct 30 1996 *
 *									*
 *  module in_out.c							*
 *  copyright (c) 1993 Bernhard Geiger					*
 ************************************************************************/
/************************************************************************
 *			Modification History				*
 * Dec  8 1996 facnor speedup						*
 * 		tri output is sorted (bottom/middle/top) per slice	*
 * May 19 1995 Geiger							*
 * 	last bug (?) when reading internal point file (+i)		*
 * Jan 25 1995 translated to ANSI C                                     *
 * Jan 20 1994 Geiger							*
 * 	bug when reading internal point file (+i)			*
 ************************************************************************/
 
#include<stdio.h>                  /*  io library */
#include<string.h>
#include<math.h>
#include "repros.h"                /*  type definitions */


#define F_OPEN(fp,fname,x,string) \
  obj->fp = fopen(fname, x); \
    if (obj->fp == NULL) { \
      fprintf(stderr,string,fname); \
      fflush(stderr); \
      exit(1); \
    } \

static int facnor(Object *obj, int (*nsimp)[4], int nsc, int nvc, int typ, double *x, double *y, double *z, double *nor, int *isom);

void file_close(Object *obj)
{
  fclose(obj->fp_coord);
  fclose(obj->fp_coord_out);
  fclose(obj->fp_tri_out);
  if(obj->flag.read_interior || obj->flag.write_interior) {
    fclose(obj->fp_coord_int);
  }
  if(obj->flag.tetrahedra_out)
    fclose(obj->fp_tetra_out);
}



void init_files(Object *obj)
{
  register int i,j;
  int nbpt;
  float x,y,z;
  float xmax,xmin,ymax,ymin,zmax,zmin;
  char fname_out[132];
  char *new_extension  = ".new";
  int max_nb_pts       = 0;
  int max_nb_int_pts   = Max_int;
  int nb               = 0;
  char c, s1[132], s2[132];
  int end;

  F_OPEN(fp_coord, obj->fnam[0],"r","file %s not found\n");
  fscanf(obj->fp_coord,"%s%d" ,s1, &(obj->nb_sections)); /* read nb of planes */

  xmax = -EXEPTION_VAL; xmin = EXEPTION_VAL;
  ymax = -EXEPTION_VAL; ymin = EXEPTION_VAL;
  zmax = -EXEPTION_VAL; zmin = EXEPTION_VAL;

  /*scan coordinates */
  for ( i=0 ; i<obj->nb_sections ; ++i) {
    nb = 0;
    fscanf(obj->fp_coord,"%s%d%s%f",s1,&nbpt, s2, &z );
    zmax = Max(zmax,z); zmin = Min(zmin,z);
    if (nbpt > max_nb_pts) max_nb_pts = nbpt;

    while (nb < nbpt ) {
      end = FALSE;
      while( (char)(getc(obj->fp_coord)) != '{' ) {;}
      do {
        fscanf(obj->fp_coord,"%f%f",&x,&y);
        xmax = Max(xmax,x); ymax = Max(ymax,y);
        xmin = Min(xmin,x); ymin = Min(ymin,y);
        nb++;
        do {
          c = (char)getc(obj->fp_coord);
        } while( c == ' ' || c == '\n' );
        if ( c=='}') {
          end = TRUE;
        }
        else { /* still one more vertex */
          ungetc(c,obj->fp_coord);
        }
      } while(!end);
    }
  }
  obj->cent[0] = xmin + (xmax-xmin)/2.0;
  obj->cent[1] = ymin + (ymax-ymin)/2.0;
  obj->cent[2] = zmin + (zmax-zmin)/2.0;
  obj->ray = InfinityNorm( xmax-xmin, ymax-ymin, zmax-zmin );
  obj->nbpt = 0;
  fclose(obj->fp_coord);
  F_OPEN(fp_coord, obj->fnam[0],"r","file %s not found\n");
  fscanf(obj->fp_coord,"%s%d" ,s1, &(obj->nb_sections)); /* read nb of planes */
  DEBUGF(("s1: %g\ns2: %g\ns3: %g\ns4: %g\ns5: %g\ns6: %g\n",
    obj->seuil[0],obj->seuil[1],obj->seuil[2],obj->seuil[3],
    obj->seuil[4],obj->seuil[5]));

  if (obj->flag.write_interior) {
    printf("writing interior files\n");
    F_OPEN(fp_coord_int, obj->fnam[3],"w","cannot open %s\n");
    fprintf(obj->fp_coord_int,"s %d\n" ,obj->nb_sections);
  }
  if (obj->flag.read_interior) {
    printf("reading interior files\n");
    F_OPEN(fp_coord_int, obj->fnam[3],"r","cannot open %s\n");
    fscanf(obj->fp_coord_int,"%s%d", s1, &nbpt); /* read number of planes */
    if (nbpt != obj->nb_sections) {
      fprintf(stderr,"nb x-sections does not match internal points\n");
      fflush(stderr);
      exit(1);
    }
    for ( i=0 ; i<obj->nb_sections ; ++i) {
      fscanf(obj->fp_coord_int,"%s%d%s%f",s1,&nbpt, s2, &z );
      if (nbpt > max_nb_int_pts) max_nb_int_pts = nbpt;
      for ( j=0 ; j<nbpt ; ++j)
        fscanf(obj->fp_coord_int,"%f%f", &x,&y);
    }
    fclose(obj->fp_coord_int);
    F_OPEN(fp_coord_int, obj->fnam[3],"r","cannot open %s\n");
    fscanf(obj->fp_coord_int,"%s%d", s1, &nbpt); /* read number of planes */
  }

  if (obj->flag.tetrahedra_out) {
    F_OPEN(fp_tetra_out, obj->fnam[2],"w","cannot open %s\n");
    fprintf(obj->fp_tetra_out,"%d\n",obj->nb_sections-1);
  }
  strcpy(fname_out,obj->fnam[0]); 
  F_OPEN(fp_coord_out, strcat(fname_out,new_extension),"w","cannot open %s\n");
  fprintf(obj->fp_coord_out,"s %d\n" ,obj->nb_sections);

  F_OPEN(fp_tri_out, obj->fnam[1],"w","cannot open %s\n");
  fprintf(obj->fp_tri_out,"%d\n",obj->nb_sections-1);

  Maxpoint  = max_nb_pts;
  Max_int   = max_nb_int_pts;

  Maxvertex = Maxpoint + Maxplus + Max_int + 4;
  Maxtri    = 2 * (Maxvertex - 3);
  Maxv      = 3 * Maxvertex - 7;
  if ( Max_t12 == MAX_T12 ) {
    Max_t12   = 2 * Maxtri + Max_extra;
    Max_tnode = 2 * Max_t12;
  }
  Max4      = 2 * Maxtri + Max_t12;
}


void read_section(Object *obj, X_section *s, int nb)
{
  int i,first;
  char c, s1[132], s2[132];
  float z;
  int end;

  fscanf(obj->fp_coord,"%s%d%s%f",s1,&(s->nbpt), s2, &z );

  i = 0;
  while ( i < s->nbpt ) {
    end = FALSE;
    first = i;
    while( (char)(getc(obj->fp_coord)) != '{' ) {;}
    do {
      fscanf(obj->fp_coord,"%f%f",&(*(s->point))[i][0], &(*(s->point))[i][1]);
      (*(s->succ))[i] = i + 2;
      (*(s->pred))[i] = i;
      i++;
      do {
        c = (char)getc(obj->fp_coord);
      } while( c == ' ' || c == '\n' );
      if ( c=='}') {
        end = TRUE;
      }
      else { /* still one more vertex */
        ungetc(c,obj->fp_coord);
      }
    } while(!end);
    (*(s->succ))[i-1] = first + 1;
    (*(s->pred))[first] = i;
  }
  s->z = z;
  obj->nbpt = obj->nbpt + s->nbpt;
  s->nb_plus= 0;
  s->nb_int = 0;
  s->nb = nb;
  if (obj->flag.read_interior) {
    fscanf(obj->fp_coord_int,"%s%d%s%f",s1,&(s->nb_int), s2, &z );
    for (i = Maxpoint+Maxplus ; i < Maxpoint+Maxplus + s->nb_int ; ++i) {
       fscanf(obj->fp_coord_int,"%f%f" , &(*(s->point))[i][0],
              &(*(s->point))[i][1]);
       (*(s->succ))[i] = 0;
       (*(s->pred))[i] = 0;
    }
    if (z!=s->z) printf("   warning: z internal does not match current section\n");
  }
  obj->z_direction = Sign(obj->s2->z - obj->s1->z);
}

 
void write_section(Object *obj, X_section *s)
{
  int i;

  fprintf(obj->fp_coord_out, "v %d z %f\n",
                  s->nbpt + s->nb_plus + s->nb_int, s->z);
  for(i=0 ; i < s->nbpt ; i++) {
    if ((*(s->point))[i][1] == EXEPTION_VAL) (*(s->point))[i][1] = 0.0;
    fprintf(obj->fp_coord_out,"%.3f %.3f\n", (*(s->point))[i][0],
                 (*(s->point))[i][1]);
  }
  for(i=Maxpoint ; i < Maxpoint+s->nb_plus ; i++) {
    if ((*(s->point))[i][1] == EXEPTION_VAL) (*(s->point))[i][1] = 0.0;
    fprintf(obj->fp_coord_out,"%.3f %.3f\n", (*(s->point))[i][0],
                 (*(s->point))[i][1]);
  }
  for(i=Maxpoint+Maxplus ; i < Maxpoint+Maxplus+s->nb_int ; i++) {
    if ((*(s->point))[i][1] == EXEPTION_VAL) (*(s->point))[i][1] = 0.0;
    fprintf(obj->fp_coord_out,"%.3f %.3f\n", (*(s->point))[i][0],
                 (*(s->point))[i][1]);
  }
  if (obj->flag.write_interior) {
    fprintf(obj->fp_coord_int,"v %d z %f\n",s->nb_int, s->z );
    for (i = Maxpoint+Maxplus ; i < Maxpoint+Maxplus + s->nb_int ; ++i) {
       fprintf(obj->fp_coord_int,"%.3f %.3f\n" , (*(s->point))[i][0],
              (*(s->point))[i][1]);
    }
  }
}

 
void write_slice(Object *obj)
{
  int i,j,k;
  Slice *S;
  X_section *s[2];
  double x[4],y[4],z[4];
  int p, d[2][2], isom[3];
  double norm[3];
  int nb;
  int ier = 0;

  S = obj->slice;
  s[0] = obj->s1;
  s[1] = obj->s2;
  d[0][0] = Maxpoint - s[0]->nbpt;
  d[1][0] = Maxpoint - s[1]->nbpt;
  d[0][1] = Maxpoint + Maxplus - s[0]->nbpt - s[0]->nb_plus;
  d[1][1] = Maxpoint + Maxplus - s[1]->nbpt - s[1]->nb_plus;

  nb = 0;
  for ( i = 0 ; i< S->nbs ; i++)
    if (Not_Elim(S,i))
      for (j=0; j<4 ; j++)
        if( (*(S->vois))[i][j] == 0 || Elim(S,((*(S->vois))[i][j]-1)))
          nb++;
  fprintf(obj->fp_tri_out,"%d %d %d\n",nb,s[0]->nb,s[1]->nb);

  /* print all horizontal triangles  first */
  for ( i = 0 ; i< S->nb_t1 ; i++)
    if (Not_Elim(S,i))
      if( (*(S->vois))[i][3] == 0 || Elim(S,((*(S->vois))[i][3]-1))) {
        ier = facnor(obj,*(S->simp),i,3,1,x,y,z,norm,isom);
        if(ier)
          printf("   flat t1 tetra - check z values\n");
        for(k=0 ; k<3 ; k++) {
          isom[k] = (isom[k]<=Maxpoint)?isom[k]:(isom[k]<=Maxpoint+Maxplus)?isom[k]-d[0][0]:isom[k]-d[0][1];
          isom[k] = (isom[k]<<1);
        }
        fprintf(obj->fp_tri_out,"%d %d %d %.3f %.3f %.3f\n",
                isom[0],isom[1],isom[2],norm[0],norm[1],norm[2]);
      }
 
  /* print all non - horizontal triangles  of t1 */
  for ( i = 0 ; i< S->nb_t1 ; i++)
    if (Not_Elim(S,i))
    for (j=0; j<3 ; j++)
      if( (*(S->vois))[i][j] == 0 || Elim(S,((*(S->vois))[i][j]-1))) {
        /*t1 out*/;
        ier = facnor(obj,*(S->simp),i,j,1,x,y,z,norm,isom);
        if(ier) 
          printf("   flat t1 tetra - check z values\n");
        for(k=0 ; k<3 ; k++) {
          p = (k == 2-j);
          isom[k] = (isom[k]<=Maxpoint)?isom[k]:(isom[k]<=Maxpoint+Maxplus)?isom[k]-d[p][0]:isom[k]-d[p][1];
          isom[k] = (isom[k]<<1) + p;
        }
        fprintf(obj->fp_tri_out,"%d %d %d %.3f %.3f %.3f\n",
                isom[0],isom[1],isom[2],norm[0],norm[1],norm[2]);
      }
  /* print all triangles  (non horizontal!) of t12 */
  for ( i = S->nb_t1+S->nb_t2 ; i< S->nbs ; i++)
    if (Not_Elim(S,i))
    for (j=0; j<4 ; j++)
      if( (*(S->vois))[i][j] == 0 || Elim(S,((*(S->vois))[i][j]-1))) {
        /*t12 out*/;
        ier = facnor(obj,*(S->simp),i,j,0,x,y,z,norm,isom);
        if(ier)
          printf("   flat t12 tetra\n");
        for(k=0 ; k<3 ; k++) {
          p = ( 3-k == j || 4-k == j || (j==0 && k==0) );
          isom[k] = (isom[k]<=Maxpoint)?isom[k]:(isom[k]<=Maxpoint+Maxplus)?isom[k]-d[p][0]:isom[k]-d[p][1];
          isom[k] = (isom[k]<<1) + p;
        }
        fprintf(obj->fp_tri_out,"%d %d %d %.3f %.3f %.3f\n",
                isom[0],isom[1],isom[2],norm[0],norm[1],norm[2]);
      }
 
  /* print all non - horizontal triangles  of t2 */
  for ( i = S->nb_t1 ; i< S->nb_t1+S->nb_t2 ; i++)
    if (Not_Elim(S,i))
    for (j=0; j<3 ; j++)
      if( (*(S->vois))[i][j] == 0 || Elim(S,((*(S->vois))[i][j]-1))) {
        /*t2 out*/;
        ier = facnor(obj,*(S->simp),i,j,2,x,y,z,norm,isom);
        if(ier) 
          printf("   flat t2 tetra - check z values\n");
        for(k=0 ; k<3 ; k++) {
          p = !(k == 2-j);
          isom[k] = (isom[k]<=Maxpoint)?isom[k]:(isom[k]<=Maxpoint+Maxplus)?isom[k]-d[p][0]:isom[k]-d[p][1]; isom[k] = (isom[k]<<1) + p;
        }
        fprintf(obj->fp_tri_out,"%d %d %d %.3f %.3f %.3f\n",
                isom[0],isom[1],isom[2],norm[0],norm[1],norm[2]);
      }
  /* print all horizontal triangles  of t2 */
  for ( i = S->nb_t1 ; i< S->nb_t1+S->nb_t2 ; i++)
    if (Not_Elim(S,i))
      if( (*(S->vois))[i][3] == 0 || Elim(S,((*(S->vois))[i][3]-1))) {
        /*t2 out*/;
        ier = facnor(obj,*(S->simp),i,3,2,x,y,z,norm,isom);
        if(ier)
          printf("   flat t2 tetra - check z values\n");
        for(k=0 ; k<3 ; k++) {
          p = 1;
          isom[k] = (isom[k]<=Maxpoint)?isom[k]:(isom[k]<=Maxpoint+Maxplus)?isom[k]-d[1][0]:isom[k]-d[1][1];
          isom[k] = (isom[k]<<1) + 1;
        }
        fprintf(obj->fp_tri_out,"%d %d %d %.3f %.3f %.3f\n",
                isom[0],isom[1],isom[2],norm[0],norm[1],norm[2]);
      }
}




void write_tetrahedra(Object *obj, int all)
{
  int i,j;
  Slice *S;
  X_section *s[2];
  int p, d[2][2], isom[4];

  S = obj->slice;
  s[0] = obj->s1;
  s[1] = obj->s2;
  d[0][0] = Maxpoint - s[0]->nbpt;
  d[1][0] = Maxpoint - s[1]->nbpt;
  d[0][1] = Maxpoint + Maxplus - s[0]->nbpt - s[0]->nb_plus;
  d[1][1] = Maxpoint + Maxplus - s[1]->nbpt - s[1]->nb_plus;
  

  fprintf(obj->fp_tetra_out,"%d %d %d\n",S->nbs,s[0]->nb,s[1]->nb);

  for ( i = 0 ; i< S->nb_t1 ; i++)
    if (all || Not_Elim(S,i)) {
      for (j=0; j<4 ; j++) { /*t1 tetrahedra out*/;
        p = (j/3);
        isom[j] = (*(S->simp))[i][j];
        isom[j] = (isom[j]<=Maxpoint)?isom[j]:(isom[j]<=Maxpoint+Maxplus)?isom[j]-d[p][0]:isom[j]-d[p][1];
        isom[j] = (isom[j]<<1) + p;
      }
      fprintf(obj->fp_tetra_out,"%d %d %d %d %d %d %d %d %d\n",
                isom[0],isom[1],isom[2],isom[3],
                (*(S->vois))[i][0], (*(S->vois))[i][1],
                (*(S->vois))[i][2], (*(S->vois))[i][3],
                (*(S->ityps))[i]);
    }
  for ( i = S->nb_t1 ; i< S->nb_t1+S->nb_t2 ; i++)
    if (all || Not_Elim(S,i)) {
      for (j=0; j<4 ; j++) { /*t2 tetrahedra out*/;
        p = (1 - j/3);
        isom[j] = (*(S->simp))[i][j];
        isom[j] = (isom[j]<=Maxpoint)?isom[j]:(isom[j]<=Maxpoint+Maxplus)?isom[j]-d[p][0]:isom[j]-d[p][1];
        isom[j] = (isom[j]<<1) + p;
      }
      fprintf(obj->fp_tetra_out,"%d %d %d %d %d %d %d %d %d\n",
                isom[0],isom[1],isom[2],isom[3],
                (*(S->vois))[i][0], (*(S->vois))[i][1],
                (*(S->vois))[i][2], (*(S->vois))[i][3],
                (*(S->ityps))[i]);
    }
  for ( i = S->nb_t1+S->nb_t2 ; i< S->nbs ; i++)
    if (all || Not_Elim(S,i)) {
      for (j=0; j<4 ; j++) { /*t12 tetrahedra out*/;
        p = (1 - j/2);
        isom[j] = (*(S->simp))[i][j];
        isom[j] = (isom[j]<=Maxpoint)?isom[j]:(isom[j]<=Maxpoint+Maxplus)?isom[j]-d[p][0]:isom[j]-d[p][1];
        isom[j] = (isom[j]<<1) + p;
      }
      fprintf(obj->fp_tetra_out,"%d %d %d %d %d %d %d %d %d\n",
                isom[0],isom[1],isom[2],isom[3],
                (*(S->vois))[i][0], (*(S->vois))[i][1],
                (*(S->vois))[i][2], (*(S->vois))[i][3],
                (*(S->ityps))[i]);
    }
}


static int facnor(Object *obj, int (*nsimp)[4], int nsc, int nvc,
           int typ, double *x, double *y, double *z, double *nor, int *isom)
/*    calcule les coordonnees des sommets de la face du simplexe
c     nsc vu par nvc
c     et sa normale pointant vers l'exterieur de la face
c     si tetrahedre plat ier=1 (on ne peut pas orienter la normale)
*/
 
{
  X_section *(s[2]);
  register int i,j,k;
  double xx,yy,zz,cnorm,xvoy,yvoy,zvoy,test;
 
  s[0] = obj->s1;
  s[1] = obj->s2;
  switch (typ) {
    case 0: i = (nvc < 2); break;
    case 1: i = (nvc > 2); break;
    case 2: i = (nvc < 3); break;
  }
 
  xvoy = (double)(*(s[i]->point))[nsimp[nsc][nvc]-1][0];
  yvoy = (double)(*(s[i]->point))[nsimp[nsc][nvc]-1][1];
  zvoy = (double)s[i]->z;
 
 
  k = nvc + 1; if (k==4) k = 0;
  for (j=0 ; j<3 ; j++, k=(k==3)?0:k+1) {
    switch (typ) {
      case 0: i = (k < 2); break;
      case 1: i = (k > 2); break;
      case 2: i = (k < 3); break;
    }
    isom[j]=nsimp[nsc][k];
    x[j]=(*(s[i]->point))[isom[j]-1][0];
    y[j]=(*(s[i]->point))[isom[j]-1][1];
    z[j]=s[i]->z;
  }
  x[3]=x[0];
  y[3]=y[0];
  z[3]=z[0];
  if( nvc == 3  && typ != 0 ) {
    if (typ == 1) {
      nor[0] = 0.0;
      nor[1] = 0.0;
      nor[2] = -obj->z_direction;
    }
    else {
      nor[0] = 0.0;
      nor[1] = 0.0;
      nor[2] = obj->z_direction;
    }
    return(0);
  }
 
  /*     calcul de la normale */
  /*     cross product of two sides */
  nor[0] = (y[1]-y[0]) * (z[2]-z[0]) - (z[1]-z[0]) * (y[2]-y[0]);
  nor[1] = (z[1]-z[0]) * (x[2]-x[0]) - (x[1]-x[0]) * (z[2]-z[0]);
  nor[2] = (x[1]-x[0]) * (y[2]-y[0]) - (y[1]-y[0]) * (x[2]-x[0]);
  cnorm= sqrt(nor[0] * nor[0] + nor[1] * nor[1] + nor[2] * nor[2]);
  if (cnorm == 0.0) {
    fprintf(stderr, "problem?? \n");
    return(1);
  }
  nor[0]= nor[0]/cnorm;
  nor[1]= nor[1]/cnorm;
  nor[2]= nor[2]/cnorm;
  /* check for orientation with resp to voy*/
  xx=xvoy-x[0];
  yy=yvoy-y[0];
  zz=zvoy-z[0];
  cnorm=sqrt(xx*xx+yy*yy+zz*zz);
  xx=xx/cnorm;
  yy=yy/cnorm;
  zz=zz/cnorm;
  test = nor[0] * xx + nor[1] * yy + nor[2] * zz;
  if(fabs(test) <= obj->seuil[3])  return(1);
  if(test < 0) return(0);
  nor[0] = -nor[0];
  nor[1] = -nor[1];
  nor[2] = -nor[2];
  return(0);
}
