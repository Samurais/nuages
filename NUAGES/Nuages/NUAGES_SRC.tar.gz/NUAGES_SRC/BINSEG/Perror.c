#ifndef lint
static  char *sccsid = "@(#)Perror.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>

#include "BINSEGP.h"
#include "BINSEGInt.h"


typedef enum {
  NOT_IN_NEWLINES, IN_NEWLINES
} State;

/*----------------- (INRIA) ---------------------------------------------*/
void
BINSEG_Perror (const char *msg)

/*
 * PURPOSE: BINSEG_Perror produces a short  error  message  on  the  standard
 *          error describing the last error encountered during a call to
 *          a BINSEG  library function.
 *          If msg is not a NULL pointer and does not point to a null string, 
 *          the string it points to is printed, followed by a colon, followed 
 *          by a space followed  by  the message and a NEWLINE
 * ARGUMENTS: 
 * RETURN:  void
 * GLOBALS: _BINSEG_errno
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  if (msg != (char *) NULL && (*msg) != '\0') {
#define MAX_MSG_SIZE 250
    char buffer[MAX_MSG_SIZE + 2 + 1];
    /*
     * 2 is for a colon, followed by a  space,
     * 1 is for the terminating null character
     */
    char *pt1;
    const char *pt2;
    unsigned int n;
    State state;

    for (pt1 = buffer, pt2 = msg, state = NOT_IN_NEWLINES, n = 0
	 ; *pt2 != '\0' && n < MAX_MSG_SIZE
	 ; pt2++, n++) {
      char c = *pt2;

      switch (state) {
	case NOT_IN_NEWLINES:
	  if (c == '\n') {
            state = IN_NEWLINES;
	  }
	  else
            *pt1++ = c;
	  break;
	case IN_NEWLINES:
	  if (c != '\n') {
	    *pt1++ = c;
            state = NOT_IN_NEWLINES;
	  }
	  break;
      }
    }

    if (pt1 != buffer) {
      *pt1++ = ':';
      *pt1++ = ' ';
      *pt1 = '\0';
      (void) fprintf (stderr, buffer);
    }
  }
  _BINSEG_Perror (_BINSEG_errno);
}


/*----------------- (INRIA) ---------------------------------------------*/
void
_BINSEG_Perror (BINSEG_Status err)

/*
 * PURPOSE: internal function called by BINSEG_Perror and
 *          BINSEG_Perrorf
 * RETURN:  void
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  unsigned int unknown_error;

  switch (err) {
    case BINSEG_Succeed:
      (void) fprintf (stderr, "last call succeeded\n");
      break;
    case BINSEG_ErrMemAlloc:
      (void) fprintf (stderr, "memory allocation failure\n");
      break;
    case BINSEG_ErrBadParams:
      (void) fprintf (stderr, "bad parameters to a function call\n");
      break;
    case BINSEG_ErrNotEnoughRoom:
      (void) fprintf (stderr,
                      "storage supplied by caller is not big enough\n");
      break;
    default:
      unknown_error = (unsigned int) err;
      (void) fprintf (stderr, "unknown error %u\n", unknown_error);
      break;
  }
}

