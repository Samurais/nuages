/*
 * @(#)BINSEGInt.h	1.1 97/04/10
 */
/************************************************************************
 *  copyright (c) 1993 Bernhard Geiger                                  *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/



#ifndef _BINSEGInt_h
#define _BINSEGInt_h

#ifndef _BINSEG_h
#include "BINSEG.h"
#endif


#define BINSEG_GetRegionNumberedPixelValue(array,sizex,sizey,i,j) \
  ((array)[(i) + (j) * (sizex)])

#define BINSEG_SetRegionNumberedPixelValue(array,sizex,sizey,i,j,value) \
  ((array)[(i) + (j) * (sizex)] = value)


#define BINSEG_IsPixelEqualToValue(array,sizex,sizey,i,j,foreground) \
  (((array)[(i) + (j) * (sizex)]) == foreground)

#define BINSEG_IsPixelSet(array,sizex,sizey,i,j) \
  (((array)[(i) + (j) * (sizex)]) == 1)

#define BINSEG_SetPixel(array,sizex,sizey,i,j) \
  ((array)[(i) + (j) * (sizex)]=(1))

#define BINSEG_UnsetPixel(array,sizex,sizey,i,j) \
  ((array)[(i) + (j) * (sizex)]=(0))

#define BINSEG_MAX_REGION_LABEL(a,b) ((a) > (b) ? (a) : (b))
#define BINSEG_MIN_REGION_LABEL(a,b) ((a) < (b) ? (a) : (b))

typedef struct _BINSEG_EquivalenceTableRec *BINSEG_EquivalenceTable ;

extern void _BINSEG_DisposeEquivalenceTable ();
extern BINSEG_Status _BINSEG_NewEquivalenceTable ()
 ,_BINSEG_IncreaseEquivalenceTableSize ();
extern BINSEG_Status _BINSEG_NewEquivalenceTableNode ();
extern void _BINSEG_RelabelImage ();
extern BINSEG_Status _BINSEG_ResolveEquivalenceTable ();
extern void _BINSEG_DumpEquivalenceTable ();
extern void _BINSEG_DumpResolvedEquivalenceTable ();
extern BINSEG_Status _BINSEG_RegisterRegionsCollision ();

extern BINSEG_Status _BINSEG_ColorRegions (BINSEG_Pixel *, unsigned int, unsigned int, BINSEG_Pixel, BINSEG_Connectedness, BINSEG_RegionLabel *, unsigned int *, BINSEG_EquivalenceTable *);
extern BINSEG_Status _BINSEG_ColorRegionsGeneric ();
extern BINSEG_Status _BINSEG_ColorRegionsInfinite (BINSEG_Pixel *, unsigned int, unsigned int, BINSEG_Pixel, BINSEG_RegionLabel *, unsigned int *);
                                                    
extern BINSEG_Status _BINSEG_ColorRegions4 (BINSEG_Pixel *, unsigned int, unsigned int, BINSEG_Pixel, BINSEG_EquivalenceTable, BINSEG_RegionLabel *, unsigned int *);
extern BINSEG_Status _BINSEG_ColorRegions8 (BINSEG_Pixel *, unsigned int, unsigned int, BINSEG_Pixel, BINSEG_EquivalenceTable, BINSEG_RegionLabel *, unsigned int *);

extern BINSEG_Status _BINSEG_NewSegmentedImage () ;

extern BINSEG_Status _BINSEG_FollowTypedBorder(
                  BINSEG_Pixel *
                  , unsigned int
                  , unsigned int
                  , BINSEG_Pixel
                  , BINSEG_Connectedness
                  , _BINSEG_BorderPoint *
                  , unsigned int
                  , unsigned int *
                  , unsigned int
                  , int) ;
extern BINSEG_Status _BINSEG_SetRegionFirstPixelIndex ();
extern BINSEG_Status _BINSEG_FollowAllBorders ();
extern BINSEG_Status _BINSEG_FollowBorder (
                  BINSEG_Pixel *
                  , unsigned int
                  , unsigned int
                  , BINSEG_Pixel
                  , BINSEG_Connectedness
                  , _BINSEG_BorderPoint *
                  , unsigned int
                  , unsigned int *
                  , _BINSEG_BorderPoint *
               ) ;
extern BINSEG_Status _BINSEG_errno;
extern void _BINSEG_Perror () ;
#endif
