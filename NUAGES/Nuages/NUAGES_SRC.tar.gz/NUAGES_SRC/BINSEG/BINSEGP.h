/*
 * @(#)BINSEGP.h	1.1 97/04/10
 */
/************************************************************************
 *  copyright (c) 1993 Bernhard Geiger                                  *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/



#ifndef _BINSEGP_h
#define _BINSEGP_h

#ifndef _BINSEG_h
#include <BINSEG.h>
#endif

#if 0
typedef enum {
  BINSEG_East = 0, BINSEG_South = 1, BINSEG_West = 2, BINSEG_North = 3
} BINSEG_4Orientation;
#else
typedef unsigned int BINSEG_4Orientation;
#define BINSEG_East   0
#define BINSEG_South  1
#define BINSEG_West   2
#define BINSEG_North  3
#endif

extern int _BINSEG_FourNeighborsDx[];
extern int _BINSEG_FourNeighborsDy[];

typedef struct {
  BINSEG_4Orientation orientation;
  unsigned int x;
  unsigned int y;
} _BINSEG_BorderPoint;

typedef struct _BINSEG_SegmentedImageRegionRec {
  unsigned int size;
  unsigned int number_of_border_points;
  _BINSEG_BorderPoint *border_points;
  unsigned int first_pixel_index;
} BINSEG_SegmentedImageRegionRec;

typedef struct _BINSEG_SegmentedImageRec {
  unsigned int width;
  unsigned int height;
  BINSEG_Pixel foreground_pixel;
  BINSEG_Connectedness connectedness;
  unsigned int number_of_foreground_regions;
  unsigned int number_of_background_regions;
  BINSEG_SegmentedImageRegionRec *foreground_regions;
  BINSEG_SegmentedImageRegionRec *background_regions;
} BINSEG_SegmentedImageRec;

typedef struct _BINSEG_SegmentedImageRegionListElementRec {
  BINSEG_SegmentedImageRegionRec region_record;
} BINSEG_SegmentedImageRegionListElementRec;


typedef struct _BINSEG_SegmentedImageRegionListRec {
  BINSEG_SegmentedImageRec segmented_image_record;
} BINSEG_SegmentedImageRegionListRec;

#endif
