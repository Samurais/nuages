#ifndef lint
static  char *sccsid = "@(#)segment_image.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include <stdio.h>
#include <malloc.h>
#include <assert.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"




BINSEG_Status _BINSEG_errno = BINSEG_Succeed;

static void _BINSEG_DisposeSegmentedImageRegionArray ();
static void _BINSEG_DisposeSegmentedImageRegion ();


BINSEG_Status
BINSEG_SegmentBinaryImage (BINSEG_Pixel *binary_image
                           ,unsigned int width
                           ,unsigned int height
			   ,BINSEG_Pixel foreground_pixel
			   ,BINSEG_Connectedness connectedness_arg
			   ,BINSEG_SegmentedImage *segmented_image_arg)
{
  BINSEG_EquivalenceTable foreground_equivalence_table
   ,background_equivalence_table;
  BINSEG_RegionLabel *foreground_region_numbered_image
   ,*background_region_numbered_image;

  BINSEG_SegmentedImage segmented_image = (BINSEG_SegmentedImage) 0;
  unsigned int foreground_number_of_regions, background_number_of_regions;
  BINSEG_Connectedness connectedness;
  BINSEG_Status err;
  unsigned int background_width, background_height;
  BINSEG_Pixel *background_binary_image;

  if (connectedness_arg != BINSEG_4_Connectedness
      && connectedness_arg != BINSEG_8_Connectedness) {
#ifndef NDEBUG
    (void) fprintf (stderr, "BINSEG_SegmentBinaryImage: connectedness should be either BINSEG_8_Connectedness or BINSEG_4_Connectedness\n");
#endif
    return BINSEG_ErrBadParams;
  }
  background_width = width + 2;
  background_height = height + 2;

  if ((foreground_region_numbered_image = (BINSEG_RegionLabel *)
       malloc (sizeof (*foreground_region_numbered_image)
	       * width * height))
      == (BINSEG_RegionLabel *) 0) {
    err = BINSEG_ErrMemAlloc;
  }
  else {
    err = _BINSEG_ColorRegions (binary_image, width, height
				  ,foreground_pixel
				  ,connectedness_arg
				  ,foreground_region_numbered_image
				  ,&foreground_number_of_regions
				  ,&foreground_equivalence_table);

    free ((malloc_t) foreground_region_numbered_image);
  }

  if (err == BINSEG_Succeed) {
    if ((background_binary_image = (BINSEG_Pixel *)
      malloc (sizeof (*background_binary_image)
		  * background_width * background_height))
	  == (BINSEG_Pixel *) 0) {
	err = BINSEG_ErrMemAlloc;
    }
    else {
      if ((background_region_numbered_image = (BINSEG_RegionLabel *)
	       malloc (sizeof (*background_region_numbered_image)
		       * background_width * background_height))
	      == (BINSEG_RegionLabel *) 0) {
	err = BINSEG_ErrMemAlloc;
	free ((malloc_t) background_binary_image);
      }
    }
  }

  if (err == BINSEG_Succeed) {
    switch (connectedness_arg) {
      case BINSEG_4_Connectedness:
	connectedness = BINSEG_8_Connectedness;
	break;
      case BINSEG_8_Connectedness:
	connectedness = BINSEG_4_Connectedness;
	break;
      default:;
    }
    {
      int w = width, h = height;
      int i, j;
      BINSEG_Pixel pixel_set = 1, pixel_unset = 0;

      for (i = 0; i < w; i++) {
	for (j = 0; j < h; j++) {
	  if (binary_image[i + w * j] == foreground_pixel)
	    background_binary_image[i + 1 + (w + 2) * (j + 1)] = pixel_unset;
	  else
            background_binary_image[i + 1 + (w + 2) * (j + 1)] = pixel_set;
	}
      }
      for (i = 0; i < w + 2; i++) {
	background_binary_image[i] = pixel_set;
	background_binary_image[i + (w + 2) * (h + 1)] = pixel_set;
      }
      for (j = 0; j < h + 2; j++) {
	background_binary_image[(w + 2) * j] = pixel_set;
	background_binary_image[w + 1 + (w + 2) * j] = pixel_set;
      }
      err = _BINSEG_ColorRegions (background_binary_image
				    ,background_width
				    ,background_height
				    ,pixel_set
				    ,connectedness
				    ,background_region_numbered_image
				    ,&background_number_of_regions
				    ,&background_equivalence_table);
    }
    free ((malloc_t) background_binary_image);
    free ((malloc_t) background_region_numbered_image);

  }
  if (err == BINSEG_Succeed) {
    background_number_of_regions--;
    /*
     * the infinite background region is irrelevant
     */
    if ((err = _BINSEG_NewSegmentedImage (width, height
					    ,foreground_number_of_regions
					    ,background_number_of_regions
					    ,&segmented_image))
	  == BINSEG_Succeed) {
      segmented_image->connectedness = connectedness_arg;
      segmented_image->foreground_pixel = foreground_pixel;
    }
  }

#ifdef DEBUG
  (void) fprintf (stdout, "Dumping foreground_equivalence_table\n");
  _BINSEG_DumpResolvedEquivalenceTable (foreground_equivalence_table);
#endif

#ifdef DEBUG
  (void) fprintf (stdout, "Dumping background_equivalence_table\n");
  _BINSEG_DumpResolvedEquivalenceTable (background_equivalence_table);
#endif

  if (err == BINSEG_Succeed) {
    err = _BINSEG_FollowAllBorders
	(segmented_image
	 ,binary_image
	 ,foreground_equivalence_table
	 ,background_equivalence_table);
  }

  _BINSEG_DisposeEquivalenceTable (&foreground_equivalence_table);
  _BINSEG_DisposeEquivalenceTable (&background_equivalence_table);

  *segmented_image_arg = segmented_image;
  return err;
}



BINSEG_Status
_BINSEG_NewSegmentedImage (unsigned int width
                          ,unsigned int height
                          ,unsigned int number_of_foreground_regions
                          ,unsigned int number_of_background_regions
                          ,BINSEG_SegmentedImage *segmented_image_ptr 
)
{
  BINSEG_Status err = BINSEG_ErrMemAlloc;

  BINSEG_SegmentedImageRec *segmented_image
  = (BINSEG_SegmentedImageRec *) 0;
  BINSEG_SegmentedImageRegionRec *foreground_regions
  = (BINSEG_SegmentedImageRegionRec *) 0;
  BINSEG_SegmentedImageRegionRec *background_regions
  = (BINSEG_SegmentedImageRegionRec *) 0;

  if (width == 0 || height == 0)
    return BINSEG_ErrBadParams;

  if (number_of_foreground_regions == 0
      || (foreground_regions = (BINSEG_SegmentedImageRegionRec *)
	  malloc (sizeof (*foreground_regions)
		  * number_of_foreground_regions))
      != (BINSEG_SegmentedImageRegionRec *) 0) {
    if (number_of_background_regions == 0
	|| (background_regions = (BINSEG_SegmentedImageRegionRec *)
	    malloc (sizeof (*background_regions)
		    * number_of_background_regions))
	!= (BINSEG_SegmentedImageRegionRec *) 0) {
      if ((segmented_image = (BINSEG_SegmentedImageRec *)
	       malloc (sizeof (*segmented_image)))
	      != (BINSEG_SegmentedImage) 0) {
	int i;

	segmented_image->width = width;
	segmented_image->height = height;

	segmented_image->number_of_foreground_regions = number_of_foreground_regions;
	segmented_image->foreground_regions = foreground_regions;
	segmented_image->number_of_background_regions = number_of_background_regions;
        segmented_image->background_regions = background_regions;

	for (i = 0; i < number_of_foreground_regions; i++)
          foreground_regions[i].border_points = (_BINSEG_BorderPoint *) 0;
	for (i = 0; i < number_of_background_regions; i++)
	  background_regions[i].border_points = (_BINSEG_BorderPoint *) 0;

	err = BINSEG_Succeed;
	goto err_0;

      }
      else
	goto err_3;
    }
    else
      goto err_2;
  }
  else
    goto err_0;

err_3:
  if (background_regions != (BINSEG_SegmentedImageRegionRec *) 0)
    free ((malloc_t) background_regions);

err_2:
  if (foreground_regions != (BINSEG_SegmentedImageRegionRec *) 0)
    free ((malloc_t) foreground_regions);

err_0:
  *segmented_image_ptr = segmented_image;

  return err;
}

void
BINSEG_DisposeSegmentedImage (BINSEG_SegmentedImage *segmented_image_ptr)
{
  BINSEG_SegmentedImage segmented_image = *segmented_image_ptr;


  if (segmented_image != (BINSEG_SegmentedImage) 0) {
    if (segmented_image->foreground_regions
	  != (BINSEG_SegmentedImageRegionRec *) 0) {
      _BINSEG_DisposeSegmentedImageRegionArray
	    (segmented_image->foreground_regions
	     ,segmented_image->number_of_foreground_regions);
      free ((malloc_t) segmented_image->foreground_regions);
    }

    if (segmented_image->background_regions
	  != (BINSEG_SegmentedImageRegionRec *) 0) {
      _BINSEG_DisposeSegmentedImageRegionArray
	    (segmented_image->background_regions
	     ,segmented_image->number_of_background_regions);
      free ((malloc_t) segmented_image->background_regions);
    }
    free ((malloc_t) segmented_image);
  }
  *segmented_image_ptr = (BINSEG_SegmentedImage) 0;
}

static void
_BINSEG_DisposeSegmentedImageRegionArray (
        BINSEG_SegmentedImageRegionRec *array,
        unsigned int size)
{
  int i;
  for (i = 0; i < size; i++)
    _BINSEG_DisposeSegmentedImageRegion (&array[i]);
}


static void
_BINSEG_DisposeSegmentedImageRegion (BINSEG_SegmentedImageRegionRec *region)
{
  if (region != (BINSEG_SegmentedImageRegionRec *) 0) {
    if (region->border_points != (_BINSEG_BorderPoint *) 0)
      free ((malloc_t) region->border_points);
  }
}
