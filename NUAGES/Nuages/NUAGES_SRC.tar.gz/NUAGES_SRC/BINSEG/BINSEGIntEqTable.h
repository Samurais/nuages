/*
 * @(#)BINSEGIntEqTable.h	1.1 97/04/10
 */
/************************************************************************
 *  copyright (c) 1993 Bernhard Geiger                                  *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/



typedef struct _BINSEG_Region {
    unsigned char mark;
    BINSEG_RegionLabel label;
    struct _BINSEG_Region *distinguished_representant;
    unsigned int first_pixel_index ;
    unsigned int region_size ;
    struct _BINSEG_EquivalenceTableNode *equivalent_nodes;
} BINSEG_EquivalenceTableSlot, *BINSEG_Region;

typedef struct _BINSEG_EquivalenceTableNode {
  BINSEG_RegionLabel label;
  struct _BINSEG_EquivalenceTableNode *next;
} *BINSEG_EquivalenceTableNode;

#define BINSEG_MarkRegion(region)\
  (region)->mark = 1 ;
#define BINSEG_UnMarkRegion(region)\
  (region)->mark = 0 ;
#define BINSEG_MarkedRegionP(region)\
  ((region)->mark == 1)

typedef struct _BINSEG_EquivalenceTableRec {
  unsigned int number_of_slots, number_of_used_slots;
  unsigned int max_region_label;
  unsigned int resolved_max_region_label;
  BINSEG_EquivalenceTableSlot *slots;
  BINSEG_EquivalenceTableSlot *resolved_slots;
  unsigned int  number_of_resolved_slots;
  unsigned char resolution_done;
} BINSEG_EquivalenceTableRec;

#define BINSEG_SetResolvedFlag(eqtable)\
  (eqtable)->resolution_done = 1 ;
#define BINSEG_UnSetResolvedFlag(eqtable)\
  (eqtable)->resolution_done = 0 ;
#define BINSEG_EquivalenceTableResolvedP(eqtable)\
  ((eqtable)->resolution_done == 1)
