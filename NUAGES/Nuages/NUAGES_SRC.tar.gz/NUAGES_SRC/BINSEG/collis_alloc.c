#ifndef lint
static  char *sccsid = "@(#)collis_alloc.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#define NDEBUG

#include <assert.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"
#include "BINSEGIntEqTable.h"



BINSEG_Status
_BINSEG_NewEquivalenceTableNode (BINSEG_EquivalenceTableNode *EquivalenceTableNode_ptr)
{
  BINSEG_EquivalenceTableNode a_EquivalenceTableNode;
  BINSEG_Status err = BINSEG_Succeed;

  if ((a_EquivalenceTableNode = (BINSEG_EquivalenceTableNode)
       malloc (sizeof (*a_EquivalenceTableNode)))
      == (BINSEG_EquivalenceTableNode) 0)
    err = BINSEG_ErrMemAlloc;
  else
    {
      a_EquivalenceTableNode->label = BINSEG_NULL_REGION_LABEL;
      a_EquivalenceTableNode->next = (BINSEG_EquivalenceTableNode) 0;
    }
  *EquivalenceTableNode_ptr = a_EquivalenceTableNode;
  return err;
}

void
_BINSEG_DisposeEquivalenceTableNode (BINSEG_EquivalenceTableNode *EquivalenceTableNode_ptr)
{
  BINSEG_EquivalenceTableNode a_EquivalenceTableNode = *EquivalenceTableNode_ptr;

  free ((malloc_t) a_EquivalenceTableNode);
  *EquivalenceTableNode_ptr = (BINSEG_EquivalenceTableNode) 0;
}

#define BINSEG_EquivalenceTable_DEFAULT_SIZE 1024


BINSEG_Status
_BINSEG_NewEquivalenceTable (BINSEG_EquivalenceTable *equivalence_table_ptr)
{
  BINSEG_EquivalenceTable equivalence_table = (BINSEG_EquivalenceTable) 0;
  BINSEG_Status err;
  unsigned int current_number_of_slots = BINSEG_EquivalenceTable_DEFAULT_SIZE;
  BINSEG_EquivalenceTableSlot *slots;

  if ((slots = (BINSEG_EquivalenceTableSlot *)
       calloc (current_number_of_slots, sizeof (*slots)))
      == (BINSEG_EquivalenceTableSlot *) 0)
    {
      err = BINSEG_ErrMemAlloc;
    }
  else
    {
      if ((equivalence_table = (BINSEG_EquivalenceTable)
	   malloc (sizeof (*equivalence_table)))
	  == (BINSEG_EquivalenceTable) 0)
	{
	  err = BINSEG_ErrMemAlloc;
	  free ((malloc_t) slots);
	}
      else
	{
	  int i;
	  for (i = 0; i < current_number_of_slots; i++)
	    {
	      BINSEG_UnMarkRegion (&slots[i]);
	      slots[i].label = BINSEG_NULL_REGION_LABEL;
	      slots[i].distinguished_representant = (BINSEG_Region) 0;
	      slots[i].equivalent_nodes = (BINSEG_EquivalenceTableNode) 0;
	    }
	  equivalence_table->number_of_slots = current_number_of_slots;
	  equivalence_table->number_of_used_slots = 0;
	  equivalence_table->slots = slots;
	  equivalence_table->max_region_label
	    = BINSEG_NULL_REGION_LABEL;
	  equivalence_table->resolved_max_region_label
	    = BINSEG_NULL_REGION_LABEL;
	  equivalence_table->slots = slots;
	  equivalence_table->resolved_slots
	    = (BINSEG_EquivalenceTableSlot *) 0;
	  equivalence_table->number_of_resolved_slots = 0;
	  BINSEG_SetResolvedFlag (equivalence_table);
	  err = BINSEG_Succeed;
	}
    }
  *equivalence_table_ptr = equivalence_table;
  return err;
}


BINSEG_Status
_BINSEG_IncreaseEquivalenceTableSize (BINSEG_EquivalenceTable equivalence_table
                                     ,BINSEG_RegionLabel max_label)
{
  BINSEG_Status err;
  unsigned int current_number_of_slots;
  BINSEG_EquivalenceTableSlot *slots;
  unsigned int desired_size = max_label + 1;

  assert (equivalence_table != (BINSEG_EquivalenceTable) 0);

  current_number_of_slots = equivalence_table->number_of_slots;

  if (desired_size <= current_number_of_slots)
    return BINSEG_Succeed;
  else
    current_number_of_slots = 2 * desired_size;

  if ((slots = (BINSEG_EquivalenceTableSlot *)
       realloc ((char *) equivalence_table->slots
		,current_number_of_slots *
		sizeof (*slots)))
      == (BINSEG_EquivalenceTableSlot *) 0)
    {
      err = BINSEG_ErrMemAlloc;
    }
  else
    {
      int i;
      for (i = equivalence_table->number_of_slots
	   ; i < current_number_of_slots
	   ; i++)
	{
	  BINSEG_UnMarkRegion (&slots[i]);
	  slots[i].label = BINSEG_NULL_REGION_LABEL;
	  slots[i].distinguished_representant = (BINSEG_Region) 0;
	  slots[i].equivalent_nodes = (BINSEG_EquivalenceTableNode) 0;
	}
      equivalence_table->number_of_slots = current_number_of_slots;
      equivalence_table->slots = slots;
      equivalence_table->number_of_used_slots = max_label;
      /* resolved flag is not affected by a size extension */

      err = BINSEG_Succeed;
    }
  return err;
}


void
_BINSEG_DisposeEquivalenceTable (BINSEG_EquivalenceTable *equivalence_table_ptr)
{
  BINSEG_EquivalenceTable equivalence_table = *equivalence_table_ptr;

  if (equivalence_table != (BINSEG_EquivalenceTable) 0)
    {
      BINSEG_EquivalenceTableSlot *slots = equivalence_table->slots;

      if (slots != (BINSEG_EquivalenceTableSlot *) 0)
	{
	  int i;
	  BINSEG_EquivalenceTableNode equivalence_table_node
	   ,next_equivalence_table_node;
	  for (i = 0; i < equivalence_table->number_of_slots; i++)
	    {

	      for (equivalence_table_node = slots[i].equivalent_nodes
		 ; equivalence_table_node != (BINSEG_EquivalenceTableNode) 0
		   ; equivalence_table_node = next_equivalence_table_node)
		{
		  next_equivalence_table_node = equivalence_table_node->next;
		  _BINSEG_DisposeEquivalenceTableNode
		    (&equivalence_table_node);
		}
	    }

	  free ((malloc_t) slots);
	}

      if (equivalence_table->resolved_slots
	  != (BINSEG_EquivalenceTableSlot *) 0)
	free ((malloc_t) equivalence_table->resolved_slots);

      free ((malloc_t) equivalence_table);
    }
  *equivalence_table_ptr = (BINSEG_EquivalenceTable) 0;
}
