#ifndef lint
static  char *sccsid = "@(#)colreg.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include <stdio.h>
#include <assert.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"
#include "BINSEGIntEqTable.h"

BINSEG_Status
BINSEG_ColorRegions (BINSEG_Pixel *image
                     ,unsigned int width
                     ,unsigned int height
		     ,BINSEG_Pixel foreground_pixel
		     ,BINSEG_Connectedness connectedness
		     ,BINSEG_RegionLabel *region_numbered_image
		     ,unsigned int *numregions_arg)
{
  BINSEG_EquivalenceTable equivalence_table;
  BINSEG_Status err;

  if ((err = _BINSEG_ColorRegions (image, width, height
				   ,foreground_pixel
				   ,connectedness
				   ,region_numbered_image
				   ,numregions_arg
				   ,&equivalence_table))
      != BINSEG_Succeed)
    return (_BINSEG_errno = err);

#ifdef DEBUG
  _BINSEG_DumpResolvedEquivalenceTable (equivalence_table);
#endif

  _BINSEG_DisposeEquivalenceTable (&equivalence_table);
  return (_BINSEG_errno = err);
}



BINSEG_Status
_BINSEG_ColorRegions (BINSEG_Pixel *image
                     ,unsigned int width
                     ,unsigned int height
		     ,BINSEG_Pixel foreground_pixel
		     ,BINSEG_Connectedness connectedness
		     ,BINSEG_RegionLabel *region_numbered_image
		     ,unsigned int *numregions_arg
		     ,BINSEG_EquivalenceTable *equivalence_table_arg)
{
  BINSEG_Status err = BINSEG_Succeed;
  unsigned int numregions = 0;
  BINSEG_EquivalenceTable equivalence_table = (BINSEG_EquivalenceTable) 0;

  if (width == 0 || height == 0)
    {
#ifndef NDEBUG
      (void) fprintf (stderr, "_BINSEG_ColorRegions: width and height should be different from 0\n");
#endif
      return BINSEG_ErrBadParams;
    }

  if (connectedness != BINSEG_Infinite_Connectedness
      && connectedness != BINSEG_4_Connectedness
      && connectedness != BINSEG_8_Connectedness) {
#ifndef NDEBUG
      (void) fprintf (stderr, "_BINSEG_ColorRegions: unknown connectedness type\n");
#endif
      return BINSEG_ErrBadParams;
  }

  if (connectedness != BINSEG_Infinite_Connectedness) {
      if ((err = _BINSEG_NewEquivalenceTable (&equivalence_table))
	  != BINSEG_Succeed)
	return err;
  }

  switch (connectedness) {
    case BINSEG_Infinite_Connectedness:
      err = _BINSEG_ColorRegionsInfinite (image, width, height
					  ,foreground_pixel
					  ,region_numbered_image
					  ,&numregions);
      break;

    case BINSEG_4_Connectedness:
      err = _BINSEG_ColorRegions4 (image, width, height
				   ,foreground_pixel
				   ,equivalence_table
				   ,region_numbered_image
				   ,&numregions);
      break;

    case BINSEG_8_Connectedness:
      err = _BINSEG_ColorRegions8 (image, width, height
				   ,foreground_pixel
				   ,equivalence_table
				   ,region_numbered_image
				   ,&numregions);
      break;

    default:
      break;
  }

  if (connectedness != BINSEG_Infinite_Connectedness) {
    equivalence_table->max_region_label = numregions;

#ifdef DEBUG_EQUIVALENCE_TABLE
      (void) fprintf (stdout, "Dumping before resolution\n");
      _BINSEG_DumpEquivalenceTable (equivalence_table);
#endif


    if ((err = _BINSEG_ResolveEquivalenceTable (equivalence_table))
	  != BINSEG_Succeed)
	return err;

#ifdef DEBUG_EQUIVALENCE_TABLE
      (void) fprintf (stdout, "Dumping after resolution\n");
      _BINSEG_DumpEquivalenceTable (equivalence_table);
#else
#endif

      _BINSEG_RelabelImage (region_numbered_image, width, height
			    ,equivalence_table
			    ,&numregions);

#ifdef DEBUG_EQUIVALENCE_TABLE
      (void) fprintf (stdout, "Dumping after relabelling\n");
      _BINSEG_DumpEquivalenceTable (equivalence_table);
#endif
    }
  *numregions_arg = numregions;

  *equivalence_table_arg = equivalence_table;
  return err;
}
