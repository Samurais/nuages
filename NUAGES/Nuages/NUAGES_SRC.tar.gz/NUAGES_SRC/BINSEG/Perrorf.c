#ifndef lint
static  char *sccsid = "@(#)Perrorf.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include <stdio.h>
#include <stdarg.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"



/*----------------- (INRIA) ---------------------------------------------*/
/*VARARGS1 PRINTFLIKE1 */
void
  BINSEG_Perrorf(const char *format,...)

/*
 * PURPOSE: BINSEG_Perror produces a short error message  on the standard
 *          error describing the last error encountered during a call to
 *          a BINSEG  library function.
 *          If format is not a NULL pointer and does not point to a null 
 *          string, the string it points to is printed, followed by a colon, 
 *          followed by a space followed  by  the message and a NEWLINE
 * RETURN:  void
 * GLOBALS: _BINSEG_errno
 * REMARK:  The difference with BINSEG_Perror is that BINSEG_Perrorf accepts
 *           a variable number of arguments.
 *-----------------------------------------------------------------------*/
{
  va_list args;
  va_start (args, format);

  if (format != (char *) NULL && (*format) != '\0')
    (void) vfprintf (stderr, format, args);
  (void) fprintf (stderr, ": ");
  _BINSEG_Perror (_BINSEG_errno);
  va_end (args);
}
