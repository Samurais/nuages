/*
 * @(#)BINSEG.h	1.1 97/04/10
 */
/************************************************************************
 *  copyright (c) 1993 Bernhard Geiger                                  *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#ifndef _BINSEG_h
#define _BINSEG_h

#define NDEBUG

typedef enum {
    BINSEG_Succeed = 0,
    BINSEG_ErrBadParams = 1,
    BINSEG_ErrMemAlloc = 2,
    BINSEG_ErrNotEnoughRoom = 3
} BINSEG_Status;

typedef enum {
  BINSEG_True = 0,
  BINSEG_False = 1
} BINSEG_Boolean;

typedef unsigned char BINSEG_Pixel;
typedef unsigned int BINSEG_RegionLabel;
typedef enum {
  BINSEG_8_Connectedness, 
  BINSEG_4_Connectedness, 
  BINSEG_Infinite_Connectedness
} BINSEG_Connectedness;

typedef struct {
  float x;
  float y;
} BINSEG_BorderPoint;

#define BINSEG_NULL_REGION_LABEL ((BINSEG_RegionLabel) 0)

typedef struct _BINSEG_SegmentedImageRec *BINSEG_SegmentedImage;
typedef struct _BINSEG_SegmentedImageRegionRec *BINSEG_SegmentedImageRegion;
typedef struct _BINSEG_SegmentedImageRegionListRec
 *BINSEG_SegmentedImageRegionList;
typedef struct _BINSEG_SegmentedImageRegionListElementRec
 *BINSEG_SegmentedImageRegionListElement;
#define BINSEG_NilRegionListElement\
	((BINSEG_SegmentedImageRegionListElement) 0)


extern void BINSEG_Perror (const char *msg);

extern void BINSEG_Perrorf (const char *format ,...);

extern BINSEG_Status BINSEG_ColorRegions (
	BINSEG_Pixel * image
	,unsigned int width
	,unsigned int height
	,BINSEG_Pixel foreground_pixel
	,BINSEG_Connectedness connectedness
	,BINSEG_RegionLabel * region_numbered_image
	,unsigned int *numregions
);

extern BINSEG_Status BINSEG_CheckRegionsColors (
	BINSEG_Pixel * image
	,unsigned int width
	,unsigned int height
	,BINSEG_Pixel foreground_pixel
	,BINSEG_Connectedness connectedness
	,BINSEG_RegionLabel * region_numbered_image
	,unsigned int numregions
	,BINSEG_Boolean * predicate_return
);

extern BINSEG_Status BINSEG_SegmentBinaryImage (
	BINSEG_Pixel * image
	,unsigned int width
	,unsigned int height
	,BINSEG_Pixel foreground_pixel
	,BINSEG_Connectedness connectedness
	,BINSEG_SegmentedImage * segmented_image
);

extern void BINSEG_DisposeSegmentedImage (
	BINSEG_SegmentedImage * segmented_image
);

extern BINSEG_Status BINSEG_GetListOfRegionsFromSegmentedImage (
	BINSEG_SegmentedImage segmented_image
	,BINSEG_SegmentedImageRegionList * list_of_regions
);

extern BINSEG_Status BINSEG_GetSegmentedImageWidthAndHeight (
	BINSEG_SegmentedImage segmented_image
	,unsigned int *width
	,unsigned int *height
);

extern BINSEG_Status BINSEG_SegmentedImageRegionListGetFirstElement (
	BINSEG_SegmentedImageRegionList list_of_regions
	,BINSEG_SegmentedImageRegionListElement * list_element
);

extern BINSEG_Status BINSEG_SegmentedImageRegionListGetNextElement (
	BINSEG_SegmentedImageRegionList list_of_regions
	,BINSEG_SegmentedImageRegionListElement list_element
	,BINSEG_SegmentedImageRegionListElement * next_element
);

extern BINSEG_Status
  BINSEG_GetSegmentedImageRegionFromSegmentedImageRegionListElement (
	BINSEG_SegmentedImage segmented_image
	,BINSEG_SegmentedImageRegionList list_of_regions
	,BINSEG_SegmentedImageRegionListElement list_element
	,BINSEG_SegmentedImageRegion * region
);

extern BINSEG_Status BINSEG_GetSegmentedImageRegionShiftedBorderPoints (
	BINSEG_SegmentedImage segmented_image
	,BINSEG_SegmentedImageRegion region
	,BINSEG_BorderPoint * border_points_array
	,unsigned int border_points_array_size
	,unsigned int *actual_number_of_border_points
);

extern BINSEG_Status BINSEG_GetSegmentedImageRegionSurface (
	BINSEG_SegmentedImage segmented_image
	,BINSEG_SegmentedImageRegion region
	,unsigned int *surface
);

#include <malloc.h>
#include <stdlib.h>

#ifdef MIPS
typedef void * malloc_t ;
#endif

#endif
