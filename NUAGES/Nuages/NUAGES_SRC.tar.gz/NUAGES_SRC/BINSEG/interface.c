#ifndef lint
static  char *sccsid = "@(#)interface.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#define NDEBUG

#include <assert.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"


/*----------------- (INRIA) ---------------------------------------------*/
BINSEG_Status BINSEG_GetListOfRegionsFromSegmentedImage (
                    BINSEG_SegmentedImage  segmented_image
                  , BINSEG_SegmentedImageRegionList *list_of_regions)

/*
 * PURPOSE:
 * ARGUMENTS: 
 * RETURN:
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err = BINSEG_Succeed;

  if (segmented_image == (BINSEG_SegmentedImage) 0)
    err = BINSEG_ErrBadParams;

  *list_of_regions = (BINSEG_SegmentedImageRegionList) segmented_image;
  return (_BINSEG_errno = err);
}

/*----------------- (INRIA) ---------------------------------------------*/
BINSEG_Status BINSEG_GetSegmentedImageWidthAndHeight(
      BINSEG_SegmentedImage segmented_image
      , unsigned int *width
      , unsigned int *height)


/*
 * PURPOSE:
 * ARGUMENTS: 
 * RETURN:
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err = BINSEG_Succeed;
  if (segmented_image == (BINSEG_SegmentedImage) 0)
    err = BINSEG_ErrBadParams;
  else
    {
      *width = segmented_image->width;
      *height = segmented_image->height;
    }
  return (_BINSEG_errno = err);
}

/*----------------- (INRIA) ---------------------------------------------*/
BINSEG_Status BINSEG_SegmentedImageRegionListGetFirstElement (
    BINSEG_SegmentedImageRegionList list_of_regions
   ,BINSEG_SegmentedImageRegionListElement *list_element)

/*
 * PURPOSE:
 * ARGUMENTS: 
 * RETURN:
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err = BINSEG_Succeed;
  BINSEG_SegmentedImage segmented_image;
  BINSEG_SegmentedImageRegion region;
  unsigned number_of_regions;

  segmented_image = (BINSEG_SegmentedImage) list_of_regions;
  if (segmented_image == (BINSEG_SegmentedImage) 0)
    region = (BINSEG_SegmentedImageRegion) 0;
  else
    {
      region = segmented_image->foreground_regions;
      number_of_regions = segmented_image->number_of_foreground_regions;
      if (region != (BINSEG_SegmentedImageRegion) 0
	  && number_of_regions != 0)
	region = segmented_image->foreground_regions;
      else
	{
	  region = segmented_image->background_regions;
	  number_of_regions = segmented_image->number_of_foreground_regions;
	  if (region == (BINSEG_SegmentedImageRegion) 0
	      || number_of_regions == 0)
	    region = (BINSEG_SegmentedImageRegion) 0;
	}
    }
  *list_element = (BINSEG_SegmentedImageRegionListElement) region;
  return (_BINSEG_errno = err);
}

/*----------------- (INRIA) ---------------------------------------------*/
BINSEG_Status BINSEG_SegmentedImageRegionListGetNextElement (
            BINSEG_SegmentedImageRegionList list_of_regions
           ,BINSEG_SegmentedImageRegionListElement list_element
           ,BINSEG_SegmentedImageRegionListElement * next_element)

/*
 * PURPOSE:
 * ARGUMENTS:
 * RETURN:
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err = BINSEG_Succeed;
  BINSEG_SegmentedImage segmented_image;
  BINSEG_SegmentedImageRegion region = (BINSEG_SegmentedImageRegion) 0;

  segmented_image = (BINSEG_SegmentedImage) list_of_regions;

  if (segmented_image == (BINSEG_SegmentedImage) 0)
    err = BINSEG_ErrBadParams;
  else
    {
      BINSEG_SegmentedImageRegion current_region;
      BINSEG_SegmentedImageRegion foreground_regions, background_regions;
      unsigned int number_of_foreground_regions, number_of_background_regions;

      current_region = (BINSEG_SegmentedImageRegion) list_element;

      if (current_region == (BINSEG_SegmentedImageRegion) 0)
	{
	  err = BINSEG_ErrBadParams;
	  region = 0;
	}
      else
	{
	  foreground_regions = segmented_image->foreground_regions;
	  number_of_foreground_regions =
	    segmented_image->number_of_foreground_regions;
	  background_regions = segmented_image->background_regions;
	  number_of_background_regions =
	    segmented_image->number_of_background_regions;

	  if (current_region >= foreground_regions
	      && current_region + 1 < foreground_regions
	      + number_of_foreground_regions)
	    region = current_region + 1;
	  else if (current_region + 1 == foreground_regions
		   + number_of_foreground_regions)
	    region = background_regions;
	  else if (current_region >= background_regions
		   && current_region + 1 < background_regions
		   + number_of_background_regions)
	    region = current_region + 1;
	  else if (current_region + 1 == background_regions
		   + number_of_background_regions)
	    region = 0;
	  else
	    {
	      err = BINSEG_ErrBadParams;
	      region = 0;
	    }
	}
    }

  *next_element = (BINSEG_SegmentedImageRegionListElement) region;
  return (_BINSEG_errno = err);
}

/*----------------- (INRIA) ---------------------------------------------*/
BINSEG_Status
BINSEG_GetSegmentedImageRegionFromSegmentedImageRegionListElement (
     BINSEG_SegmentedImage segmented_image
    ,BINSEG_SegmentedImageRegionList list_of_regions
    ,BINSEG_SegmentedImageRegionListElement list_element
    ,BINSEG_SegmentedImageRegion * region)

/*
 * PURPOSE:
 * ARGUMENTS:
 * RETURN:
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err = BINSEG_Succeed;
  BINSEG_SegmentedImage segmented_image_aux;
  BINSEG_SegmentedImageRegion region_aux
  = (BINSEG_SegmentedImageRegion) 0;

  segmented_image_aux = (BINSEG_SegmentedImage) list_of_regions;

  if (segmented_image == 0
      || segmented_image_aux != segmented_image)
    err = BINSEG_ErrBadParams;
  else
    {
      BINSEG_SegmentedImageRegion current_region;
      BINSEG_SegmentedImageRegion foreground_regions, background_regions;
      unsigned int number_of_foreground_regions, number_of_background_regions;

      current_region = (BINSEG_SegmentedImageRegion) list_element;

      if (current_region == (BINSEG_SegmentedImageRegion) 0)
	{
	  err = BINSEG_ErrBadParams;
	  region_aux = 0;
	}
      else
	{
	  foreground_regions = segmented_image->foreground_regions;
	  number_of_foreground_regions =
	    segmented_image->number_of_foreground_regions;
	  background_regions = segmented_image->background_regions;
	  number_of_background_regions =
	    segmented_image->number_of_background_regions;

	  if ((current_region >= foreground_regions
	       && current_region <= foreground_regions
	       + number_of_foreground_regions)
	      || (current_region >= background_regions
		  && current_region <= background_regions
		  + number_of_background_regions)
	    )
	    region_aux = current_region;
	  else
	    {
	      err = BINSEG_ErrBadParams;
	      region_aux = 0;
	    }
	}
    }
  *region = region_aux;
  return (_BINSEG_errno = err);
}

/*----------------- (INRIA) ---------------------------------------------*/
BINSEG_Status BINSEG_GetSegmentedImageRegionShiftedBorderPoints (
    BINSEG_SegmentedImage segmented_image
   ,BINSEG_SegmentedImageRegion region
   ,BINSEG_BorderPoint *border_points_array
   ,unsigned int border_points_array_size
   ,unsigned int *actual_number_of_border_points)

/*
 * PURPOSE:
 * ARGUMENTS: 
 * RETURN:
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err = BINSEG_Succeed;
  unsigned int n;
  unsigned int width;
  unsigned int height;

  if (segmented_image == 0 || region == 0)
    {
      err = BINSEG_ErrBadParams;
      n = 0;
    }
  else
    {
      n = region->number_of_border_points;
      width = segmented_image->width;
      height = segmented_image->height;

      if (border_points_array_size < n)
	err = BINSEG_ErrNotEnoughRoom;
      else
	{
	  unsigned int i;

	  for (i = 0; i < n; i++)
	    {
	      double x = region->border_points[i].x;
	      double y = region->border_points[i].y;
	      BINSEG_4Orientation orientation
	      = region->border_points[i].orientation;

	      assert (x < width);
	      assert (y < height);

	      switch (orientation)
		{
		case BINSEG_East:
		  x += 0.25;
		  y += 0.5;
		  break;
		case BINSEG_South:
		  x += 0.5;
		  y += 0.25;
		  break;
		case BINSEG_West:
		  x += 0.75;
		  y += 0.5;
		  break;
		case BINSEG_North:
		  x += 0.5;
		  y += 0.75;
		  break;
		default:
/*
		  assertNOTREACHED ();
*/
		  break;
		}
	      border_points_array[i].x = x;
	      border_points_array[i].y = y;
	    }
	}
    }
  *actual_number_of_border_points = n;
  return (_BINSEG_errno = err);
}
/*----------------- (INRIA) ---------------------------------------------*/
BINSEG_Status BINSEG_GetSegmentedImageRegionSurface (
    BINSEG_SegmentedImage  segmented_image
   ,BINSEG_SegmentedImageRegion region
   ,unsigned int *surface)

/*
 * PURPOSE:
 * ARGUMENTS: 
 * RETURN:
 * GLOBALS:
 * REMARK:
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err;
  if (segmented_image == 0 || region == 0)
    {
      err = BINSEG_ErrBadParams;
      *surface = 0;
    }
  else
    {
      err = BINSEG_Succeed;
      *surface = region->size;
    }

  return (_BINSEG_errno = err);
}
