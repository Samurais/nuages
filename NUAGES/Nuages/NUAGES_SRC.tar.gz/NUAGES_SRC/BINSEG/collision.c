#ifndef lint
static  char *sccsid = "@(#)collision.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include <stdio.h>
#include <assert.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"
#include "BINSEGIntEqTable.h"

static void depth_first_search ();

BINSEG_Status
_BINSEG_RegisterRegionsCollision (BINSEG_EquivalenceTable equivalence_table
				  ,BINSEG_RegionLabel region_label1
				  ,BINSEG_RegionLabel region_label2)
{
  BINSEG_Status err = BINSEG_Succeed;
  BINSEG_RegionLabel label_min, label_max;
  BINSEG_EquivalenceTableNode equivalence_table_node;
  BINSEG_EquivalenceTableSlot *slots;
  int found = 0;

  assert (equivalence_table != (BINSEG_EquivalenceTable) 0);
  if (region_label1 == BINSEG_NULL_REGION_LABEL
      || region_label2 == BINSEG_NULL_REGION_LABEL
      || region_label1 == region_label2)
    return err;

  label_min = BINSEG_MIN_REGION_LABEL (region_label1, region_label2);
  label_max = BINSEG_MAX_REGION_LABEL (region_label1, region_label2);
  equivalence_table->number_of_used_slots
    = BINSEG_MAX_REGION_LABEL (label_max
			       ,equivalence_table->number_of_used_slots);

  if (label_max >= equivalence_table->number_of_slots) {
    if ((err = _BINSEG_IncreaseEquivalenceTableSize
	   (equivalence_table, label_max))
	  != BINSEG_Succeed)
      return err;
  }

  slots = equivalence_table->slots;

  for (found = 0
       ,equivalence_table_node = slots[label_min].equivalent_nodes
       ; equivalence_table_node != (BINSEG_EquivalenceTableNode) 0
       ; equivalence_table_node = equivalence_table_node->next) {
    if (equivalence_table_node->label == label_max) {
      found = 1;
      break;
    }
  }

  if (found == 0) {
    if ((err = _BINSEG_NewEquivalenceTableNode (&equivalence_table_node))
	!= BINSEG_Succeed)
      return err;
    else {
      equivalence_table_node->label = label_max;
      equivalence_table_node->next = slots[label_min].equivalent_nodes;
      slots[label_min].equivalent_nodes = equivalence_table_node;
    }
  }

  for (found = 0
       ,equivalence_table_node = slots[label_max].equivalent_nodes
       ; equivalence_table_node != (BINSEG_EquivalenceTableNode) 0
       ; equivalence_table_node = equivalence_table_node->next) {
    if (equivalence_table_node->label == label_min) {
      found = 1;
      break;
    }
  }

  if (found == 0) {
    if ((err = _BINSEG_NewEquivalenceTableNode (&equivalence_table_node))
	!= BINSEG_Succeed)
      return err;
    else {
      equivalence_table_node->label = label_min;
      equivalence_table_node->next = slots[label_max].equivalent_nodes;
      slots[label_max].equivalent_nodes = equivalence_table_node;
      BINSEG_UnSetResolvedFlag (equivalence_table);
    }
  }

  return err;
}

BINSEG_Status
_BINSEG_ResolveEquivalenceTable (BINSEG_EquivalenceTable equivalence_table)
{
  int i;
  unsigned int nregions;
  BINSEG_Region region;
  BINSEG_Status err = BINSEG_Succeed;

  assert (equivalence_table != (BINSEG_EquivalenceTable) 0);

  if (BINSEG_EquivalenceTableResolvedP (equivalence_table))
    return err;

  for (i = 1
       ; i <= equivalence_table->number_of_used_slots
       ; i++) {
    region = &equivalence_table->slots[i];
    region->label = i;
    BINSEG_UnMarkRegion (region);
  }

  if (equivalence_table->resolved_slots != (BINSEG_EquivalenceTableSlot *) 0)
    free ((malloc_t) equivalence_table->resolved_slots);

  if ((equivalence_table->resolved_slots = (BINSEG_EquivalenceTableSlot *)
       malloc (equivalence_table->number_of_used_slots
	       * sizeof (*equivalence_table->resolved_slots)))
      == (BINSEG_EquivalenceTableSlot *) 0)
    return BINSEG_ErrMemAlloc;

  equivalence_table->number_of_resolved_slots = 0;

  for (nregions = 0
       ,i = 1
       ; i <= equivalence_table->number_of_used_slots
       ; i++) {
    region = &equivalence_table->slots[i];
    if (!BINSEG_MarkedRegionP (region)) {
      depth_first_search (equivalence_table
			      ,region
			      ,region);

      region->label = nregions + 1;
      bcopy ((char *) region
	    ,(char *) &equivalence_table->resolved_slots[nregions]
            ,sizeof (*region));
      nregions++;
    }
  }
  equivalence_table->resolved_slots = (BINSEG_EquivalenceTableSlot *)
    realloc ((char *) equivalence_table->resolved_slots
	     ,nregions * sizeof (*equivalence_table->resolved_slots));
  if (equivalence_table->resolved_slots == (BINSEG_EquivalenceTableSlot *) 0)
    return BINSEG_ErrMemAlloc;

  equivalence_table->number_of_resolved_slots = nregions;

  for (i = 1
       ; i <= equivalence_table->number_of_used_slots
       ; i++) {
    BINSEG_RegionLabel equivalence_class_label;
    region = &equivalence_table->slots[i];
    equivalence_class_label = region->distinguished_representant->label;
    region->label = equivalence_class_label;
  }
  assert (equivalence_table->max_region_label
	  >= equivalence_table->number_of_used_slots);

  equivalence_table->resolved_max_region_label = nregions;

  BINSEG_SetResolvedFlag (equivalence_table);
  return err;
}

static void
depth_first_search (BINSEG_EquivalenceTable equivalence_table
		    ,BINSEG_Region region
		    ,BINSEG_Region distinguished_representant)
{
  BINSEG_EquivalenceTableNode equivalence_table_node;

  BINSEG_MarkRegion (region);
  region->distinguished_representant = distinguished_representant;

  for (equivalence_table_node = region->equivalent_nodes
       ; equivalence_table_node != (BINSEG_EquivalenceTableNode) 0
       ; equivalence_table_node = equivalence_table_node->next) {
    BINSEG_RegionLabel next_label;
    BINSEG_Region next_region;
    next_label = equivalence_table_node->label;
    next_region = &equivalence_table->slots[next_label];

    if (!BINSEG_MarkedRegionP (next_region)) {
      depth_first_search (equivalence_table
			  ,next_region
			  ,distinguished_representant);
    }
  }
}

void
_BINSEG_RelabelImage (BINSEG_RegionLabel *image
                      ,unsigned int width
                      ,unsigned int height
		      ,BINSEG_EquivalenceTable equivalence_table
		      ,unsigned int *numregions)
{
  int w = width;
  int h = height;
  BINSEG_RegionLabel *image_ptr;
  int i;

  assert (equivalence_table->number_of_used_slots
	  <= equivalence_table->max_region_label);

  assert (equivalence_table->number_of_resolved_slots
	  == equivalence_table->resolved_max_region_label);

  for (i = 0; i < equivalence_table->number_of_resolved_slots; i++) {
    equivalence_table->resolved_slots[i].region_size = 0;
  }

  for (image_ptr = image
       ; image_ptr < image + w * h
       ; image_ptr++) {
    BINSEG_RegionLabel label, new_label;
    label = *image_ptr;
    if (label != BINSEG_NULL_REGION_LABEL) {
      if (label <= equivalence_table->number_of_used_slots) {
	new_label = equivalence_table->slots[label].label;
      }
      else {
	assert (label <= equivalence_table->max_region_label);
	new_label = label - (int) equivalence_table->number_of_used_slots
                          + equivalence_table->resolved_max_region_label;
      }
      assert (new_label <= equivalence_table->number_of_resolved_slots);
      assert (new_label > 0);

      equivalence_table->resolved_slots[new_label - 1].region_size++;
      *image_ptr = new_label;
    }
  }

  *numregions = equivalence_table->max_region_label
    - (int) equivalence_table->number_of_used_slots
    + equivalence_table->resolved_max_region_label;
}

BINSEG_Status
_BINSEG_SetRegionFirstPixelIndex (BINSEG_EquivalenceTable equivalence_table
				  ,BINSEG_RegionLabel region_label
				  ,unsigned int first_pixel_index)
{
  BINSEG_Status err = BINSEG_Succeed;

  assert (equivalence_table != (BINSEG_EquivalenceTable) 0);
  assert (region_label != BINSEG_NULL_REGION_LABEL);

  if (region_label >= equivalence_table->number_of_slots) {
    if ((err = _BINSEG_IncreaseEquivalenceTableSize
        (equivalence_table, region_label))
	    != BINSEG_Succeed)
      return err;
  }

  equivalence_table->number_of_used_slots
    = BINSEG_MAX_REGION_LABEL (region_label
			       ,equivalence_table->number_of_used_slots);
  BINSEG_UnSetResolvedFlag (equivalence_table);

  equivalence_table->slots[region_label].first_pixel_index = first_pixel_index;

  return err;
}

void
_BINSEG_DumpEquivalenceTable (BINSEG_EquivalenceTable equivalence_table)
{
  BINSEG_RegionLabel label;
  int i;

  (void) fprintf (stdout, "==========================\nEquivalence Table\n");
  if (equivalence_table == 0) {
    (void) fprintf (stdout, " NULL equivalence table\n");
    return;
  }

  (void) fprintf (stdout, "  Slots number:%u used:%u"
		  ,equivalence_table->number_of_slots
		  ,equivalence_table->number_of_used_slots);
  (void) fprintf (stdout, "  Region labels  max:%u"
		  ,equivalence_table->max_region_label);
  if (BINSEG_EquivalenceTableResolvedP (equivalence_table)) {
    (void) fprintf (stdout, " resolved max:%u"
		    ,equivalence_table->resolved_max_region_label);
  }

  (void) fprintf (stdout, "\n");

  if (!BINSEG_EquivalenceTableResolvedP (equivalence_table)) {
    (void) fprintf (stdout, "  Slots content (table is UNRESOLVED)\n");

    for (i = 0; i <= equivalence_table->number_of_used_slots; i++) {
      struct _BINSEG_EquivalenceTableNode *equivalence_table_node;
      label = equivalence_table->slots[i].label;
      (void) fprintf (stdout, "    %d label=%u first pixel=%u  "
		      ,i, label
		      ,equivalence_table->slots[i].first_pixel_index);
      for (equivalence_table_node
	= equivalence_table->slots[i].equivalent_nodes
	; equivalence_table_node != (BINSEG_EquivalenceTableNode) 0
	; equivalence_table_node = equivalence_table_node->next) {
	  (void) fprintf (stdout, "->%u", equivalence_table_node->label);
      }
      (void) fprintf (stdout, "\n");
    }
  }
  else {
    (void) fprintf (stdout, "  Slots content (table is RESOLVED)\n");

    for (i = 0; i <= equivalence_table->number_of_used_slots; i++) {
      label = equivalence_table->slots[i].label;
      (void) fprintf (stdout, "    %d label=%u\n"
			  ,i, label);
    }
    (void) fprintf (stdout, "  Resolved slots content\n");

    for (i = 0; i < equivalence_table->number_of_resolved_slots; i++) {
      label = equivalence_table->resolved_slots[i].label;
      (void) fprintf (stdout, "    %d label=%u first pixel=%u size=%u\n"
		     ,i, label
		     ,equivalence_table->resolved_slots[i].first_pixel_index
	             ,equivalence_table->resolved_slots[i].region_size
	    );
    }
  }
}

void
_BINSEG_DumpResolvedEquivalenceTable (BINSEG_EquivalenceTable equivalence_table)
{
  BINSEG_RegionLabel label;
  int i;

  (void) fprintf (stdout, "==========================\nEquivalence Table\n");
  if (equivalence_table == 0)
    {
      (void) fprintf (stdout, " NULL equivalence table\n");
      return;
    }

  (void) fprintf (stdout, "  Slots number:%u used:%u"
		  ,equivalence_table->number_of_slots
		  ,equivalence_table->number_of_used_slots);
  (void) fprintf (stdout, "  Region labels  max:%u"
		  ,equivalence_table->max_region_label);
  if (BINSEG_EquivalenceTableResolvedP (equivalence_table))
    {
      (void) fprintf (stdout, " resolved max:%u\n"
		      ,equivalence_table->resolved_max_region_label);

      (void) fprintf (stdout, "  Resolved slots content\n");

      for (i = 0; i < equivalence_table->number_of_resolved_slots; i++)
	{
	  label = equivalence_table->resolved_slots[i].label;
	  (void) fprintf (stdout, "    %d label=%u first pixel=%u size=%u\n"
			  ,i, label
		     ,equivalence_table->resolved_slots[i].first_pixel_index
			  ,equivalence_table->resolved_slots[i].region_size
	    );
	}
    }
  else
    {
      (void) fprintf (stdout, " NON RESOLVED equivalence table\n");
      return;
    }
}
