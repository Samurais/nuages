#ifndef lint
static  char *sccsid = "@(#)followContour.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include <assert.h>
#include <malloc.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"

int _BINSEG_FourNeighborsDx[] =
{-1, 0, 1, 0};
int _BINSEG_FourNeighborsDy[] =
{0, -1, 0, 1};

BINSEG_Status
_BINSEG_FollowBorder (BINSEG_Pixel *binary_image
		      ,unsigned int width
		      ,unsigned int height
		      ,BINSEG_Pixel foreground_pixel
		      ,BINSEG_Connectedness connectedness
		      ,_BINSEG_BorderPoint *border_points
		      ,unsigned int max_number_of_border_points
		      ,unsigned int *number_of_border_points
		      ,_BINSEG_BorderPoint *first_point)

{
  BINSEG_Status err = BINSEG_Succeed;
  unsigned int n_border = 0;
  int X_x, X_y, Y_x, Y_y, x_first, y_first;
  int w = width;
  int h = height;
  int dx, dy;
  BINSEG_4Orientation orientation, orientation_first;

  X_x = x_first = first_point->x;
  X_y = y_first = first_point->y;
  orientation = orientation_first = first_point->orientation;

#define PixelSetP(x,y)\
  ((x)>=0 && (x)<w && (y)>=0 && (y)<h &&\
   BINSEG_IsPixelEqualToValue(binary_image, w, h, (x), (y), foreground_pixel))

  do
    {
      unsigned int a, b;
      int A_x, A_y, B_x, B_y;

      if (n_border < max_number_of_border_points)
	{
	  border_points[n_border].x = X_x;
	  border_points[n_border].y = X_y;
	  border_points[n_border].orientation = orientation;
	  n_border++;
	}
      else
	{
	  err = BINSEG_ErrMemAlloc;
	  break;
	}

      dx = _BINSEG_FourNeighborsDx[orientation];
      dy = _BINSEG_FourNeighborsDy[orientation];

      Y_x = X_x + dx;
      Y_y = X_y + dy;

      A_x = X_x - dy;
      A_y = X_y + dx;

      B_x = X_x + dx - dy;
      B_y = X_y + dy + dx;

      if (PixelSetP (A_x, A_y))
	a = 1;
      else
	a = 0;

      if (PixelSetP (B_x, B_y))
	b = 1;
      else
	b = 0;

      assert (PixelSetP (X_x, X_y));
      assert (!PixelSetP (Y_x, Y_y));

      if (a == 0)
	{
	  if (b == 1 && connectedness == BINSEG_8_Connectedness)
	    {
	      X_x = B_x;
	      X_y = B_y;
	      if (orientation == 0)
		orientation = 4;
	      orientation--;
	    }
	  else
	    {
	      if (++orientation == 4)
		orientation = 0;
	    }
	}
      else
	{
	  if (b == 0)
	    {
	      X_x = A_x;
	      X_y = A_y;
	    }
	  else
	    {
	      X_x = B_x;
	      X_y = B_y;
	      if (orientation == 0)
		orientation = 4;
	      orientation--;
	    }
	}
    }

  while (!
	 (X_x == x_first
	  && X_y == y_first
	  && orientation == orientation_first));
  *number_of_border_points = n_border;
  return err;
}
