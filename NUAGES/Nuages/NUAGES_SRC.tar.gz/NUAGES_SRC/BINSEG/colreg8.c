#ifndef lint
static  char *sccsid = "@(#)colreg8.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include "BINSEGP.h"
#include "BINSEGInt.h"

BINSEG_Status
_BINSEG_ColorRegions8 (BINSEG_Pixel *image
                       ,unsigned int width
                       ,unsigned int height
		       ,BINSEG_Pixel foreground_pixel
		       ,BINSEG_EquivalenceTable equivalence_table
		       ,BINSEG_RegionLabel *region_numbered_image
		       ,unsigned int *numregions_arg)
{
  int w = width, h = height;
  BINSEG_Status err = BINSEG_Succeed;
  unsigned int numregions = 0;
  BINSEG_Pixel *image_ptr;
  BINSEG_RegionLabel *region_numbered_image_ptr;
  BINSEG_RegionLabel neighbor_label, neighbor1_label
   ,neighbor2_label, neighbor3_label
   ,label;
  BINSEG_RegionLabel *neighbor3_ptr;
  int distance_to_end_of_line;
  unsigned int pixel_index;

  for (pixel_index = 0
       ,image_ptr = image
       ,region_numbered_image_ptr = region_numbered_image
       ,neighbor_label = BINSEG_NULL_REGION_LABEL
       ; image_ptr < image + w
       ; image_ptr++
       ,region_numbered_image_ptr++
       ,pixel_index++)
    {
      if (*image_ptr == foreground_pixel)
	{
	  if (neighbor_label == BINSEG_NULL_REGION_LABEL)
	    {
	      /* create a new region */
	      numregions++;
	      label = numregions;
	      if ((err = _BINSEG_SetRegionFirstPixelIndex
		   (equivalence_table, label, pixel_index))
		  != BINSEG_Succeed)
		return err;
	    }
	  else
	    {
	      label = neighbor_label;
	    }
	}
      else
	label = BINSEG_NULL_REGION_LABEL;

      neighbor_label = *region_numbered_image_ptr = label;
    }

  for (pixel_index = w
       ,image_ptr = image + w
       ,neighbor3_ptr = region_numbered_image + 1
       ,region_numbered_image_ptr = region_numbered_image + w
       ,neighbor_label = BINSEG_NULL_REGION_LABEL
       ,neighbor1_label = BINSEG_NULL_REGION_LABEL
       ,neighbor2_label = *region_numbered_image
       ,distance_to_end_of_line = w - 1
       ; image_ptr < image + w * h
       ; region_numbered_image_ptr++
       ,neighbor3_ptr++
       ,image_ptr++
       ,pixel_index++)
    {
      if (distance_to_end_of_line == 0)
	neighbor3_label = BINSEG_NULL_REGION_LABEL;
      else
	neighbor3_label = *neighbor3_ptr;

      label = BINSEG_NULL_REGION_LABEL;

#define ConnectedWith(label)\
	  ((label) != BINSEG_NULL_REGION_LABEL)
#define COLLISION(label1,label2)\
		  { if ((err = _BINSEG_RegisterRegionsCollision \
			(equivalence_table,label1,label2))!=BINSEG_Succeed)\
			goto error_label; }

      if (*image_ptr == foreground_pixel)
	{
	  if (ConnectedWith (neighbor_label))
	    {
	      label = neighbor_label;
	      if (!ConnectedWith (neighbor2_label)
		  && ConnectedWith (neighbor3_label))
		{
		  COLLISION (label, neighbor3_label);
		}
	    }
	  else if (ConnectedWith (neighbor2_label))
	    {
	      label = neighbor2_label;
	    }
	  else if (ConnectedWith (neighbor1_label))
	    {
	      label = neighbor1_label;
	      if (ConnectedWith (neighbor3_label))
		{
		  COLLISION (label, neighbor3_label);
		}
	    }
	  else if (ConnectedWith (neighbor3_label))
	    {
	      label = neighbor3_label;
	    }
	  else
	    {
	      /* create a new region */
	      numregions++;
	      label = numregions;
	      if ((err = _BINSEG_SetRegionFirstPixelIndex
		   (equivalence_table, label, pixel_index))
		  != BINSEG_Succeed)
		return err;
	    }
	}

      neighbor_label = *region_numbered_image_ptr = label;

#ifndef BOGGUS
      neighbor1_label = neighbor2_label;
      neighbor2_label = neighbor3_label;
#endif
      if (distance_to_end_of_line == 0)
	{
	  neighbor_label = BINSEG_NULL_REGION_LABEL;
#ifndef BOGGUS
	  neighbor1_label = BINSEG_NULL_REGION_LABEL;
	  neighbor2_label = *neighbor3_ptr;
#endif
	  distance_to_end_of_line = w - 1;
	}
      else
	distance_to_end_of_line--;
    }

  *numregions_arg = numregions;
error_label:
  return err;
}
