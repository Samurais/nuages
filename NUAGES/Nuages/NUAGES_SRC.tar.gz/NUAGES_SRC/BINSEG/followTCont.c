#ifndef lint
static  char *sccsid = "@(#)followTCont.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include <assert.h>
#include <malloc.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"

BINSEG_Status
_BINSEG_FollowTypedBorder (BINSEG_Pixel *binary_image
			   ,unsigned int width
			   ,unsigned int height
			   ,BINSEG_Pixel foreground_pixel
			   ,BINSEG_Connectedness connectedness
			   ,_BINSEG_BorderPoint *border_points
			   ,unsigned int max_number_of_border_points
			   ,unsigned int *number_of_border_points
			   ,unsigned int first_pixel_index
			   ,int doing_background)
{
  BINSEG_Status err = BINSEG_Succeed;
  int x, y;
  int w = width;
  int h = height;
  _BINSEG_BorderPoint first_point;

  x = first_pixel_index % w;
  y = first_pixel_index / w;

  assert (x >= 0 && x < w && y >= 0 && y < h);

  if (doing_background)
    {
      assert (x > 0 && x < w - 1);
      assert (y > 0 && y < h - 1);
      assert (!BINSEG_IsPixelEqualToValue
	      (binary_image, w, h, x, y, foreground_pixel));
      assert (BINSEG_IsPixelEqualToValue
	      (binary_image, w, h, x - 1, y, foreground_pixel));
      assert (BINSEG_IsPixelEqualToValue
	      (binary_image, w, h, x, y - 1, foreground_pixel));
      first_point.x = x - 1;
      first_point.y = y;
      first_point.orientation = BINSEG_West;
    }
  else
    {
      assert (BINSEG_IsPixelEqualToValue
	      (binary_image, w, h, x, y, foreground_pixel));
      assert (x == 0 ||
	      (!BINSEG_IsPixelEqualToValue
	       (binary_image, w, h, x - 1, y, foreground_pixel)));
      assert (y == 0 ||
	      (!BINSEG_IsPixelEqualToValue
	       (binary_image, w, h, x, y - 1, foreground_pixel)));
      first_point.x = x;
      first_point.y = y;
      first_point.orientation = BINSEG_East;
    }
#ifdef DEBUG
  (void) fprintf (stdout, "follow border x=%d y=%d (pixel=%d)"
		  ,first_point.x, first_point.y
		  ,first_pixel_index
    );
  if (doing_background)
    (void) fprintf (stdout, "(background border)\n");
  else
    (void) fprintf (stdout, "(foreground border)\n");
#endif

  err = _BINSEG_FollowBorder (binary_image
			      ,width
			      ,height
			      ,foreground_pixel
			      ,connectedness
			      ,border_points
			      ,max_number_of_border_points
			      ,number_of_border_points
			      ,&first_point);

  return err;
}
