#ifndef lint
static  char *sccsid = "@(#)colregInf.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include "BINSEGP.h"
#include "BINSEGInt.h"

BINSEG_Status
_BINSEG_ColorRegionsInfinite (BINSEG_Pixel *image
                              ,unsigned int width
                              ,unsigned int height
			      ,BINSEG_Pixel foreground_pixel
			      ,BINSEG_RegionLabel *region_numbered_image
			      ,unsigned int *numregions_arg)
{
  BINSEG_Status err = BINSEG_Succeed;
  unsigned int numregions = 0;
  BINSEG_Pixel *image_ptr;
  BINSEG_RegionLabel *region_numbered_image_ptr;
  /*
   * on a sun3 defining DBRA saves 10% of running time
   * on a sparc it actually increases it
   * a real dbra instruction is not safe anyway on a 68x00
   * since it restrict th size of the image to 64k -1
   */
  int w = width;
  int h = height;

  for (image_ptr = image
       ,region_numbered_image_ptr = region_numbered_image
       ; image_ptr < image + w * h
       ; region_numbered_image_ptr++
       ,image_ptr++) {

    if (*image_ptr == foreground_pixel) {

#ifndef SLIGHTLY_BOGGUS
      numregions = 1;
#endif
      *region_numbered_image_ptr = 1;
    }
    else
      *region_numbered_image_ptr = BINSEG_NULL_REGION_LABEL;
  }

#ifdef SLIGHTLY_BOGGUS
  numregions = 1;		/*
				 * may be wrong if image is all blank
				 * this does not affect performance
				 * at all on a sun4
				 */
#endif

  *numregions_arg = numregions;
  return err;
}
