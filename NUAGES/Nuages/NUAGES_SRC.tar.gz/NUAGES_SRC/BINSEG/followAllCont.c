#ifndef lint
static  char *sccsid = "@(#)followAllCont.c	1.1 97/04/10";
#endif

/************************************************************************
 *                                                                      *
 * copyright (c) 1993 Bernhard Geiger                                   *
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 ************************************************************************/


#include <assert.h>
#include <malloc.h>
#include "BINSEGP.h"
#include "BINSEGInt.h"
#include "BINSEGIntEqTable.h"

static BINSEG_Status _BINSEG_FollowAllBordersAux (BINSEG_Pixel *, unsigned int, unsigned int, BINSEG_Pixel, BINSEG_Connectedness, BINSEG_EquivalenceTable, BINSEG_SegmentedImageRegionRec *, unsigned int, int);

BINSEG_Status
_BINSEG_FollowAllBorders (BINSEG_SegmentedImage segmented_image
			  ,BINSEG_Pixel *binary_image
			  ,BINSEG_EquivalenceTable foreground_equivalence_table
			  ,BINSEG_EquivalenceTable background_equivalence_table)
{
  BINSEG_Status err = BINSEG_Succeed;
  int doing_background;

  doing_background = 0;
  if ((err = _BINSEG_FollowAllBordersAux (binary_image
					  ,segmented_image->width
					  ,segmented_image->height
					  ,segmented_image->foreground_pixel
					  ,segmented_image->connectedness
					  ,foreground_equivalence_table
					,segmented_image->foreground_regions
			      ,segmented_image->number_of_foreground_regions
					  ,doing_background
       ))
      == BINSEG_Succeed)
    {
      doing_background = 1;
      err = _BINSEG_FollowAllBordersAux (binary_image
					 ,segmented_image->width
					 ,segmented_image->height
					 ,segmented_image->foreground_pixel
					 ,segmented_image->connectedness
					 ,background_equivalence_table
					 ,segmented_image->background_regions
			      ,segmented_image->number_of_background_regions
					 ,doing_background
	);
    }

  return err;

}

static BINSEG_Status
_BINSEG_FollowAllBordersAux (BINSEG_Pixel *binary_image
			     ,unsigned int width
			     ,unsigned int height
			     ,BINSEG_Pixel foreground_pixel
			     ,BINSEG_Connectedness connectedness
			     ,BINSEG_EquivalenceTable equivalence_table
			     ,BINSEG_SegmentedImageRegionRec *regions
			     ,unsigned int number_of_regions
			     ,int doing_background)
{
  BINSEG_Status err = BINSEG_Succeed;
  int i;
  _BINSEG_BorderPoint *tmp_border_points = (_BINSEG_BorderPoint *) 0;
  _BINSEG_BorderPoint *border_points;
  unsigned int number_of_finite_regions;
  unsigned int max_number_of_border_points;
  unsigned int number_of_border_points;
  unsigned int first_pixel_index;

  assert (BINSEG_EquivalenceTableResolvedP (equivalence_table));

  for (i = 0, number_of_finite_regions = 0
       ; i < equivalence_table->number_of_resolved_slots
       ; i++)
    {

      first_pixel_index
	= equivalence_table->resolved_slots[i].first_pixel_index;

      if (doing_background && first_pixel_index == 0)
	continue;
      if (doing_background)
	{
	  int x = first_pixel_index % (width + 2);
	  int y = first_pixel_index / (width + 2);
	  assert (first_pixel_index < (width + 2) * (height + 2));
	  x--;
	  y--;
	  assert (x > 0);
	  assert (y > 0);
	  assert (x < width - 1);
	  assert (y < height - 1);

	  /* the background region coloring is done
	     * on a bordered image, indexes have to
	     * be transformed
	   */

	  first_pixel_index = x
	    + width * y;
	}
      max_number_of_border_points
	= 4 * equivalence_table->resolved_slots[i].region_size;
      number_of_border_points = 0;

      if ((tmp_border_points = (_BINSEG_BorderPoint *) malloc
	   (sizeof (*tmp_border_points) * max_number_of_border_points))
	  == (_BINSEG_BorderPoint *) 0)
	break;

      if ((err = _BINSEG_FollowTypedBorder (binary_image
					    ,width
					    ,height
					    ,foreground_pixel
					    ,connectedness
					    ,tmp_border_points
					    ,max_number_of_border_points
					    ,&number_of_border_points
					    ,first_pixel_index
					    ,doing_background))
	  != BINSEG_Succeed)
	break;
      else
	{
	  assert (number_of_border_points != 0);

	  if ((border_points = (_BINSEG_BorderPoint *) malloc
	       (sizeof (*border_points) * number_of_border_points))
	      == (_BINSEG_BorderPoint *) 0)
	    {
	      err = BINSEG_ErrMemAlloc;
	      break;
	    }
	  else
	    {
	      int bcopy_size;
	      assert (number_of_finite_regions < number_of_regions);
	      bcopy_size = sizeof (*border_points)
		* number_of_border_points;

	      (void) bcopy ((char *) tmp_border_points
			    ,(char *) border_points
			    ,bcopy_size);
	      regions[number_of_finite_regions].border_points
		= border_points;
	      regions[number_of_finite_regions].number_of_border_points
		= number_of_border_points;
	      regions[number_of_finite_regions].size
		= equivalence_table->resolved_slots[i].region_size;
	      regions[number_of_finite_regions].first_pixel_index =
		first_pixel_index;
	    }
	}
      free ((malloc_t) tmp_border_points);
      tmp_border_points = (_BINSEG_BorderPoint *) 0;
      number_of_finite_regions++;
    }

  if (tmp_border_points != (_BINSEG_BorderPoint *) 0)
    free ((malloc_t) tmp_border_points);

  if (err == BINSEG_Succeed)
    assert (number_of_finite_regions == number_of_regions);

  return err;
}
