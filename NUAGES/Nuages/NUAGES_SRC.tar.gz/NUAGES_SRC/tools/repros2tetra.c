#ifndef lint
static  char *sccsid = "%W% %D%";
#endif

/************************************************************************ 
 * repros2tetra.c   Version 2.0  Oct 14 1993				* 
 * repros-output -> tetra format					* 
 *									* 
 * Copyright 1993 Bernhard Geiger					* 
 *									* 
 *									* 
 ************************************************************************/ 
/************************************************************************
 *                      Modification History                            *
 * Apr 15 1997 in main() t1->nb/t1/t2/t12 initialized			*
 * Apr 10 1997 in memory_alloc cast in size_t instead of int            *
 * Dec  8 1996 Bug in numerate(), speedup				*
 * Apr 15 1996 Usage() corrected					*
 * Jan 25 1995 translated to ANSI C                                     *
 * Dec 29 1994 #ifndef VMS_NUAGES added, minor bug detected		*
 * Jul 19 1994 option -statistic added					*
 ************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <strings.h>

#ifndef VMS_NUAGES
#include <malloc.h>
#endif

#ifndef FALSE
#define FALSE 0
#define TRUE  1
#endif


#define MAXVERTEX 20000               /*max number of points per cross-section*/
#define MAX_TETRA (4*(MAXVERTEX - 1)) /*max number of triangles per slice */
#define MAX_CC    100                 /*max number of connected components */


typedef float KOORD [MAXVERTEX][2];          /* coordinates x,y */
typedef float POINTNORM [MAXVERTEX][3];      /* normals of each point*/
typedef int   TETRA [MAX_TETRA][4];        /* tetrahedron */
typedef int   NBOR [MAX_TETRA][4];
typedef short   TYP  [MAX_TETRA];

#define T1      0x1
#define T2      0x2
#define T12     0x4
#define ELIM    0x8
#define Elim(S,i)        ((*(S->typ))[i] & ELIM)
#define Is_t1(S,i)      ((*(S->typ))[i] & T1)
#define Is_t2(S,i)      ((*(S->typ))[i] & T2)
#define Is_t12(S,i)     ((*(S->typ))[i] & T12)
#define Not_Elim(S,i)    (!Elim(S,i))
#define No_t1(S,i)      (!Is_t1(S,i))
#define No_t2(S,i)      (!Is_t2(S,i))
#define No_t12(S,i)     (!Is_t12(S,i))
#define ODD(x) ((x) & 1)



typedef
  struct plane {        /**** description of one cross-section */
    int start,stop;     /*nb of first and last point of one cross-section*/
    float z;            /*z-coordinate of cross-section*/
    KOORD *point;       /*x,y-coordinates of points*/
    char *s_ptr;       /*pointer to available memory*/
  } PLANE;

typedef
  struct tetra_slice {    /**** description of one slice */
    int nb;             /* nb of triangles */
    int   nb_t1;
    int   nb_t2;
    int   nb_t12;
    TETRA *tetra;       /* triangles */
    NBOR  *neighbor;
    TYP   *typ;
    TYP   *obj;
    PLANE *pl0, *pl1;
  } TETRA_SLICE;

/* globals */

int   remove_h[10];
char  *(fnam[4]);
FILE  *koord_file,*tetra_file,*out_file,*act_file;
int   tetra_buffer[4];
int   neighbor_buffer[4];
int   koord_count = 0;
int   tetra_count = 0;
short horizontal = 0;  /* do not remove horizontal triangles */
short n_remove = 0;
short n_nosmooth = 0;
int   nosmooth[10];
short plane_counter = 0;
int   nb_slices = 0;
int   nb_sections = 0;
short act_out = FALSE;
int   vertex_out = TRUE;
char  *obj_name = "object";
char  *header = "";
float scale = 10.0;
int   obj_nb = 0;
int   off1, off2, off3;
int   Maxvertex, Maxtetra, mv_changed, mf_changed;
int   nb_elim_tetras = 0;
int   nb_inside_tetras = 0;
int   Max_cc = MAX_CC;
int   *cc_list;
int   cc_reread = FALSE;
int   do_statistics = FALSE;
float *volume_list;
int   nb_test = 0;

double tetra_volume(int i, TETRA_SLICE *tetra);
void read_points(PLANE *pl);
void read_tetra(TETRA_SLICE *tetra, PLANE *pl1, PLANE *pl2);
void connect_double(TETRA_SLICE *tetra0, TETRA_SLICE *tetra1);
void memory_alloc(TETRA_SLICE *,TETRA_SLICE *,PLANE *,PLANE *,PLANE *,char **);
void numerate(TETRA_SLICE *tetra0, TETRA_SLICE *tetra1);
void mark(int i, TETRA_SLICE *tetra0, TETRA_SLICE *tetra1, int nb);
void write_new_tetra(TETRA_SLICE *tetra, PLANE *pl0, PLANE *pl1);
void write_points(PLANE *pl);
void grab_arguments(int argc, char **argv);
int count_cc(void);
void change_cc(void);
int equal(int a, int b, int (*simp1)[4], int (*simp2)[4]);
void add_cc(int a, int b);
void Usage(void);



main(int argc, char **argv)
/********************************************************************/
/*                                                                  */
/*         main                                                     */
/*                                                                  */
/*                                                                  */
/********************************************************************/
         
            

{
  TETRA_SLICE tetra_0, tetra_1;
  TETRA_SLICE *t0, *t1, *help_tetra;
  PLANE plane0, plane1, plane2;      /*3 cross-sections for 2 adj. slices*/
  PLANE *pl0, *pl1, *pl2, *help_pl;
  char *work_buffer;
  int i;
  char str[10];

  Maxvertex = MAXVERTEX;
  Maxtetra = 4 * (Maxvertex-1);

 
  grab_arguments(argc, argv);

  if ( mv_changed && !mf_changed )
    Maxtetra = 4 * (Maxvertex-1);
 
  tetra_file = fopen(fnam[0], "r");
  if (tetra_file == NULL) {
    fprintf(stderr , "tetra-file not found\n");
    fflush(stderr);
    exit(1);
  }
  koord_file = fopen(fnam[1], "r");
  if (koord_file == NULL) {
    fprintf(stderr , "coord-file not found\n");
    fflush(stderr);
    exit(1);
  }
  fscanf(koord_file, "%s%d",str, &nb_sections);

  out_file = fopen(fnam[2], "w");
  if (out_file == NULL) {
    fprintf(stderr , "cannot open output\n");
    fflush(stderr);
    exit(1);
  }
  if( strlen(header) != 0 ) 
    fprintf(out_file, "%s\n", header);

  fscanf(tetra_file,"%d", &nb_slices);
  if (nb_slices != nb_sections-1) {
    fprintf(stderr,"  error: %d sections vs %d slices\n", nb_sections, nb_slices);
    exit(1);
  }
  fprintf(out_file,"S %d\n", nb_slices);

  pl0 = &plane0;
  pl1 = &plane1;
  pl2 = &plane2;

  t0 = &tetra_0;
  t1 = &tetra_1;

  memory_alloc(t0,t1,pl0,pl1,pl2,&work_buffer);

  pl0->start = 0;
  pl0->stop = 0;

  read_points(pl0);   /*read points of first cross-section */
  if (vertex_out ) write_points(pl0);
  read_points(pl1);   /*read points of first cross-section */
  read_tetra(t0,pl0,pl1); /*read triangles of one slice*/
  off1 = 0; off2 = 0; off3 = t0->nb;
  plane_counter++;
  printf("slice #1\n");

  for (i=1 ; i<nb_slices ; i++) {
    read_points(pl2); /*read points of following cross-section*/
    plane_counter++;
    read_tetra(t1,pl1,pl2); /*read triangles of one slice*/
    printf("slice #%d\n",i+1);

    connect_double(t0,t1);
    numerate(t0,t1);

    write_new_tetra(t0, pl0, pl1);
    if (vertex_out ) write_points(pl1);

    off1 = off2;
    off2 = off3;
    off3 = off3 + t1->nb;

    help_tetra = t0; t0 = t1; t1 = help_tetra; /*turn around*/
    help_pl = pl0; pl0 = pl1; pl1 = pl2; pl2 = help_pl; /*also*/
  }

  t1->nb = t1->nb_t1 = t1->nb_t12 = t1->nb_t2 = 0;
  numerate(t0,t1);

  write_new_tetra(t0, pl0, pl1); /*write last slice*/
  if (vertex_out ) write_points(pl1);

  fclose(out_file);
  fclose(koord_file);
  fclose(tetra_file);
  printf("nb of tetrahedra: %d  (%d inside  %d outside)\n",
           nb_inside_tetras+nb_elim_tetras, nb_inside_tetras, nb_elim_tetras);
  /*printf("%d connected component(s)\n", obj_nb);*/
  count_cc();
  if (cc_reread) 
    change_cc();
  exit(0);
}


void read_points(PLANE *pl)
/********************************************************************/
/*   Read points of one cross section.                              */
/********************************************************************/
          
{
  float z;
  int i;
  int nb_pts;
  char s1[10], s2[10];

  fscanf( koord_file, "%s%d%s%f",s1, &nb_pts, s2, &z );
  if (nb_pts >= Maxvertex) {
    fprintf(stderr,"Vertex overflow (> %d)  use option -max_vertex\n", Maxvertex);
    fflush(stderr);
    exit(1);
  }

  pl->start = koord_count;
  pl->z = z;
  for (i=0; i<nb_pts ; i++) {
    if( fscanf(koord_file,"%f",&((*(pl->point))[i][0])) == EOF) {
      fprintf(stderr,"error reading coords (EOF)\n");
      exit(1);
    }
    fscanf( koord_file, "%f", &((*(pl->point))[i][1]));

  }
  koord_count = koord_count + nb_pts;
  pl->stop = koord_count;
}



void read_tetra(TETRA_SLICE *tetra, PLANE *pl1, PLANE *pl2)
/********************************************************************/
/* Read the triangles of one slice.                                 */
/********************************************************************/
                   
                 
{
  int j,i = 0;
  int nb1, nb2;
  int typ;
 
  tetra->pl0 = pl1;
  tetra->pl1 = pl2;

  fscanf(tetra_file,"%d%d%d",&tetra->nb, &nb1, &nb2);
  if (tetra->nb > Maxtetra) { /*XXXXX*/
    fprintf(stderr,"too many tetrahedra [%d needed] \n", Maxtetra);
    exit(2);
  }
  tetra->nb_t1 = tetra->nb_t2 = tetra->nb_t12 = 0;
  for(i=0 ; i<tetra->nb ; i++) {
    fscanf( tetra_file, "%d%d%d%d%d%d%d%d%d", &tetra_buffer[0],
                        &tetra_buffer[1], &tetra_buffer[2], &tetra_buffer[3],
                        &neighbor_buffer[0],&neighbor_buffer[1],
                        &neighbor_buffer[2],&neighbor_buffer[3],
                        &typ);
    for (j=0 ; j<4; j++) 
      (*(tetra->tetra))[i][j] = tetra_buffer[j]-2; /* !!!! neu !!!! */
    for (j=0 ; j<4; j++) 
      (*(tetra->neighbor))[i][j] = neighbor_buffer[j]-1;
    (*(tetra->typ))[i] = (short)typ;
    (*(tetra->obj))[i] = 0;
    if (typ & ELIM)
      nb_elim_tetras++;
    else
      nb_inside_tetras++;

    if (typ & T1)
      tetra->nb_t1++;
    else
      if (typ & T2)
        tetra->nb_t2++;
      else
        tetra->nb_t12++;
  }
}



void connect_double(TETRA_SLICE *tetra0, TETRA_SLICE *tetra1)
{
 register int i,j,k;
 int old = 0;

 for (i=tetra0->nb_t1 ; i< tetra0->nb_t1 + tetra0->nb_t2 ; i++)
   for (k=0, j=old ; k<tetra1->nb_t1 ; k++, j=(j==tetra1->nb_t1-1)?0:j+1)
     if ( (*(tetra0->tetra))[i][0] == ((*(tetra1->tetra))[j][0] | 0x1) &&
          (*(tetra0->tetra))[i][1] == ((*(tetra1->tetra))[j][1] | 0x1) &&
         (*(tetra0->tetra))[i][2] == ((*(tetra1->tetra))[j][2] | 0x1) ) {
       (*(tetra0->neighbor))[i][3] = j;
       (*(tetra1->neighbor))[j][3] = i;
       old=j+1;
       break;
     }
}




int equal(int a, int b, int (*simp1)[4], int (*simp2)[4])
/************************************************************************
 *returns 1 if triangle a and b are equal ,   else 0			*
 * Use the fact that if tri are equal, their vertice in same order	*
 ************************************************************************/
        
               
               

{
  if(simp1[a][0]-1 == simp2[b][0] &&
     simp1[a][1]-1 == simp2[b][1] &&
     simp1[a][2]-1 == simp2[b][2]){
    return(1);
  }
  else return(0);
}




void memory_alloc(TETRA_SLICE *t0, TETRA_SLICE *t1, PLANE *pl0, PLANE *pl1, PLANE *pl2, char **work_buffer)
{
  register int i;
  int point_size, neighbor_size, typ_size, tetra_size;
  unsigned int wkb_size;

  point_size =    Maxvertex * 2 * sizeof(float); 
  tetra_size =    Maxtetra * 4 * sizeof(int);
  neighbor_size = Maxtetra * 4 * sizeof(int);
  typ_size =      Maxtetra * sizeof(char);
  wkb_size =      3*point_size       /*                      */

                + 2*tetra_size         /*   2 slices           */
                + 2*neighbor_size
                + 4*typ_size;

  /*memory allocation */
  *work_buffer = (char *)malloc( wkb_size); /* XXXXX */
  if (*work_buffer == NULL) { 
    fprintf(stderr,"malloc failed [%dkB]\n", wkb_size/1024);
    fflush(stderr);
    exit(1);
  }

  pl0->point = (KOORD *)(*work_buffer);

  pl1->point = (KOORD *)((char *)pl0->point + point_size);
  
  pl2->point = (KOORD *)((char *)pl1->point + point_size);


  t0->tetra = (TETRA *)((char *)pl2->point + point_size);
  t0->neighbor = (NBOR *)((char *)t0->tetra + tetra_size);
  t0->typ = (TYP *)((char *)t0->neighbor + neighbor_size);
  t0->obj = (TYP *)((char *)t0->typ + typ_size);
  t1->tetra = (TETRA *)((char *)t0->obj + typ_size);
  t1->neighbor = (NBOR *)((char *)t1->tetra + tetra_size);
  t1->typ = (TYP *)((char *)t1->neighbor + neighbor_size);
  t1->obj = (TYP *)((char *)t1->typ + typ_size);

  if( (size_t)((char *)t1->obj+typ_size) - (size_t)(*work_buffer)>wkb_size ) {
    printf("error memory alloc\n");
    exit(1);
  }
  cc_list = (int *)malloc(Max_cc*sizeof(int));
  if (cc_list == NULL) { 
    fprintf(stderr,"malloc failed [%dkB]\n", Max_cc*sizeof(int)/1024);
    fflush(stderr);
    exit(1);
  }
  for (i=0; i< Max_cc; i++)
    cc_list[i] = i;

  if (do_statistics) {
    volume_list = (float *)malloc(Max_cc*sizeof(float));
    if (volume_list == NULL) {
      fprintf(stderr,"malloc failed [%dkB]\n", Max_cc*sizeof(int)/1024);
      fflush(stderr);
      exit(1);
    }
    for (i=0; i< Max_cc; i++)
      volume_list[i] = 0.0;
  }
}



void Usage(void)
{
  fprintf(stderr,"Usage: repros2tetra <tetra> <points> <output> ");
  fprintf(stderr," [-t <string>] [-max_vertex <nb>] [-max_tetra <nb>] [-statistic] [-p]\n");
  fprintf(stderr,"-t <string>   insert <string> as first line in file <output>\n");
  fprintf(stderr,"-statistic    calculate volume of connected components\n");
  fprintf(stderr,"-max_vertex <nb>   max nb of vertices per section (default=20000)\n");
  fprintf(stderr,"-max_tetra  <nb>   max nb of tetrahedra per slice (default=4*max_vertex)\n");
  fprintf(stderr,"-p                 suppress output of vertices\n");
  exit(1);
}



void numerate(TETRA_SLICE *tetra0, TETRA_SLICE *tetra1)
/********************************************************************/
/*                                                                  */
/********************************************************************/
                             
{
  int i,j;
 
  /* spread out the known ones */
  for(i = 0 ; i<tetra0->nb ; i++)
    if( Not_Elim(tetra0,i) && (*(tetra0->obj))[i] != 0 )
      mark(i,tetra0,tetra1,(*(tetra0->obj))[i]);
  /* unknown->make new cc */
  for(i = 0 ; i<tetra0->nb ; i++)
    if( Not_Elim(tetra0,i) && (*(tetra0->obj))[i] == 0 ) {
      obj_nb++;
      if( obj_nb >= Max_cc) {
        char *cc_ptr;
        Max_cc = Max_cc + 100;
        cc_ptr = realloc((char *)cc_list, Max_cc *sizeof(int));
        if (cc_ptr == NULL) {
          perror("realloc");
          exit(1);
        }
        cc_list = (int *)cc_ptr;
        for (j = Max_cc - 100; j< Max_cc ; j++)
          cc_list[j] = j;
        if (do_statistics) {
          cc_ptr = realloc((char *)volume_list, Max_cc *sizeof(float));
          if (cc_ptr == NULL) {
            perror("realloc");
            exit(1);
          }
          volume_list = (float *)cc_ptr;
          for (j= Max_cc - 100; j< Max_cc; j++)
            volume_list[j] = 0.0;
        }
      }
      mark(i, tetra0, tetra1, obj_nb);
    }
}

void mark(int i, TETRA_SLICE *tetra0, TETRA_SLICE *tetra1, int nb)
{
  int j;

  /*printf("tetra %d, obj was %d -> %d\n", i , (*(tetra0->obj))[i], nb);*/
  if (do_statistics && (*(tetra0->obj))[i] == 0) {
    volume_list[nb] = volume_list[nb] + tetra_volume(i,tetra0);
    nb_test++;
  }
  (*(tetra0->obj))[i] = (short)nb;

  for (j=0 ; j<3 ; j++) {
    if( (*(tetra0->neighbor))[i][j] >= 0  &&
       Not_Elim(tetra0,(*(tetra0->neighbor))[i][j])) {
         if ( (*(tetra0->obj))[(*(tetra0->neighbor))[i][j]] == 0 )
           mark((*(tetra0->neighbor))[i][j],tetra0,tetra1,nb);
         else {
           if ( (*(tetra0->obj))[(*(tetra0->neighbor))[i][j]] != nb ) {
             add_cc(nb,(*(tetra0->obj))[(*(tetra0->neighbor))[i][j]]);
           }
         }
    }
  }

  /* if t2, propagate into adjacent slice */
  if( Is_t2(tetra0,i) ) {/*t2*/
    if( (*(tetra0->neighbor))[i][3] >= 0
        && Not_Elim(tetra1,(*(tetra0->neighbor))[i][3])
        && (*(tetra1->obj))[(*(tetra0->neighbor))[i][3]] == 0) {
      (*(tetra1->obj))[(*(tetra0->neighbor))[i][3]] =  (*(tetra0->obj))[i];
      if (do_statistics) {
        volume_list[(*(tetra0->obj))[i]] = volume_list[(*(tetra0->obj))[i]]
                          + tetra_volume( (*(tetra0->neighbor))[i][3] ,tetra1);
        /*printf("spread%d, %d           -> %d\n",(*(tetra0->neighbor))[i][3], i , (*(tetra0->obj))[i]);*/
        nb_test++;
      }
    }
  }

  /* if t12, stay in that slice */
  if( Is_t12(tetra0,i) ) {/*t12*/
    if( (*(tetra0->neighbor))[i][3] >= 0  &&
       Not_Elim(tetra0,(*(tetra0->neighbor))[i][3]) ) {
       if ( (*(tetra0->obj))[(*(tetra0->neighbor))[i][3]] == 0 )
         mark((*(tetra0->neighbor))[i][3],tetra0,tetra1,nb);
       else {
           if ( (*(tetra0->obj))[(*(tetra0->neighbor))[i][j]] != nb ) {
             add_cc(nb,(*(tetra0->obj))[(*(tetra0->neighbor))[i][j]]);
           }
       }
    }
  }
}


void write_new_tetra(TETRA_SLICE *tetra, PLANE *pl0, PLANE *pl1)
/********************************************************************/
/*                                                                  */
/********************************************************************/
                   
                 
{
  int i,j;
  int p0,p1,p2,p3;
  int n[4];

  PLANE *pl[2];

  pl[0] = pl0;
  pl[1] = pl1;

  fprintf(out_file, "T %d\n", tetra->nb);
  for (i=0 ; i< tetra->nb ; i++) {
    switch ((*(tetra->typ))[i]) {
      case  4:
      case 12:
               p0 = 1; p1 = 1; p2 = 0; p3 = 0; break;
      case  1:
      case  9:
               p0 = 0; p1 = 0; p2 = 0; p3 = 1; break;
      case  2:
      case 10:
               p0 = 1; p1 = 1; p2 = 1; p3 = 0; break;
    }

    fprintf(out_file, "%d %d %d %d",
       ((*(tetra->tetra))[i][0]>>1) + pl[p0]->start,
       ((*(tetra->tetra))[i][1]>>1) + pl[p1]->start,
       ((*(tetra->tetra))[i][2]>>1) + pl[p2]->start,
       ((*(tetra->tetra))[i][3]>>1) + pl[p3]->start);

    for(j=0; j<3 ; j++) {
      n[j] = (*(tetra->neighbor))[i][j];
      if ( n[j]  >= 0 ) n[j] = n[j] + off2;
    }
    switch ((*(tetra->typ))[i]) {
      case  4:                                    /*t12*/
      case 12:
              n[3] = (*(tetra->neighbor))[i][3];
              if ( n[3]  >= 0 ) n[j] = n[3] + off2;
              break;
      case  1:                                    /*t1*/
      case  9:
              n[3] = (*(tetra->neighbor))[i][3];
              if ( n[3]  >= 0 ) n[j] = n[3] + off1;
              break;
      case  2:                                    /*t2*/
      case 10:
              n[3] = (*(tetra->neighbor))[i][3];
              if ( n[3]  >= 0 ) n[j] = n[3] + off3;
              break;
    }
    
    fprintf(out_file, " %d %d %d %d %d %d\n",
       n[0], n[1], n[2], n[3],
       (*(tetra->typ))[i], (*(tetra->obj))[i]);
  }
}

void write_points(PLANE *pl)
/********************************************************************/
/*                                                                  */
/********************************************************************/
          
{
  int i;

  fprintf(out_file, "V %d z %f\n", pl->stop-pl->start, pl->z);
  for (i=0 ; i< pl->stop-pl->start ; i++) {
    fprintf(out_file, "%.2f %.2f\n",
      (*(pl->point))[i][0], (*(pl->point))[i][1] );
  }
}

void grab_arguments(int argc, char **argv)
{
  int i;

  if (argc < 4)  Usage();
  fnam[0] = argv[1];
  fnam[1] = argv[2];
  fnam[2] = argv[3];

  for (i = 4; i < argc; i++) {
    if (strcmp(argv[i], "-max_vertex") == 0) {
      if (++i >= argc) Usage();
      Maxvertex = atoi(argv[i]);
      mv_changed = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-max_tetra") == 0) {
      if (++i >= argc) Usage();
      Maxtetra = atoi(argv[i]);
      mf_changed = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-t") == 0) {
      if (++i >= argc) Usage();
      header = argv[i];
      continue;
    }
    if (strcmp(argv[i], "-statistic") == 0) {
      do_statistics = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-p") == 0) {
      vertex_out = FALSE;
      continue;
    }
    if (strcmp(argv[i], "-help") == 0) {
      Usage();
    }
    Usage();
  }
}

void add_cc(int a, int b)
{
  int i,v,x;

  /*printf("%d == %d\n", a,b);*/
  if (a < b) {
    i = a;
    a = b;
    b = i;
  }

  v = b;
  while (cc_list[v] != v) { /* get smallest instance */
    v = cc_list[v];
  }
  /* we had that case already */
  if (cc_list[a] == v){ cc_reread = TRUE; return;}

  if (cc_list[a] == a) {;}
  else {
    x = cc_list[a];
    if (v > x) {
      a = v;
      v = x;
    }
    else {
      a = x;
    }
  }
  for (i=a ; i< Max_cc ; i++) {
    if (cc_list[i] == a) {
      cc_list[i] = v;
    }
  }
  cc_reread = TRUE;
}

int count_cc(void)
{
  int i,j;
  int x,cc = 1;
  float total_volume = 0.0;

  if(do_statistics) {
    for (i=1 ; i<=obj_nb; i++) {
      if (cc_list[i] == i) continue;
      volume_list[cc_list[i]] = volume_list[cc_list[i]] + volume_list[i];
    }
    for(i=1,j=1; i<obj_nb+1 ; i++) {
      if (cc_list[i] != i) continue;
      printf("cc # %5d    %14.2f\n", j, volume_list[i]);
      total_volume = total_volume + volume_list[i];
      j++;
    }
    printf("total         %14.2f\n", total_volume);
  }

  for (i=1 ; i<=obj_nb; i++) {
    if (cc_list[i] > cc) {
      x = cc_list[i];
      cc++;
      if (cc_list[i] == cc) continue;
      for (j=i ; j<=obj_nb; j++) {
        if (cc_list[j] == x)
          cc_list[j] = cc;
      }
    }
  }
  printf("%d connected component(s)\n", cc);
  return(cc);
}


void change_cc(void)
{
  int i,j,n;
  FILE *tmp_file;
  char str[12];
  char str1[132];
  char tmpfile[1024], basename[1024], *fname;

  int nb_slabs, nb_vt, nb_tet;
  float x,y,z;
  int p1, p2, p3, p4, p5, p6, p7, p8, p9, cc;

  if ( (fname = rindex(fnam[2], '/')) == NULL ) {
    sprintf(tmpfile, "tmp_r2t_file");
  }
  else {
    n = strlen(fnam[2]) - strlen(fname) + 1;
    strncpy( basename, fnam[2], n);
    basename[n] = '\0';
    sprintf(tmpfile,"%stmp_r2t_file", basename);
  }
  if( rename(fnam[2], tmpfile) == -1) {
    perror(tmpfile);
    exit(1);
  }

  out_file = fopen(fnam[2], "w");
  if (out_file == NULL) {
    perror(fnam[2]);
    exit(1);
  }

  tmp_file = fopen(tmpfile, "r");
  if (tmp_file == NULL) {
    perror(tmpfile);
    exit(1);
  }
  
  if( strlen(header) != 0 ) { /*read/write header*/
     fprintf(out_file, "%s\n",  header);
     for(i=0; i < strlen(header)+1 ; i++)
       j = getc(tmp_file);
  }

  fscanf( tmp_file,  "%s%d",  str, &nb_slabs);
  fprintf(out_file, "S %d\n",  nb_slabs);
  for (i=0 ; i<nb_slabs; i++) {
    if (vertex_out) {
      fscanf(tmp_file, "%s%d%s%f", str, &nb_vt, str1, &z);
      fprintf(out_file, "V %d z %f\n",  nb_vt, z);
      for (j=0 ; j<nb_vt; j++) {
        fscanf(tmp_file, "%f%f", &x, &y);
        fprintf(out_file, "%.2f %.2f\n", x, y);
      }
    }
    fscanf(tmp_file, "%s%d", str, &nb_tet);
    fprintf(out_file, "T %d\n",  nb_tet);
    for (j=0 ; j<nb_tet; j++) {
      fscanf(tmp_file, "%d%d%d%d%d%d%d%d%d%d",
         &p1, &p2, &p3, &p4, &p5, &p6, &p7, &p8, &p9, &cc);

      fprintf(out_file, "%d %d %d %d %d %d %d %d %d %d\n",
          p1,p2,p3,p4,p5,p6,p7,p8,p9,cc_list[cc]);
    }
  }
  if (vertex_out) {
    fscanf(tmp_file, "%s%d%s%f", str, &nb_vt, str1, &z);
    fprintf(out_file, "V %d z %f\n",  nb_vt, z);
    for (j=0 ; j<nb_vt; j++) {
      fscanf(tmp_file, "%f%f", &x, &y);
      fprintf(out_file, "%.2f %.2f\n", x, y);
    }
  }
  fclose(tmp_file);

  if ( unlink(tmpfile) == -1) {
    perror("unlink") ;
    exit(1);
  }
  
  fclose(out_file);
}


double tetra_volume(int i, TETRA_SLICE *tetra)
/****************************************************************
 * Calc volume of tetra						*
 ****************************************************************/
      
                   
{
  int p0,p1,p2,p3;
  PLANE *pl[2];
  double a[3], b[3], c[3], d[3];

  pl[0] = tetra->pl0;
  pl[1] = tetra->pl1;

  switch ((*(tetra->typ))[i]) {
      case  4:
      case 12:
               p0 = 1; p1 = 1; p2 = 0; p3 = 0; break;
      case  1:
      case  9:
               p0 = 0; p1 = 0; p2 = 0; p3 = 1; break;
      case  2:
      case 10:
               p0 = 1; p1 = 1; p2 = 1; p3 = 0; break;
  }

  a[0] = (*(pl[p1]->point))[((*(tetra->tetra))[i][1]>>1)][0] -
         (*(pl[p0]->point))[((*(tetra->tetra))[i][0]>>1)][0];
  a[1] = (*(pl[p1]->point))[((*(tetra->tetra))[i][1]>>1)][1] -
         (*(pl[p0]->point))[((*(tetra->tetra))[i][0]>>1)][1];
  a[2] = pl[p1]->z - pl[p0]->z;
  b[0] = (*(pl[p2]->point))[((*(tetra->tetra))[i][2]>>1)][0] -
         (*(pl[p0]->point))[((*(tetra->tetra))[i][0]>>1)][0];
  b[1] = (*(pl[p2]->point))[((*(tetra->tetra))[i][2]>>1)][1] -
         (*(pl[p0]->point))[((*(tetra->tetra))[i][0]>>1)][1];
  b[2] = pl[p2]->z - pl[p0]->z;
  c[0] = (*(pl[p3]->point))[((*(tetra->tetra))[i][3]>>1)][0] -
         (*(pl[p0]->point))[((*(tetra->tetra))[i][0]>>1)][0];
  c[1] = (*(pl[p3]->point))[((*(tetra->tetra))[i][3]>>1)][1] -
         (*(pl[p0]->point))[((*(tetra->tetra))[i][0]>>1)][1];
  c[2] = pl[p3]->z - pl[p0]->z;

  d[0] = a[1]*b[2]-a[2]*b[1];
  d[1] = a[2]*b[0]-a[0]*b[2];
  d[2] = a[0]*b[1]-a[1]*b[0];

  return ( fabs((d[0]*c[0]+d[1]*c[1]+d[2]*c[2])/6.0));
}
