#ifndef lint
static  char *sccsid = "%W% %D%";
#endif
 
/************************************************************************
 * extrect_contours.c   Version 1.0  Oct 14 1993                        *
 *                                                                      *
 * Copyright 1993-96 INRIA                                              *
 *                                                                      *
 ***********************************************************************/
/************************************************************************
 *                      Modification History                            *
 *                                                                      *
 * Apr 10 1997 inclusion of string.h                                    *
 ************************************************************************/

/*  PURPOSE: Extract contours from segmented images. 
 *
 *
 *  ARGUMENTS:  <in_file> <out_file>
 *              -obj <nb>    extract contours with value <nb>         
 *              -range <nb1> <nb2> extract contours of values  between <nb1> and <nb2>\n"
 *              -z <value>   z_coord                           [0]
 *              -swap        byte swap                         [no]
 *              -hdr <nb>    skip <nb> bytes                   [0]
 *              -x  <xsize>  width of image                    [256]
 *              -y  <xsize>  heigth of image                   [256]
 *              -1           one byte per pixel
 *              -2           two bytes per pixel               [def]
 *              -xs          scale factor in x-direction       [1.0]
 *              -ys          scale factor in y-direction       [1.0]
 *		-double      experimental
 *		-simple      experimental
 *		-gauss       filter binary image with gaussian
 *		-sigma <val> gauss                             [1.0]
 *		-cut <x> <y> <lx> <ly>
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
/*
#include <stdHeaders.h>
#include <varargs.h>
#include <alloc.h>
*/
#include <BINSEG.h>

#ifdef HAVE_GAUSS
#include "low_level.h"
#endif

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#define CTX 256
#define CTY 256

#define TRESH 0.5


static int read_image(char *fname);
static void Usage(void);

int height,width;
int ctx = CTX;
int cty = CTY;
int obj_value;
int obj_value1;
int obj_value2;
int get_range = FALSE;
int image_hdr_size = 0;
int byte_swap = FALSE;
int pixelsize = 2;
int double_size = FALSE;
int half_size = FALSE;
int do_gauss = FALSE;
int cut_image = FALSE;
int cut_x=0, cut_y=0, cut_lx, cut_ly;
double sigma = 1.0;
unsigned char background = 0;
unsigned char foreground = 1;
float z_coord = 0.0;
double x_scale = 1.0;
double y_scale = 1.0;
double *double_image;
double *smooth_image;
double gauss_tresh = TRESH;
int    cat_objects = FALSE;
int    nb_of_cat_objects = 0;
int    cat_objects_list[100];

void swapshort();
void reduce_get_object();
void image_reduce();
void get_object();
void get_contours();
void Usage();
static void process_region();
static void count_vertices_in_region();
int connect_5();
void image_dilat();
void image_expand();
double *convert_to_double();
void convert_to_uchar();
void cat_values();

unsigned char	*nmr;


char *fnam[3];
FILE *fp1,*fp2,*fp3,*fopen();
int  fp4;
char descr_file[132], coord_file[132];

/*****************************************************************/
int main(int argc, char **argv)
/*****************************************************************/

{
  int i,j, nb;

  if (argc < 3) Usage();
  fnam[0] = argv[1];
  fnam[1] = argv[2];
  for (i = 3; i < argc; i++) {
    if (strcmp(argv[i], "-swap") == 0) {
      byte_swap = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-obj") == 0) {
      if (++i >= argc) Usage();
      obj_value = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-range") == 0) {
      if (++i >= argc) Usage();
      obj_value1 = atoi(argv[i]);
      if (++i >= argc) Usage();
      obj_value2 = atoi(argv[i]);
      get_range = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-z") == 0) {
      if (++i >= argc) Usage();
      z_coord = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-cut") == 0) {
      cut_image = TRUE;
      if (++i >= argc) Usage();
      cut_x = atof(argv[i]);
      if (++i >= argc) Usage();
      cut_y = atof(argv[i]);
      if (++i >= argc) Usage();
      cut_lx = atof(argv[i]);
      if (++i >= argc) Usage();
      cut_ly = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-hdr") == 0) {
      if (++i >= argc) Usage();
      image_hdr_size = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-cat") == 0) {
      cat_objects = TRUE;
      if (++i >= argc) Usage();
      nb_of_cat_objects = atoi(argv[i]);
      if (nb_of_cat_objects >= 100 || nb_of_cat_objects <= 1) {
        fprintf(stderr, "cannot cat %d objects\n",nb_of_cat_objects);
        Usage();
      }
      for (j=0 ; j<nb_of_cat_objects ; j++) {
        if (++i >= argc) Usage();
        cat_objects_list[j] = atoi(argv[i]);
      }
      continue;
    }
    if (strcmp(argv[i], "-x") == 0) {
      if (++i >= argc) Usage();
      ctx = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-sigma") == 0) {
      if (++i >= argc) Usage();
      sigma = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-y") == 0) {
      if (++i >= argc) Usage();
      cty = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-xs") == 0) {
      if (++i >= argc) Usage();
      x_scale = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-ys") == 0) {
      if (++i >= argc) Usage();
      y_scale = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-t") == 0) {
      if (++i >= argc) Usage();
      gauss_tresh = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-gauss") == 0) {
      do_gauss = TRUE;
      double_size = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-1") == 0) {
      pixelsize = 1;
      continue;
    }
    if (strcmp(argv[i], "-2") == 0) {
      pixelsize = 2;
      continue;
    }
    if (strcmp(argv[i], "-double") == 0) {
      double_size = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-simple") == 0) {
      half_size = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-help") == 0) {
      Usage();
    }
    Usage();
  }

  if (pixelsize == 1) byte_swap = FALSE;


  nb = read_image(fnam[0]);

  if (byte_swap) swapshort((char *)nmr,nb);

  if (pixelsize == 2 && cat_objects)
    cat_values(nmr);

  switch(pixelsize) {
    case 1: get_object(nmr);
            break;
    case 2: reduce_get_object(nmr);
            break;
  }

  if(double_size) {
    image_expand(nmr);
    ctx = 2*ctx;
    cty = 2*cty;
    cut_x = 2*cut_x;
    cut_y = 2*cut_y;
    /*image_dilat(nmr);*/
  }
  if(half_size) {
    image_reduce(nmr);
    ctx = ctx/2;
    cty = cty/2;
  }

  fp1 = fopen(fnam[1], "w");
  if (fp1 == NULL) {
    perror("fopen");
    exit(1);
  }

#ifdef HAVE_GAUSS
  if (do_gauss) {
    double_image = convert_to_double(nmr);
    smooth_image = Gaussian_filter_2D(double_image,ctx,cty,IMAGE_DOUBLE,sigma,sigma,0,0);
    free(double_image);
    convert_to_uchar(nmr,smooth_image);
    free(smooth_image);
  }
#endif
  get_contours(nmr);

  close(fp4);
  fclose(fp1);
  exit(0);
  return(0);
}
/*end main*********************************************************************/

void swapshort (register char *bp, register unsigned n)
{
    register char c;
    register char *ep = bp + n;

    while (bp < ep) {
        c = *bp;
        *bp = *(bp + 1);
        bp++;
        *bp++ = c;
    }
}


void get_object(unsigned char *image)
/* Set all pixel with a value != obj  to background;
 *                            == obj  to foreground;
 */
{
  register unsigned char *c;
  register int i;

  c = image;
  if (!get_range) {
    for (i=0; i<ctx*cty; i++) {
      if ( *c != obj_value)
        *c = background;
      else 
        *c = foreground;
      c++;
    }
  }
  else {
    for (i=0; i<ctx*cty; i++) {
      if ( *c < (unsigned char)obj_value1 || *c > (unsigned char)obj_value2 )
        *c = background;
      else
        *c = foreground;
      c++;
    }
  }
  obj_value = foreground;
}

void reduce_get_object(unsigned char *image)
/* Reduces 2 Byte image to 1 byte image and
 * set all pixel with a value != obj  to background;
 * We suppose that there is no img value > 255, and
 * high byte comes first (!!!)
 */
{
  register unsigned char *d;
  register unsigned char *s;
  register int i;
  register unsigned short *v;

  d = image;
  v = (unsigned short *)image;
  s = image+1;
  if (!get_range) {
    for (i=0; i<ctx*cty; i++) {
      if ( *v != obj_value) *d = background;
      else *d = foreground;
      d++;
      s = s + 2;
      v++;
    }
  }
  else {
    for (i=0; i<ctx*cty; i++) {
      if ( *v < (unsigned short)obj_value1 || *v > (unsigned short)obj_value2 ) 
        *d = background;
      else
        *d = foreground;
      d++;
      s = s + 2;
      v++;
    }
  }
  obj_value = foreground;
}


void get_contours(BINSEG_Pixel *image)
{
  int i, j, w, h, i_0, j_0;
  BINSEG_Pixel foreground_pixel;
  BINSEG_Connectedness connectedness;
  static BINSEG_SegmentedImage segmented_image;

  BINSEG_SegmentedImageRegionList list;
  BINSEG_SegmentedImageRegionListElement element, next;
  BINSEG_SegmentedImageRegion region;
  int nb_region_vertices;

  int err;

  connectedness = BINSEG_4_Connectedness;
  foreground_pixel = obj_value;
  if (BINSEG_SegmentBinaryImage (image, ctx, cty
                                 ,foreground_pixel, connectedness
                                 ,&segmented_image) != BINSEG_Succeed) {
    BINSEG_Perror ("BINSEG_SegmentBinaryImage");
    err = 1;
  }
  else {
    err = 0;
  }

  if (BINSEG_GetListOfRegionsFromSegmentedImage (segmented_image, &list)
      != BINSEG_Succeed) {
    BINSEG_Perror ("BINSEG_GetListOfRegionsFromSegmentedImage");
    err = 1;
    return;
  }

  nb_region_vertices = 0;
  if (BINSEG_SegmentedImageRegionListGetFirstElement (list, &element)
      != BINSEG_Succeed) {
    BINSEG_Perror ("BINSEG_SegmentedImageRegionListGetFirstElement");
    err = 1;
    return;
  }
  for (; element != BINSEG_NilRegionListElement ; element = next) {
    if (BINSEG_GetSegmentedImageRegionFromSegmentedImageRegionListElement
          (segmented_image, list, element, &region)
          != BINSEG_Succeed) {
      BINSEG_Perror ("BINSEG_GetSegmentedImageRegionFromSegmentedImageRegionListElement");
      break;
    }

    count_vertices_in_region (segmented_image, region, &nb_region_vertices);

    if (BINSEG_SegmentedImageRegionListGetNextElement
          (list, element, &next) != BINSEG_Succeed) {
      BINSEG_Perror ("BINSEG_SegmentedImageRegionListGetNextElement");
      break;
    }
  }

  fprintf(fp1, "v %d z %f\n", nb_region_vertices, z_coord);

  if (BINSEG_SegmentedImageRegionListGetFirstElement (list, &element)
      != BINSEG_Succeed) {
    BINSEG_Perror ("BINSEG_SegmentedImageRegionListGetFirstElement");
    err = 1;
    return;
  }
  for (; element != BINSEG_NilRegionListElement ; element = next) {
    if (BINSEG_GetSegmentedImageRegionFromSegmentedImageRegionListElement
          (segmented_image, list, element, &region)
          != BINSEG_Succeed) {
      BINSEG_Perror ("BINSEG_GetSegmentedImageRegionFromSegmentedImageRegionListElement");
      break;
    }
    process_region (segmented_image, region);

    if (BINSEG_SegmentedImageRegionListGetNextElement
          (list, element, &next) != BINSEG_Succeed) {
      BINSEG_Perror ("BINSEG_SegmentedImageRegionListGetNextElement");
      break;
    }
  }

  BINSEG_DisposeSegmentedImage (&segmented_image);

}



/*----------------- (INRIA) ---------------------------------------------*/
static void
process_region (BINSEG_SegmentedImage segmented_image, BINSEG_SegmentedImageRegion region)

/*
 * PURPOSE: retrieves the "shifted" border points of a region
 *          and dumps them using dump_region
 * ARGUMENTS:
 * RETURN:
 * GLOBALS: NONE
 *-----------------------------------------------------------------------*/
{
  BINSEG_Status err;
  BINSEG_BorderPoint static_array[1024];
  BINSEG_BorderPoint *dynamic_array = 0;
  BINSEG_BorderPoint *border_points;
  unsigned int number_of_border_points;
  int i;

  if ((err = BINSEG_GetSegmentedImageRegionShiftedBorderPoints
       (segmented_image, region
        ,static_array, sizeof (static_array) / sizeof (static_array[0])
        ,&number_of_border_points))
      == BINSEG_Succeed) {
    border_points = static_array;
  }
  else {
    if (err == BINSEG_ErrNotEnoughRoom) {
      if ((dynamic_array = (BINSEG_BorderPoint *)
           malloc (number_of_border_points * sizeof (dynamic_array[0])))
          != (BINSEG_BorderPoint *) 0) {
        border_points = dynamic_array;
        err = BINSEG_GetSegmentedImageRegionShiftedBorderPoints
               (segmented_image, region
               ,dynamic_array, number_of_border_points
             ,&number_of_border_points);
      }
    }
  }


  if (err != BINSEG_Succeed) {
    BINSEG_Perror ("BINSEG_GetSegmentedImageRegionShiftedBorderPoints");
    return;
  }


  fprintf(fp1, "{\n");
  if (double_size)
    for (i=0 ; i< number_of_border_points ; i++) {
      fprintf(fp1, "%.2f %.2f\n", (border_points[i].x + cut_x)*x_scale/2.0 ,
                                  (border_points[i].y + cut_y)*y_scale/2.0);
  }
  else
    for (i=0 ; i< number_of_border_points ; i++) {
      fprintf(fp1, "%.2f %.2f\n", (border_points[i].x + cut_x)*x_scale,
                                  (border_points[i].y + cut_y)*y_scale);
  }
  fprintf(fp1, "}\n");


  if (dynamic_array != 0)
    free (dynamic_array);
}

/*----------------- (INRIA) ---------------------------------------------*/
static void
count_vertices_in_region (BINSEG_SegmentedImage segmented_image,
                          BINSEG_SegmentedImageRegion  region,
                          int *nb_region_vertices)
{
  BINSEG_Status err;
  BINSEG_BorderPoint static_array[10];
  BINSEG_BorderPoint *dynamic_array = 0;
  BINSEG_BorderPoint *border_points;
  unsigned int number_of_border_points;
  int i;

  if ((err = BINSEG_GetSegmentedImageRegionShiftedBorderPoints
       (segmented_image, region
        ,static_array, sizeof (static_array) / sizeof (static_array[0])
        ,&number_of_border_points))
      == BINSEG_Succeed || err == BINSEG_ErrNotEnoughRoom) {
    *nb_region_vertices = *nb_region_vertices + number_of_border_points;
  }
}




static void Usage(void)
{
  fprintf(stderr,"usage: extract_contours <in_file> [<out_file>] -obj <nb> [-range <nb1> <nb2>] [-z <value>] [-swap] [-hdr <nb>] [-x  <xsize>] [-y  <xsize>] [-1] [-2]\n");
 fprintf(stderr,"       -obj <nb>    extract contours with value <nb>\n");
 fprintf(stderr,"       -range <nb1> <nb2> extract contours of values  between <nb1> and <nb2>\n");
 fprintf(stderr,"       -z <value>   z_coord                  [0]\n");
 fprintf(stderr,"       -swap        byte swap               [no]\n");
 fprintf(stderr,"       -hdr <nb>    skip <nb> bytes          [0]\n");
 fprintf(stderr,"       -x  <xsize>  width of image         [256]\n");
 fprintf(stderr,"       -y  <xsize>  heigth of image        [256]\n");
 fprintf(stderr,"       -1           one byte per pixel          \n");
 fprintf(stderr,"       -2           two bytes per pixel    [def]\n");
 fprintf(stderr,"       -xs <val>    scale factor x         [1.0]\n"); 
 fprintf(stderr,"       -ys <val>    scale factor y         [1.0]\n");
#ifdef HAVE_GAUSS
 fprintf(stderr,"       -gauss       filter binary image\n");
 fprintf(stderr,"       -sigma <val> gauss filter           [1.0]\n");
#endif
 exit(1);
}

void image_expand(img)
unsigned char img[];
{
  int i,j,src;
  for (i=cty-1 ; i>=0 ; i--) {
    for (j=ctx-1 ; j>=0 ; j--) {
      src = i*ctx + j;
      img[ i*ctx*4 + j*2 ] = img [src];
      img[ i*ctx*4 + j*2 + 1 ] = img [src];
      img[ i*ctx*4 + ctx*2 + j*2 ] = img [src];
      img[ i*ctx*4 + ctx*2 + j*2 + 1 ] = img [src];
    }
  }
}
void image_dilat(img)
unsigned char *img;
{
  int i,j;
  unsigned char *img_out;
  unsigned char *ptr, *ptr_out;

  img_out = (unsigned char *)malloc(ctx*cty);
  if (img_out == NULL) {
    perror("malloc");
    exit(1);
  }
  ptr = img;
  ptr_out=img_out;

  for (i=0; i<cty ; i++) {
    for (j=0 ; j<ctx ; j++) {
      if ( *ptr == foreground || connect_5(ptr,i,j) )
        *ptr_out = foreground; 
      else {
        *ptr_out = background;
      }
      ptr++; ptr_out++;
    }
  }
  memcpy(img,img_out,ctx*cty);
  free(img_out);
}
 
int connect_5(ptr,i,j)
unsigned char *ptr;
int i,j;
{
  int nb=0;
  if ( (i == 0) || (i == cty-1) || (j == 0) || (j==ctx-1))
    return(0);
  if ( *(ptr+1) == foreground ) nb++;
  if ( *(ptr-1) == foreground ) nb++;
  if ( *(ptr-ctx-1) == foreground ) nb++;
  if ( *(ptr-ctx) == foreground ) nb++;
  if ( *(ptr-ctx+1) == foreground ) nb++;
  if ( *(ptr+ctx-1) == foreground ) nb++;
  if ( *(ptr+ctx) == foreground ) nb++;
  if ( *(ptr+ctx+1) == foreground ) nb++;
  return (nb > 4);
}

void image_reduce(image)
  unsigned char *image;
/* Reduces image to half size */
{
  register unsigned char *d;
  register unsigned char *s;
  register int i,j;

  d = image;
  s = image;
  for (i=0; i<cty/2; i++) {
    for (j=0; j<ctx/2; j++) {
      *d = *s;
      d++;
      s = s + 2;
    }
    s = s + ctx; 
  }
}

double *convert_to_double(img)
unsigned char *img;
{
  double *dimg, *ptr;
  register int i;

  dimg = (double *)malloc(ctx*cty*sizeof(double));
  if (dimg == NULL) {
    perror("malloc");
    exit(1);
  }
  ptr = dimg;
  for (i=0; i<ctx*cty ; i++) {
    *(ptr++) = (double)(*(img++));
  }
  return(dimg);
}

void convert_to_uchar(img,smooth_image)
unsigned char *img;
double *smooth_image;
{
  double *dptr;
  unsigned char *uptr;

  register int i;

  dptr = smooth_image;
  uptr = img;
  for (i=0 ; i<ctx*cty ; i++) {
    if( *(dptr++) < gauss_tresh ) {
      *(uptr++) = background; 
    }
    else {
      *(uptr++) = foreground; 
    }
  }
}

void cat_values(img)
unsigned char *img;
{
  register unsigned short *uptr;
  register int i,j;

  uptr = (unsigned short *)img;
  for (i=0 ; i<ctx*cty ; i++,uptr++) {
    for(j=1; j<nb_of_cat_objects ; j++) {
      if ( *uptr == (unsigned char)cat_objects_list[j])
        *uptr = (unsigned char)cat_objects_list[0];
    }
  }
}


int read_image(char *fname)
{
  int nb, i,j,k;
  int factor;
  unsigned char	*tmp;

  fp4 = open(fname, 0);
  if(fp4 == -1) {
    perror("open");
    exit(1);
  }

  if(double_size) 
    nmr = (unsigned char *)malloc(ctx*2*cty*2*pixelsize);
  else
    nmr = (unsigned char *)malloc(ctx*cty*pixelsize);

  if (nmr == NULL) {
    perror("malloc");
    exit(1);
  }

  i = lseek( fp4, image_hdr_size, 0);
  if (i == -1) {
    perror("lseek");
    exit(1);
  }
  nb = read(fp4, (char *)nmr, ctx*cty*pixelsize);
  printf(" %d Bytes read at %d\n" ,nb, i);

  if(double_size) factor = 2;
  else factor = 1;

  if ( cut_image ) {
    tmp = (unsigned char *)malloc(cut_lx*factor*cut_ly*factor*pixelsize);
    if (tmp == NULL) {
      perror("malloc");
      exit(1);
    }
    k = 0;
    for (i = cut_y ; i < (cut_y + cut_ly) ; i++) {
      for (j = cut_x*pixelsize ; j < (cut_x + cut_lx)*pixelsize ; j++)  {
        *(tmp + k) = *(nmr + (ctx * i * pixelsize) + j);
        k++;
      }
    }
    free ( (char *)nmr);
    nmr = tmp;
    ctx = cut_lx;
    cty = cut_ly;
  }
  return (ctx*cty*pixelsize); 
}
