#ifndef lint
static  char *sccsid = "@(#)prepros.c	2.6 96/10/31";
#endif

/************************************************************************
 *									*
 *  prepros  Version 2.0  Oct 14 1993					*
 *									*
 *  repros-preprozessor							*
 *  copyright 1993 Bernhard Geiger					*
 *									*
 *  tests if contour segments are intersecting				*
 *  delets vertices that are                                            *
 *   -incident								*
 *   -co_linear  or almost co_linear					*
 *  checks for proper contour orientation				*
 *  compares adjacent sections and perturbes identical vertices		*
 *  fills contours with internal points					*
 *  adds vertices on contour segments					*
 *  reduces pixel-contours						*
 *									*
 ************************************************************************/
/************************************************************************
 *                      Modification History                            *
 *									*
 * May 31 1996 depth selection added 					*
 * Jan 25 1995 translated to ANSI C                                     *
 * Dec 29 1994 #ifndef VMS_NUAGES added					*
 * Jul 15 1994 -mask, -circle, -s_approx added				*
 * Jun 20 1994 Check if number of vertices is correct			*
 * Apr 12 1994 Option -elim added					*
 *             if number of contours > Max_contour bug fixed		*
 ************************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#ifndef VMS_NUAGES
#include <malloc.h>
#else
#define M_PI 3.141592653589793238462643383279503
#endif
#include <fcntl.h>

#define SEUIL 1E-15
#define THR_A 0.5000           /*constant for contour approximation*/

#define Min(a,b)  (((a) < (b)) ? (a):(b))
#define Max(a,b)  (((a) > (b)) ? (a):(b))

#ifndef FALSE
#define TRUE 1
#define FALSE 0
#endif

#define MAX_CONTOUR   200  /*max nb of contours / plane */
#define SAN_FRANCISCO 250.0 
          /* points are moved by Min ((min_distance)/SAN_FRANCISCO, RICHTER) */
#define RICHTER       0.004
#define DX 10
#define DY 10

          /* huge value that will not appear in coordinate data */
#define EXEPTION_VAL 1000000.0 

int Maxcontour = MAX_CONTOUR;

int elim_small = 3;

typedef
  struct vertex {
    float x,y;
    int nb;
    struct vertex *ident;
    struct vertex *succ;
    struct vertex *pred;
  } VERTEX;
    
typedef
  struct contour {
    int nb_vertex;
    int depth;
    int orientation;
    VERTEX  *v_list;
    struct contour *next;
    struct contour *prev;
  } CONTOUR;

  


typedef
  struct x_section {
    int nbpt;
    float z;
    float xmin, xmax;
    float ymin, ymax;
    float minlength, maxlength;
    int nb_contours;
    CONTOUR *c_ptr;
    char *mem_ptr;
    char *mem_base;
    unsigned  mem_size;
    int nb_2points;
    int nb;
  } X_SECTION;

typedef struct P {
  float x,y,z;
} POINT;

typedef struct P2D {
  float x,y;
} POINT2D;


#ifndef VMS_NUAGES
  extern double drand48(void);
#else
  double drand48(void)
  {
    return ( (double)rand()/(double)2147483647);
  }
#endif


FILE *fopen(const char *, const char *);
FILE *fp1,*fp2,*fp3,*fp4,*fp5,*fp6;
float	n;
float	shake_length;
int	global_nb =	1;
int	mask =		FALSE;
int	circle_mask =	FALSE;
int	shake_on =	FALSE;		/*don't perturbe*/
int	shake_value_on=	FALSE;		/*take default value*/
int	no_linear =	TRUE;		/*supress co-linear vertices*/
int	fill_interior =	FALSE;		/*dont fill internal points*/
int	fill_cont =	FALSE;		/*don't fill points on contours*/
int	pixel_contour  = FALSE;		/*no pixel contour*/
int     approx_selected = FALSE;
int     select_depth = FALSE;
int     selected_depth = 0;
float	delta =	10000.0;
float	delta_x	=	DX;
float	delta_y	=	DY;
double	min_c_distance=	SEUIL;
int	exit_status =	0;
char	*fnam[6];
float	angle   = 1.0;
double  Thr_a   = THR_A * THR_A; /* we compare square distances */
double  Thr_selection  = THR_A * THR_A; /* we compare square distances */
int	depth_selector = 0;
float mask_x_min, mask_x_max, mask_y_min, mask_y_max;
float c_mask_x, c_mask_y, c_mask_r;


void read_section(int nb, X_SECTION *section);
void min_section(X_SECTION *section);
void eliminieren(CONTOUR **c_ptr, VERTEX **a_ptr, VERTEX **s_ptr, VERTEX **p_ptr);
void compare(X_SECTION *section1, X_SECTION *section2);
void shake(VERTEX *v_ptr, float l);
void turn_section(X_SECTION *section);
void turn_around(VERTEX *v_ptr, int nb);
void fill_section(X_SECTION *section);
void fill_contour(X_SECTION *section, float d);
void Usage(void);
void grab_arguments(int argc, char **argv);
void write_section(X_SECTION *section);
void approx_section(X_SECTION *section);
void elim_2pt_section(X_SECTION *section);
void approx_selected_section(X_SECTION *section);
int outside_circle(VERTEX *v);
int outside_mask(VERTEX *v);
void mask_out(X_SECTION *section);
double edge_distance(VERTEX *p1, VERTEX *p2, VERTEX *i);
double max_distance(VERTEX *p1, VERTEX *p2);
int read_contour(int i, X_SECTION *section);
int intersection(VERTEX *s1, VERTEX *s2, VERTEX *s3, VERTEX *s4);
int inter_section(X_SECTION *section);
int self_intersection(VERTEX *s1, VERTEX *s2, VERTEX *s3, VERTEX *s4);
int halfline_intersection(VERTEX *p1, VERTEX *p2, VERTEX *z);
int self_inter_section(X_SECTION *section);





/*****************************************************************/
main(int argc, char **argv)
/*****************************************************************/
                      

{
  X_SECTION *section[2];
  int i, k, nb_sections;
  char string[4];

  fnam[1] = "/dev/null";

  section[0] = (X_SECTION *)malloc( sizeof(X_SECTION) );
  section[0]->nbpt = 0;
  section[0]->c_ptr = NULL;
  section[0]->nb_contours = 0;

  section[1] = (X_SECTION *)malloc( sizeof(X_SECTION) );
  section[1]->nbpt = 0;
  section[1]->c_ptr = NULL;
  section[1]->nb_contours = 0;


  grab_arguments(argc, argv);

  fp1 = fopen(fnam[0], "r");
  if(fp1 == NULL) {fprintf(stderr," %s  not found\n", fnam[0]); exit(1);}

  fp3 = fopen(fnam[1], "w");
  if(fp3 == NULL) {fprintf(stderr," cannot open %s\n", fnam[1]); exit(1);}

  if(fill_interior) {
    fp6 = fopen(fnam[4], "w");
    if(fp6 == NULL) {fprintf(stderr," cannot open %s\n", fnam[4]); exit(1);}
  }

  fscanf(fp1, "%s%d", string, &nb_sections);
  fprintf(fp3,"S %d\n",nb_sections); 
  if(fill_interior)
    fprintf(fp6,"S %d\n",nb_sections); 

  n = cos(angle*M_PI/180.0);
  i = 0;
  k = 1;
  read_section(i,section[0]);
  if (mask || circle_mask) mask_out(section[0]);
  if (pixel_contour) {
    approx_section(section[0]);
  }
  min_section(section[0]);
  if (!self_inter_section(section[0]) && !inter_section(section[0])) {
    turn_section(section[0]);
    if (approx_selected) {
      approx_selected_section(section[0]);
    }
    elim_2pt_section(section[0]);
    if (fill_interior)
      fill_section(section[0]);
    if(fill_cont)
      fill_contour(section[0],delta);
  }
  for (i=1; i<nb_sections; i++) {
    read_section(i,section[k]);
    if (mask || circle_mask) mask_out(section[k]);
    if (pixel_contour) {
      approx_section(section[k]);
    }
    min_section(section[k]);
    if( !self_inter_section(section[k]) && !inter_section(section[k])) {
      compare(section[!k], section[k]);
      turn_section(section[k]);
      if (approx_selected) {
        approx_selected_section(section[k]);
      }
      elim_2pt_section(section[k]);
      if (fill_interior)
        fill_section(section[k]);
      if(fill_cont)
        fill_contour(section[k],delta);
      write_section(section[!k]);
    }
    k = !k;
  }
  write_section(section[!k]);
  fclose(fp1);
  fclose(fp3);
  if(fill_interior) {
    fclose(fp6);
  }
  exit(exit_status);
}


void min_section(X_SECTION *section)
{
  int i,j,elim,nb_vert;
  double pa[2], norm, as, cos_alpha, diff;
  CONTOUR *c_ptr;
  VERTEX  *a_ptr, *s_ptr, *p_ptr;

  section->minlength = 10000000.0;
  section->maxlength = 0.0;
  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    a_ptr = c_ptr->v_list;
    s_ptr = a_ptr->succ;
    p_ptr = a_ptr->pred;
    
    nb_vert = c_ptr->nb_vertex;
    for ( j=0 ; j<nb_vert; j++) {
      elim = 0;
      norm = sqrt((a_ptr->x - p_ptr->x) * (a_ptr->x - p_ptr->x) +
                  (a_ptr->y - p_ptr->y) * (a_ptr->y - p_ptr->y));
      if (norm == 0.0)  {
        fprintf(stdout,"            %d = %d          ",a_ptr->nb,p_ptr->nb);
        elim = 1;
      }
      else if (no_linear)  {
        pa[0] = (a_ptr->x - p_ptr->x) / norm;
        pa[1] = (a_ptr->y - p_ptr->y) / norm;
  
        as = sqrt((s_ptr->x - a_ptr->x) * (s_ptr->x - a_ptr->x) +
                  (s_ptr->y - a_ptr->y) * (s_ptr->y - a_ptr->y));
  
        cos_alpha =  as*pa[0]* (s_ptr->x - a_ptr->x) +
                     as*pa[1]* (s_ptr->y - a_ptr->y);

        diff = sqrt(as*pa[0] * as*pa[0] + as*pa[1] * as*pa[1]) * as;
        if (diff == 0.0) {
          fprintf(stdout,"            %d = %d          ",a_ptr->nb,p_ptr->nb);
          elim = 1;
        }
        else {
          cos_alpha = cos_alpha/diff;
          if(cos_alpha > n) {
            elim = 1;
          }
          if(-cos_alpha  > n) ;/*printf("*\n");*/
        }
      }
      if( elim ) {
        eliminieren(&c_ptr, &a_ptr, &s_ptr, &p_ptr);
        section->nbpt--;
      }
      else {
        if (section->minlength > norm) section->minlength = norm;
        if (section->maxlength < norm) section->maxlength = norm;
        a_ptr  = s_ptr;
        s_ptr  = a_ptr->succ;
        p_ptr  = a_ptr->pred;
      }
    }
  c_ptr = c_ptr->next;
  }
  fprintf(stdout,"        max: %f, min: %f\n",
                                 section->maxlength,section->minlength);
}




void eliminieren(CONTOUR **c_ptr, VERTEX **a_ptr, VERTEX **s_ptr, VERTEX **p_ptr)
{
  fprintf(stdout,"            %d deleted\n",(*a_ptr)->nb);
  (*c_ptr)->nb_vertex--;
  if((*c_ptr)->v_list == *a_ptr) {
    (*c_ptr)->v_list = *p_ptr;
    (*c_ptr)->v_list->succ = (*a_ptr)->succ;
    (*c_ptr)->v_list->succ->pred = (*c_ptr)->v_list;
    *a_ptr = (*c_ptr)->v_list->succ;
  }
  else {
    (*a_ptr)->succ->pred = *p_ptr;
    (*p_ptr)->succ = *s_ptr;
    *a_ptr = *s_ptr;
  }
  *s_ptr = (*a_ptr)->succ;
  *p_ptr = (*a_ptr)->pred;
}

int self_inter_section(X_SECTION *section)
{
  int i,j,first;
  CONTOUR *c_ptr;
  VERTEX  *v_ptr, *s_ptr;
  int ret_value = 0;

  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    if (c_ptr->nb_vertex >= elim_small) {
      v_ptr = c_ptr->v_list;
      for ( j=0 ; j< c_ptr->nb_vertex-1; j++) {
        s_ptr = v_ptr->succ;
        first = TRUE;
        while(s_ptr != c_ptr->v_list) {
          if(first || (s_ptr->succ == c_ptr->v_list)) {
            if( self_intersection(v_ptr,v_ptr->succ, s_ptr, s_ptr->succ)) {
              fprintf(stderr, "ERROR: section %d contour %d is self-intersecting !\n",section->nb, i+1);
              fprintf(stderr, "segments %d %d  x  %d %d\n",
                         v_ptr->nb,v_ptr->succ->nb, s_ptr->nb,s_ptr->succ->nb);
              ret_value = 1;
            }
            first = FALSE;
          }
          else {
            if( intersection(v_ptr,v_ptr->succ, s_ptr, s_ptr->succ)) {
              fprintf(stderr, "ERROR: section %d contour %d is self-intersecting !\n",section->nb, i+1);
              fprintf(stderr, "segments %d %d  x  %d %d\n",
                       v_ptr->nb,v_ptr->succ->nb, s_ptr->nb,s_ptr->succ->nb);
              ret_value = 1;
            }
          }
          s_ptr = s_ptr->succ;
        }
        v_ptr = v_ptr->succ;
      }
    }
    c_ptr = c_ptr->next;
  }
  exit_status = exit_status + ret_value;
  return(ret_value);
}

 
void compare(X_SECTION *section1, X_SECTION *section2)
{
  int i,j,ii,jj,nb_ident = 0;
  CONTOUR *c_ptr1, *c_ptr2;
  VERTEX  *v_ptr1, *v_ptr2;

  VERTEX *longest_chain = NULL, *lc = NULL;
  int length = 0,l = 0;
  int mod = 1;
 
  if ( section1->nbpt == 0 || section2->nbpt == 0 ) return;

  c_ptr1 = section1->c_ptr;
  for ( i=0 ; i< section1->nb_contours; i++) {
    v_ptr1 = c_ptr1->v_list;
    for ( j=0 ; j< c_ptr1->nb_vertex; j++) {
      c_ptr2 = section2->c_ptr;
      for ( ii=0 ; ii< section2->nb_contours; ii++) {
        v_ptr2 = c_ptr2->v_list;
        for ( jj=0 ; jj< c_ptr2->nb_vertex; jj++) {
          if(v_ptr1->x == v_ptr2->x && v_ptr1->y == v_ptr2->y ) {
            nb_ident++;
            v_ptr1->ident = v_ptr2; 
          }
          v_ptr2= v_ptr2->succ;
        }
        c_ptr2 = c_ptr2->next;
      }
      v_ptr1= v_ptr1->succ;
    }
    c_ptr1 = c_ptr1->next;
  }

  if( 100.0/(float)section1->nbpt*(float)nb_ident > 50.0) mod = 1;
  else 
  if( 100.0/(float)section1->nbpt*(float)nb_ident > 30.0) mod = 2;
  else mod = 3;

  if(!shake_value_on)
    shake_length = Min((section1->minlength)/SAN_FRANCISCO, RICHTER);
  c_ptr1 = section1->c_ptr;
  for ( i=0 ; i< section1->nb_contours; i++) {
    v_ptr1 = c_ptr1->v_list;
    l = 0;
    j = 0;
    do {
      if( v_ptr1->ident != NULL ) {
        lc = v_ptr1;
        l = 1;
        do {
          v_ptr1 = v_ptr1->succ;
          j++;
          if( v_ptr1->ident != NULL ) {
            l++;
            if (l% mod == 0 && shake_on ) 
              shake(v_ptr1,shake_length);
          }
          else {
           if (l > length) {
             length =  l;
             longest_chain = lc;
             l = 0;
           }
          }
        } while( v_ptr1->ident != NULL && v_ptr1 != lc );
        if (l > length) {
          length =  l;
          longest_chain = lc;
          l = 0;
        }
      }
      else {
        v_ptr1 = v_ptr1->succ;
        j++;
      }
    } while (j < c_ptr1->nb_vertex );
    c_ptr1 = c_ptr1->next;
  }

       
      
  fprintf(stdout,"        %d  identical points (%f %%)\n",
                   nb_ident,100.0/(float)section1->nbpt*(float)nb_ident);
  fprintf(stdout,"        longest chain: %d\n", length);
}

void shake(VERTEX *v_ptr, float l)
{
  v_ptr->x = v_ptr->x + l* (drand48()-0.5);
  v_ptr->y = v_ptr->y + l* (drand48()-0.5);
}



int Isclockwise(VERTEX *pv, int nv)
{
	VERTEX *p1;
	float area=0;
        int i;
	for(i=0,p1 = pv ; i<nv ; i++,p1 = p1->succ ) 
		area+=(p1->succ->x - p1->x) * (p1->succ->y+p1->y);
	return area<0 ? 1 : area>0 ? 0 : -1;
}



int halfline_intersection(VERTEX *p1, VERTEX *p2, VERTEX *z)
{
  float x1,y1,x2,y2,xz,yz;


  x1 = p1->x;
  x2 = p2->x;
  y1 = p1->y;
  y2 = p2->y;
  xz = z->x;
  yz = z->y;

  if (
   ((y1 >  yz) && (y2 >  yz)) || /* segment    above */
   ((y1 <  yz) && (y2 <  yz)) || /* segment    below */
   ((x1 >= xz) && (x2 >= xz)) || /* segment on right */
   (y1 == y2)                 || /* segment horizontal */
   ((y1 == yz) && (y2 < y1))  || /* vertex wth larger ordinate */
   ((y2 == yz) && (y1 < y2))     /* vertex wth larger ordinate */
  ) return(0); /*no intersection*/
  else {
    if (
     ((y1 == yz) && (y2 > y1) && (x1 <= xz)) || /* vertex wth smaller ordinate */
     ((y2 == yz) && (y1 > y2) && (x2 <= xz))  /* vertex wth smaller ordinate */
    ) return(1);
    else {
      if (
        ((y1 == yz) && (y2 > y1) && (x1 > xz))|| /* vertex wth smaller ordinate */
        ((y2 == yz) && (y1 > y2) && (x2 > xz)) /* vertex wth smaller ordinate */
      ) return(0);
      else {
        if (
         ((y1 > yz) && (y2 < yz)) || /* segment crossing */
         ((y2 > yz) && (y1 < yz))    /* segment crossing */
        )
        if ( (x1 <= xz) && (x2 <= xz) ) return(1); /*intersection*/
        else {
          if ( x1 + ((yz-y1)*(x2-x1)/(y2-y1))  > xz)
            return(0); /* inters. right side */
          else
            return(1); /* inters. left side */
        }
      }
    }
  }
}

void turn_section(X_SECTION *section)
{
  int i,j,jj,L;
  CONTOUR *c_ptr_i, *c_ptr_j;
  VERTEX  *v_ptr_i, *v_ptr_j;

  c_ptr_i = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    c_ptr_j = c_ptr_i->next;
    v_ptr_i = c_ptr_i->v_list;
    for ( j=i+1 ; j< section->nb_contours; j++) {
      v_ptr_j = c_ptr_j->v_list;


      L = 0;
      for ( jj=0 ; jj< c_ptr_j->nb_vertex; jj++) {
        if (halfline_intersection(v_ptr_j,v_ptr_j->succ,v_ptr_i) == 1) {
          L = L+1;
        }
        v_ptr_j = v_ptr_j->succ;
      }
      if (L & 1) {
        fprintf(stdout,"    contour %4d  inside of contour %4d\n", i+1 , j+1);
        c_ptr_i->depth++;
      }
      else {
        /*printf("contour %d external to contour %d\n", i+1 , j+1)*/;
      }

      L = 0;
      for ( jj=0 ; jj< c_ptr_i->nb_vertex; jj++) {
        if (halfline_intersection(v_ptr_i,v_ptr_i->succ,v_ptr_j) == 1) {
          L = L+1;
        }
        v_ptr_i = v_ptr_i->succ;
      }
      if (L & 1) {
        fprintf(stdout,"    contour %4d inside of contour %4d\n", j+1 , i+1);
        c_ptr_j->depth++;
      }
      else {
        /*printf("contour %d external to contour %d\n", j+1 , i+1)*/;
      }

      c_ptr_j = c_ptr_j->next;
    }
    c_ptr_i = c_ptr_i->next;
  }

  c_ptr_i = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    if((c_ptr_i->depth & 1) ^ (c_ptr_i->orientation == 1)) {
      fprintf(stdout, "    contour %d at depth %d had wrong orientation\n",
              i+1, c_ptr_i->depth);
      turn_around(c_ptr_i->v_list, c_ptr_i->nb_vertex);
      c_ptr_i->orientation = ! c_ptr_i->orientation;
    }
    c_ptr_i = c_ptr_i->next;
  }
}

void turn_around(VERTEX *v_ptr, int nb)
{
  VERTEX *h;
  int i;

  for (i=0 ; i<nb ; i++) {
    h = v_ptr->succ;
    v_ptr->succ = v_ptr->pred;
    v_ptr->pred = h;
    v_ptr = v_ptr->succ;
  }
}





void fill_section(X_SECTION *section)
{
  float xi,yi;  /* !!!!!!!!!!!!!!!!! */
  int i,ii,L;
  CONTOUR *c_ptr;
  VERTEX  *v_ptr;
  VERTEX v;
  int inside, depth;
  int nb = 0;
  char *ptr;

  int Max_int_vertices = 10000;
  POINT2D *int_vertices;

  int_vertices = (POINT2D *)malloc(Max_int_vertices*sizeof(POINT2D));
  if (int_vertices == NULL) {
    fprintf(stderr,"cannot allocate %d internal vertices\n",Max_int_vertices);
    fprintf(fp6, "V 0 z %f\n", section->z);
    return;
  }

  if(!shake_value_on)
    shake_length = Min((section->minlength)/SAN_FRANCISCO, RICHTER);

  for (yi = section->ymin ; yi < section->ymax ; yi = yi + delta_y ) {
    v.y = yi;
    for (xi = section->xmin ; xi < section->xmax; xi = xi + delta_x ) {
      v.x = xi;
      shake(&v,shake_length);
      c_ptr = section->c_ptr;

      depth = -1;
      inside = FALSE;
      for ( i=0 ; i< section->nb_contours; i++) {
        v_ptr = c_ptr->v_list;
        L = 0;
        for ( ii=0 ; ii< c_ptr->nb_vertex; ii++) {
          if (halfline_intersection(v_ptr,v_ptr->succ,&v) == 1) {
            L = L+1;
          }
          v_ptr = v_ptr->succ;
        }
        if (L & 1) {
          if(c_ptr->orientation) {
            if(c_ptr->depth > depth) {
              inside = FALSE;
              depth = c_ptr->depth;
            }
          }
          else {
            if(c_ptr->depth > depth) {
              inside = TRUE;
              depth = c_ptr->depth;
            }
          }
        }
        c_ptr = c_ptr->next;
      }
      if (inside) {
        if (nb >= Max_int_vertices) {
          Max_int_vertices = Max_int_vertices + 500;
          ptr = 
            (char *)realloc((char *)int_vertices,Max_int_vertices*sizeof(POINT2D));
          if (ptr == NULL) {
            fprintf(stderr,"cannot allocat %d internal vertices\n",Max_int_vertices);
            fprintf(fp6, "V 0 z %f\n", section->z);
            return;
          }
          int_vertices = (POINT2D *)ptr;
        }
        int_vertices[nb].x = v.x;
        int_vertices[nb].y = v.y;
        nb++;
      }
    }
  }
  fprintf(fp6,"V %d z %f\n", nb, section->z);
  fprintf(fp6,"{\n");
  for (i=0 ; i<nb ; i++) {
    fprintf(fp6,"%.2f %.2f\n", int_vertices[i].x, int_vertices[i].y);
  }
  fprintf(fp6,"}\n");
  free((char *)int_vertices);
}

int self_intersection(VERTEX *s1, VERTEX *s2, VERTEX *s3, VERTEX *s4)
{
  double x1,y1,x2,y2,x3,y3,x4,y4;
  double a11,a12,a21,a22,b1,b2,det,l1,l2;

  x1 = s1->x;
  y1 = s1->y;
  x2 = s2->x;
  y2 = s2->y;
  x3 = s3->x;
  y3 = s3->y;
  x4 = s4->x;
  y4 = s4->y;

  if( (x1 <= x3 && x1 <= x4 && x2 <  x3 && x2 <  x4) ||
      (x1 <  x3 && x1 <  x4 && x2 <= x3 && x2 <= x4) ||
      (x1 >= x3 && x1 >= x4 && x2 >  x3 && x2 >  x4) ||
      (x1 >  x3 && x1 >  x4 && x2 >= x3 && x2 >= x4) ||
      (y1 <= y3 && y1 <= y4 && y2 < y3 && y2 < y4) ||
      (y1 < y3 && y1 < y4 && y2 <= y3 && y2 <= y4) ||
      (y1 >= y3 && y1 >= y4 && y2 > y3 && y2 > y4) ||
      (y1 > y3 && y1 > y4 && y2 >= y3 && y2 >= y4) )
    return(0);

  if(x2==x3 && y2==y3) {
    if( fabs((x4-x2)*(y1-y2)-(x1-x2)*(y4-y2)) < min_c_distance )
      return(1);
    else
      return(0);
  }
  if(x1==x3 && y1==y3) {
    if( fabs((x4-x1)*(y2-y1)-(x2-x1)*(y4-y1)) < min_c_distance )
      return(1);
    else
      return(0);
  }
  if(x1==x4 && y1==y4) {
    if( fabs((x3-x1)*(y2-y1)-(x2-x1)*(y3-y1)) < min_c_distance )
      return(1);
    else
      return(0);
  }
  if(x2==x4 && y2==y4) {
    if( fabs((x3-x2)*(y1-y2)-(x1-x2)*(y3-y2)) < min_c_distance )
      return(1);
    else
      return(0);
  }
    

  a11 = x3 - x4;
  a12 = x1 - x2;
   b1 = x1 - x4;
  a21 = y3 - y4;
  a22 = y1 - y2;
   b2 = y1 - y4;
  det = a11*a22 - a12*a21;
  
  if (det == 0)  {
    if ( fabs((x3-x2)*(y1-y2)-(x1-x2)*(y3-y2)) < min_c_distance )
      return(1); /*parallel =*/
    else return(0); /*parallel, not intersecting*/
  }
  l1 = (b1*a22 - a12*b2)/det;
  l2 = (a11*b2 - b1*a21)/det;
  if( (l1>0.0) && (l1<1.0) && (l2>0.0) && (l2<1.0 ) )
    return(1);
  else
    return(0);
}

int inter_section(X_SECTION *section)
{
  int i,j,ii,jj;
  CONTOUR *c_ptr_i, *c_ptr_j;
  VERTEX  *v_ptr_i, *v_ptr_j;
  int ret_value = 0;

  c_ptr_i = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    if (c_ptr_i->nb_vertex >= elim_small) {
      v_ptr_i = c_ptr_i->v_list;
      for ( ii=0 ; ii< c_ptr_i->nb_vertex; ii++) {
        c_ptr_j = c_ptr_i->next;
        for ( j=i+1 ; j< section->nb_contours; j++) {
          if (c_ptr_j->nb_vertex >= elim_small) {
            v_ptr_j = c_ptr_j->v_list;
            for ( jj=0 ; jj< c_ptr_j->nb_vertex; jj++) {
              if( intersection(v_ptr_i,v_ptr_i->succ,v_ptr_j,v_ptr_j->succ)) {
                fprintf(stderr, "ERROR: section %d contour %d is intersecting contour %d\n",
                                                          section->nb,i+1,j+1);
                fprintf(stderr, "segments %d %d  x %d %d\n",
                   v_ptr_i->nb,v_ptr_i->succ->nb, v_ptr_j->nb,v_ptr_j->succ->nb);
                ret_value = 1;
              }
              v_ptr_j = v_ptr_j->succ;
            }
          }
          c_ptr_j = c_ptr_j->next;
        }
        v_ptr_i = v_ptr_i->succ;
      }
    }
    c_ptr_i = c_ptr_i->next;
  }
  exit_status = exit_status + ret_value;
  return(ret_value);
}

int intersection(VERTEX *s1, VERTEX *s2, VERTEX *s3, VERTEX *s4)
{
  double x1,y1,x2,y2,x3,y3,x4,y4;
  double a11,a12,a21,a22,b1,b2,det,l1,l2;

  x1 = s1->x;
  y1 = s1->y;
  x2 = s2->x;
  y2 = s2->y;
  x3 = s3->x;
  y3 = s3->y;
  x4 = s4->x;
  y4 = s4->y;

  if( (x1 < x3 && x1 < x4 && x2 < x3 && x2 <  x4) ||
      (x1 > x3 && x1 > x4 && x2 > x3 && x2 >  x4) ||
      (y1 < y3 && y1 < y4 && y2 < y3 && y2 < y4) ||
      (y1 > y3 && y1 > y4 && y2 > y3 && y2 > y4) )
    return(0);

  a11 = x3 - x4;
  a12 = x1 - x2;
   b1 = x1 - x4;
  a21 = y3 - y4;
  a22 = y1 - y2;
   b2 = y1 - y4;
  det = a11*a22 - a12*a21;
  
  if (det == 0)  {
    if ( fabs((x3-x2)*(y1-y2)-(x1-x2)*(y3-y2)) < min_c_distance )
      return(1); /*parallel =*/
    else return(0); /*parallel, not intersecting*/
  }
  l1 = (b1*a22 - a12*b2)/det;
  l2 = (a11*b2 - b1*a21)/det;
  if( (l1>= 0.0) && (l1<=1.0) && (l2>=0) && (l2<=1.0) )
  /*if( (l1> -min_c_distance/100.0) && (l1<1.0+min_c_distance/100.0)
        && (l2> -min_c_distance/100.0) && (l2<1.0+min_c_distance/100.0) )
  */
    return(1);
  else
    return(0);
}



void fill_contour(X_SECTION *section, float d)
{
  int i,j,nb,k,nb_new;
  double norm, diff;
  CONTOUR *c_ptr;
  VERTEX  *v_ptr, *a_ptr, *s_ptr, *p_ptr;

  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    a_ptr = c_ptr->v_list;
    s_ptr = a_ptr->succ;
    nb_new = 0;
    for ( j=0 ; j< c_ptr->nb_vertex; j++) {
      norm = sqrt((a_ptr->x - s_ptr->x) * (a_ptr->x - s_ptr->x) +
                  (a_ptr->y - s_ptr->y) * (a_ptr->y - s_ptr->y));
      if (norm > 1.5*d) {
        nb = (int)norm/(int)d -1;
        if(nb == 0) nb++;
        diff =  norm/(float)(nb+1);
        p_ptr = a_ptr;
        for(k=1; k<=nb ; k++) {
          v_ptr = (VERTEX *)malloc(sizeof(VERTEX));
          if(v_ptr == NULL) {
            fprintf(stderr,"fill_contour: no memory\n");
            fflush(stderr);
            exit(1);
          }
          v_ptr->x = p_ptr->x + k*diff*(s_ptr->x - p_ptr->x)/norm;
          v_ptr->y = p_ptr->y + k*diff*(s_ptr->y - p_ptr->y)/norm;
          v_ptr->nb = -1;/*global_nb++;*/
          v_ptr->ident = NULL;
          v_ptr->succ = s_ptr;
          s_ptr->pred = v_ptr;
          v_ptr->pred = a_ptr;
          a_ptr->succ = v_ptr;
          a_ptr = v_ptr;
          nb_new++;
        }
      }
      a_ptr = a_ptr->succ;
      s_ptr = a_ptr->succ;
    }
    c_ptr->nb_vertex = c_ptr->nb_vertex + nb_new;
    section->nbpt = section->nbpt+nb_new;
    c_ptr = c_ptr->next;
  }
}


void Usage(void)
{
 fprintf(stderr,"Usage: prepros <cnt_in> [<cnt_out>] [-d <d>] [-n][-s][-S <d>][-i <file>][-c <d>][-x <d>][-y <d>] [-m <nb>] [-pixel] [-approx <value>] [-elim <nb>]\n");
 fprintf(stderr,"       -d <d>: delete segments with orientation difference\n");
 fprintf(stderr,"       smaller than <d> degree   default = 1 \n");
 fprintf(stderr,"       -n no supression of co_linear vertices\n");
 fprintf(stderr,"       -s perturbe identical vertices\n");
 fprintf(stderr,"       -S <d> perturbe identical vertices by <d>\n");
 fprintf(stderr,"       -i <file> fill contours with internal points\n");
 fprintf(stderr,"       -x <d> x distance of internal points\n");
 fprintf(stderr,"       -y <d> y distance of internal points\n");
 fprintf(stderr,"       -c <d> put additional vertices on contour segments at distance <d>\n");
 fprintf(stderr,"       -m <nb> set max number of contours per plane (default=200)\n");
 fprintf(stderr,"       -pixel approximate pixel contours\n");
 fprintf(stderr,"       -approx <value> set max error of pixel contour approximation to <value> (default=0.5)\n");
 fprintf(stderr,"       -elim <nb> delete contours with less than <nb> vertices (default=3)\n");
 exit(1);
}



void grab_arguments(int argc, char **argv)
{
  int i;

  if (argc < 2)  Usage();
  fnam[0] = argv[1];

  for (i = 2; i < argc; i++) {
    if (strcmp(argv[i], "-d") == 0) {
      if (++i >= argc) Usage();
      angle = atof(argv[i]); 
      continue;
    }
    if (strcmp(argv[i], "-s") == 0) {
      shake_on = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-depth") == 0) {
      select_depth = TRUE;
      if (++i >= argc) Usage();
      selected_depth = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-S") == 0) {
      shake_on = TRUE;
      shake_value_on = TRUE;
      if (++i >= argc) Usage();
      shake_length = atof(argv[i]); 
      continue;
    }
    if (strcmp(argv[i], "-n") == 0) {
      no_linear = FALSE;
      continue;
    }
    if (strcmp(argv[i], "-i") == 0) {
      fill_interior = TRUE;
      if (++i >= argc) Usage();
        fnam[4] = argv[i];
      continue;
    }
    if (strcmp(argv[i], "-pixel") == 0) {
      pixel_contour    = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-c") == 0) {
      fill_cont    = TRUE;
      if (++i >= argc) Usage();
      delta = atof(argv[i]); 
      continue;
    }
    if (strcmp(argv[i], "-x") == 0) {
      if (++i >= argc) Usage();
       delta_x = atof(argv[i]); 
      continue;
    }
    if (strcmp(argv[i], "-y") == 0) {
      if (++i >= argc) Usage();
       delta_y = atof(argv[i]); 
      continue;
    }
    if (strcmp(argv[i], "-t") == 0) {
      if (++i >= argc) Usage();
       min_c_distance = atof(argv[i]); 
      continue;
    }
    if (strcmp(argv[i], "-elim") == 0) {
      if (++i >= argc) Usage();
      elim_small = atoi(argv[i]);
      if (elim_small < 3) elim_small = 3;
      continue;
    }
    if (strcmp(argv[i], "-mask") == 0) {
      mask = TRUE;
      if (++i >= argc) Usage();
      mask_x_min = atof(argv[i]);
      if (++i >= argc) Usage();
      mask_x_max = atof(argv[i]);
      if (++i >= argc) Usage();
      mask_y_min = atof(argv[i]);
      if (++i >= argc) Usage();
      mask_y_max = atof(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-circle") == 0) {
      circle_mask = TRUE;
      if (++i >= argc) Usage();
      c_mask_x = atof(argv[i]);
      if (++i >= argc) Usage();
      c_mask_y = atof(argv[i]);
      if (++i >= argc) Usage();
      c_mask_r= atof(argv[i]);
      c_mask_r = c_mask_r*c_mask_r;
      continue;
    }
    if (strcmp(argv[i], "-m") == 0) {
      if (++i >= argc) Usage();
      Maxcontour = atoi(argv[i]);
      continue;
    }
    if (strcmp(argv[i], "-h") == 0) {
      Usage();
    }
    if (strcmp(argv[i], "-approx") == 0) {
      if (++i >= argc) Usage();
      Thr_a = atof(argv[i]);
      Thr_a = Thr_a * Thr_a; /* we compare square distances */
      continue;
    }
    if (strcmp(argv[i], "-s_approx") == 0) {
      approx_selected = TRUE;
      if (++i >= argc) Usage();
      depth_selector = atoi(argv[i]);
      if (++i >= argc) Usage();
      Thr_selection = atof(argv[i]);
      Thr_selection = Thr_selection * Thr_selection;
                                    /* we compare square distances */
      continue;
    }
    if (strcmp(argv[i], "-h") == 0) {
      Usage();
    }
    if (i < 3)
      fnam[i-1] = argv[i];
    else
      Usage();
  }
}


void read_section(int nb, X_SECTION *section)
{
  int i, nb_pts;
  CONTOUR *c_ptr;
  char s1[132], s2[132];

  section->nb = nb+1;
  section->nb_contours = 0;
  section->nb_2points = 0;
  section->nb_contours = 0;
  section->xmin =  EXEPTION_VAL;
  section->xmax = -EXEPTION_VAL;
  section->ymin =  EXEPTION_VAL;
  section->ymax = -EXEPTION_VAL;
  if( fscanf(fp1,"%s%d%s%f",s1,&(section->nbpt), s2, &(section->z)) == EOF) {
    fprintf(stderr, "   error reading x-section %d\n", nb+1);
    exit(1);
  }
  if(section->nbpt<1) {
    printf("x-section %d is empty\n",nb+1);
    return;
  }
  if(section->nbpt<3) {
    fprintf(stdout, "%d points in x-section %d - eliminated \n",section->nbpt,nb+1);
    section->nbpt = 0;
    return;
  }

  section->mem_size = sizeof(VERTEX) * section->nbpt  +
                      sizeof(CONTOUR) * Maxcontour;
  section->mem_base = (char *)malloc(section->mem_size);
  if(section->mem_base == NULL) {
    fprintf(stderr,"mem alloc failed\n");
    exit(1);
  }
  section->mem_ptr = section->mem_base;

  nb_pts = section->nbpt;
  section->nbpt = 0;
  i = 0;
  do {i = read_contour(i,section);} while (i < nb_pts );

  fprintf(stdout,"section #%4d  %6d points   %4d contours\n",
                                 nb+1,section->nbpt,section->nb_contours);
  if(section->nbpt != nb_pts) {
    fprintf(stderr, "ERROR section %d: %d points declared - %d points found\n",
              nb+1,nb_pts,section->nbpt);
    exit(1);
  }

  c_ptr = section->c_ptr;
  for(i=0; i<section->nb_contours ; i++) {
    fprintf(stdout,"      contour %4d    %6d points ",i+1,c_ptr->nb_vertex);
    switch(Isclockwise(c_ptr->v_list,c_ptr->nb_vertex)){
      case 0: {
             fprintf(stdout," cw\n");
             c_ptr->orientation = 0;
             break;
      }
      case 1: {
             fprintf(stdout," ccw\n");
             c_ptr->orientation = 1;
             break;
      }
      case -1: fprintf(stdout," orientation????");break;
      default:;
    }

    c_ptr = c_ptr->next;
  }
}


int read_contour(int i, X_SECTION *section)
{
  CONTOUR *c_ptr;
  VERTEX *vx;
  int ret, end = FALSE;
  char c;

  if(section->nb_contours >= Maxcontour) {
    fprintf(stderr,
      "ERROR: more than %d contours per plane. Use option -m\n", Maxcontour);
    exit(1);
  }
  section->nb_contours++;
  if (section->nb_contours == 1) { /*first contour*/
    section->c_ptr =  ((CONTOUR *)section->mem_ptr);
    section->mem_ptr = section->mem_ptr+sizeof(CONTOUR);
    c_ptr = section->c_ptr;
    c_ptr->next = NULL;
    c_ptr->prev = NULL;
  }
  else {
    c_ptr = section->c_ptr;
    while(c_ptr->next != NULL) { c_ptr = c_ptr->next; }
    c_ptr->next =  ((CONTOUR *)section->mem_ptr);
    section->mem_ptr = section->mem_ptr+sizeof(CONTOUR);
    c_ptr->next->prev = c_ptr;
    c_ptr->next->next = NULL;
    c_ptr = c_ptr->next;
  }

  c_ptr->nb_vertex=0;
  vx = ((VERTEX *)section->mem_ptr);
  section->mem_ptr = section->mem_ptr+sizeof(VERTEX);
  c_ptr->v_list = vx;
  c_ptr->depth = 0;
  vx->ident = NULL;

  do {
    if ( (ret = getc(fp1)) == EOF ) {
      fprintf(stderr, "   error reading contour\n");
      exit(1);
    }
  } while( (char)ret != '{' );

  do {
    if( fscanf(fp1,"%f%f",&(vx->x),&(vx->y)) == EOF) {
      fprintf(stderr, "   error reading contour\n");
      exit(1);
    }
    if(section->xmax < vx->x) section->xmax = vx->x;
    if(section->ymax < vx->y) section->ymax = vx->y;
    if(section->xmin > vx->x) section->xmin = vx->x;
    if(section->ymin > vx->y) section->ymin = vx->y;
    vx->nb = global_nb++;
    vx->ident = NULL;
    c_ptr->nb_vertex++;
    section->nbpt++;
    i++;

    do {
      c = (char)getc(fp1);
    } while( c == ' ' || c == '\n' );
    if ( c=='}') {
      end = TRUE;
    }
    else { /* still one more vertex */
      ungetc(c,fp1);
      vx->succ = ((VERTEX *)section->mem_ptr);
      section->mem_ptr = section->mem_ptr+sizeof(VERTEX);
      vx->ident = NULL;
      (vx->succ)->pred = vx;
      vx = vx->succ;
    }
  } while(!end);
  vx->succ = c_ptr->v_list;
  (c_ptr->v_list)->pred = vx;
  return(i);
}


void write_section(X_SECTION *section)
{
  int i,j;
  CONTOUR *c_ptr;
  VERTEX  *v_ptr;

  fprintf(fp3,"v %d z %f\n", section->nbpt-section->nb_2points, section->z);
  if (section->nbpt == 0) {
    return;
  }
  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    v_ptr = c_ptr->v_list;
    if (c_ptr->nb_vertex >= elim_small && !(select_depth && selected_depth != c_ptr->depth)) {
      fprintf(fp3,"{\n");
      for ( j=0 ; j< c_ptr->nb_vertex; j++) {
        fprintf(fp3,"%.2f %.2f\n", v_ptr->x, v_ptr->y);
        v_ptr = v_ptr->succ;
        if( v_ptr->pred->nb == -1)
          free((char *)v_ptr->pred);
      }
      fprintf(fp3,"}\n");
    }
    if( c_ptr->next == NULL)
      /*free((char *)c_ptr)*/;
    else {
      c_ptr = c_ptr->next;
    }
  }
  free( section->mem_base);
}

void approx_section(X_SECTION *section)
{
  int i;
  CONTOUR *c_ptr;
  VERTEX  *a_ptr;
  VERTEX *p1, *p2, *p3;
  int end, steps;
  double d, bad, max_distance(VERTEX *p1, VERTEX *p2);

  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++, c_ptr=c_ptr->next) {
    a_ptr = c_ptr->v_list;
    p1 = a_ptr;
    p2 = p1->succ;
    do {
      end = FALSE;
      do {
        if ( p2 == a_ptr ) {end = TRUE; break;}
        p3 = p2->succ;
        d = max_distance( p1, p3);
        if (d < Thr_a) {
          p2 = p3;
          section->nbpt--;
          c_ptr->nb_vertex--;
          continue;
        }
        else {
          steps = 1;
          do {
            bad = d;
            steps++;
            if (p3 != a_ptr) p3 = p3->succ;
            d = max_distance( p1, p3);
          } while( (d < bad) && (d > Thr_a) && (p3 != a_ptr) );
          if ((d < Thr_a) && (p3 != a_ptr)  ) {
            p2 = p3;
            section->nbpt = section->nbpt-steps;
            c_ptr->nb_vertex = c_ptr->nb_vertex-steps;
            continue;
          }
          else {
            /*endgueltig nix mehr drinn! verb p1 p2 */
            end = TRUE;
            break;
          }
        }
      } while ( !end);
      /*p1-p2*/
      p1->succ = p2;
      p2->pred = p1;
      p1 = p2;
      p2 = p1->succ;
    } while (p2 != a_ptr);
  }
}

double max_distance(VERTEX *p1, VERTEX *p2)
{
  double d, max = 0.0;
  double edge_distance(VERTEX *p1, VERTEX *p2, VERTEX *i);
  VERTEX *i;

  for (i = p1->succ ; i != p2 ; i=i->succ) {
    d = edge_distance(p1,p2,i);
    max = Max(max, d);
  }
  return(max);
}

double edge_distance(VERTEX *p1, VERTEX *p2, VERTEX *i)
/*calc orthogonal distance^2*/
                  
{
  double l,t;

  POINT r;
  r.x = p2->x - p1->x;
  r.y = p2->y - p1->y;

  t = (p1->y - i->y)* r.x - (p1->x - i->x)* r.y;
  l = t * t / (r.x*r.x + r.y*r.y);
  return(l);
}

void elim_2pt_section(X_SECTION *section)
{
  int i;
  CONTOUR *c_ptr;

  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++, c_ptr=c_ptr->next) {
    if (c_ptr->nb_vertex < elim_small || (select_depth && selected_depth != c_ptr->depth)) {
      section->nb_2points = section->nb_2points + c_ptr->nb_vertex;
    }
  }
}


void mask_out(X_SECTION *section)
/*delete all contours that are outside a bounding area*/
                   

{
  int i,j;
  CONTOUR *c_ptr, *back_ptr;
  VERTEX  *v_ptr;
  int del = 0;

  back_ptr = NULL;
  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++) {
    v_ptr = c_ptr->v_list;
    for ( j=0 ; j< c_ptr->nb_vertex-1; j++) {
      if (( mask && outside_mask(v_ptr)) ||
           (circle_mask && outside_circle(v_ptr)) ) {
        /*elim contour*/ 
        section->nbpt = section->nbpt - c_ptr->nb_vertex;
        del++;
        if(c_ptr == section->c_ptr) {/*first*/
          section->c_ptr = c_ptr->next;
        }
        else
          back_ptr->next = c_ptr->next;
        break; 
      }
      v_ptr = v_ptr->succ;
    }
    if (back_ptr == NULL || back_ptr->next == c_ptr ) back_ptr = c_ptr;
    c_ptr = c_ptr->next;
  }
  section->nb_contours = section->nb_contours - del;
}

int outside_mask(VERTEX *v)
{
  if ( 
    v->x < mask_x_min ||
    v->x > mask_x_max ||
    v->y < mask_y_min ||
    v->y > mask_y_max ) 
    return(1);
  return(0);
}

int outside_circle(VERTEX *v)
{
  if ( 
    (v->x  - c_mask_x)*(v->x  - c_mask_x) +
    (v->y  - c_mask_y)*(v->y  - c_mask_y) > c_mask_r 
  )
    return(1);
  return(0);
}

void approx_selected_section(X_SECTION *section)
{
  int i;
  CONTOUR *c_ptr;
  VERTEX  *a_ptr;
  VERTEX *p1, *p2, *p3;
  int end, steps;
  double d, bad, max_distance(VERTEX *p1, VERTEX *p2);

  c_ptr = section->c_ptr;
  for ( i=0 ; i< section->nb_contours; i++, c_ptr=c_ptr->next) {
    if (c_ptr->nb_vertex >= elim_small)
    if(c_ptr->depth == depth_selector) {
      a_ptr = c_ptr->v_list;
      p1 = a_ptr;
      p2 = p1->succ;
      do {
        end = FALSE;
        do {
          if ( p2 == a_ptr ) {end = TRUE; break;}
          p3 = p2->succ;
          d = max_distance( p1, p3);
          if (d < Thr_selection) {
            p2 = p3;
            section->nbpt--;
            c_ptr->nb_vertex--;
            continue;
          }
          else {
            steps = 1;
            do {
              bad = d;
              steps++;
              if (p3 != a_ptr) p3 = p3->succ;
              d = max_distance( p1, p3);
            } while( (d < bad) && (d > Thr_selection) && (p3 != a_ptr) );
            if ((d < Thr_selection) && (p3 != a_ptr)  ) {
              p2 = p3;
              section->nbpt = section->nbpt-steps;
              c_ptr->nb_vertex = c_ptr->nb_vertex-steps;
              continue;
            }
            else {
              /*endgueltig nix mehr drinn! verb p1 p2 */
              end = TRUE;
              break;
            }
          }
        } while ( !end);
        /*p1-p2*/
        p1->succ = p2;
        p2->pred = p1;
        p1 = p2;
        p2 = p1->succ;
      } while (p2 != a_ptr);
    }
  }
}
