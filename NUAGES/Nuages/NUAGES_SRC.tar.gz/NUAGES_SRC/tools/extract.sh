#!/bin/sh
#
#
# Example of using extract_contours for raw volume data
#
#
#

usage='extract.sh <raw_data> <contour_file> [-range <v1> <v2>] [-x <size>] [-y <size>]'

#

if [ x$1 = x -o x$2 = x ]
then
      echo $usage
      exit 1
fi

datafile=$1
outfile=$2
pid=$$

#default imagesize 512x512  unsigned short
xsize=512
ysize=512
pixelsize=2

#default range = 1250 to 4000

low=1250
high=4000

while [ x$3 != x ]; do
  case $3 in
     -range)  shift
              low=$3
              shift
              high=$3
              shift
              continue;;
     -x)      shift
              xsize=$3
              shift
              continue;;
     -y)      shift
              ysize=$3
              shift
              continue;;
     *)       echo $usage
             exit 1 ;;
    esac
done


bits_per_image=`expr $xsize "*" $ysize `
bits_per_image=`expr $bits_per_image "*" $pixelsize`


#calculate number of images
nb=`cat $datafile | wc -c`
nb=`expr $nb / $bits_per_image `

#write number of images to outfile
echo "s $nb" > $outfile

count=0
offset=0
zcoordinate=0

while [ $count != $nb ];
do
  extract_contours $datafile tmpfile$pid -hdr $offset  -z $zcoordinate  -range  $low $high -x $xsize -y $ysize

  offset=`expr $offset + $bits_per_image`
  count=`expr $count + 1`
  zcoordinate=`expr $zcoordinate + 1`
  cat tmpfile$pid >> $outfile
 
done
