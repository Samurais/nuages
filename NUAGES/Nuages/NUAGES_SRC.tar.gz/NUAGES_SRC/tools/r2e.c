#ifndef lint
static  char *sccsid = "%W% %D%";
#endif

/************************************************************************ 
 * r2e.c 	  Version 2.0  Oct 14 1993				* 
 * old repros format -> cnt format					* 
 *									* 
 * Copyright 1993 Bernhard Geiger					* 
 *									* 
 *									* 
 ************************************************************************/ 
/************************************************************************
 *                      Modification History                            *
 * Apr 10 1997 inclusion of stdlib.h and string.h                       *
 ************************************************************************/


#include <math.h>
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>


#define Min(a,b)  (((a) < (b)) ? (a):(b))
#ifndef FALSE
#define TRUE 1
#define FALSE 0
#endif

#define EXEPTION_VAL 1000000.0

#define MAX_CONTOUR   100  /*max nb of contours / plane */


#define F_OPEN(fp,fname,x,string) \
  fp = fopen(fname, x); \
    if (fp == NULL) { \
      fprintf(stderr,string,fname); \
      fflush(stderr); \
      exit(1); \
    } \


typedef
  struct vertex {
    float x,y;
    int nb;
    struct vertex *ident;
    struct vertex *succ;
    struct vertex *pred;
  } VERTEX;
    
typedef
  struct contour {
    int nb_vertex;
    int depth;
    int orientation;
    VERTEX  *v_list;
    struct contour *next;
    struct contour *prev;
  } CONTOUR;

  


typedef
  struct x_section {
    int nbpt;
    float z;
    float xmin, xmax;
    float ymin, ymax;
    float minlength, maxlength;
    int nb_contours;
    CONTOUR *c_ptr;
    char *mem_ptr;
    char *mem_base;
    unsigned  mem_size;
  } X_SECTION;


FILE *fopen(),*fp1,*fp2,*fp3,*fp4,*fp5,*fp6;
float	n;
int	successor =	1;
int	global_nb =	1;
int old_format_out =	FALSE;
int	exit_status =	0;
char    *in_file, *out_file;

/*****************************************************************/
main(argc,argv)
/*****************************************************************/
int argc; char **argv;

{
  X_SECTION *section[2];
  int i, k, nb_sections;
  int read_section();
  float angle   = 1.0;
  int filecount = 0;
  char *fnam1;
  char *fnam2;

  section[0] = (X_SECTION *)malloc( sizeof(X_SECTION) );
  if(section[0] == NULL) {
    fprintf(stderr, "cannot allocate section 0\n");
    exit(1);
  }
  section[0]->nbpt = 0;
  section[0]->c_ptr = NULL;
  section[0]->nb_contours = 0;

  section[1] = (X_SECTION *)malloc( sizeof(X_SECTION) );
  if(section[1] == NULL) {
    fprintf(stderr, "cannot allocate section 1\n");
    exit(1);
  }
  section[1]->nbpt = 0;
  section[1]->c_ptr = NULL;
  section[1]->nb_contours = 0;

  if (argc < 3) {
    Usage(argv);
    exit(1);
  }
  in_file = argv[1];
  out_file = argv[2];
  fnam1 = (char *)malloc(strlen(in_file)+10);
  fnam2 = (char *)malloc(strlen(in_file)+10);
  if (fnam1 == NULL || fnam2 == NULL) {
    fprintf(stderr,"cannot allocate filenames\n");
  }
  strcpy(fnam1,in_file);
  strcat(fnam1,".descr");
  F_OPEN(fp1,fnam1,"r","cannot open %s\n");
  strcpy(fnam2,in_file);
  strcat(fnam2,".coord");
  F_OPEN(fp2,fnam2,"r","cannot open %s\n");
  F_OPEN(fp3,out_file, "w", "cannot open %s\n");


  fscanf(fp1, "%d", &nb_sections);
  fprintf(fp3, "S %d\n", nb_sections);
  for (i=1; i<(nb_sections +1); i++) {
    read_section(i,section[0]);
    write_section(section[0]);
  }
  fclose(fp1);
  fclose(fp2);
  fclose(fp3);
  exit(0);
}




int read_section(nb,section)
X_SECTION *section;
int nb;

{
  int i, start,new_contour,s,p;
  float z;
  CONTOUR *c_ptr;
  VERTEX *vx;

  section->nb_contours = 0;
  section->xmin =  EXEPTION_VAL;
  section->xmax = -EXEPTION_VAL;
  section->ymin =  EXEPTION_VAL;
  section->ymax = -EXEPTION_VAL;
  fscanf(fp1,"%d",&(section->nbpt));

  if(section->nbpt<1) {
    printf("x-section %d is empty\n",nb+1);
    return;
  }
  if(section->nbpt<3) {
    printf("%d points in x-section %d - eliminated \n",section->nbpt,nb+1);
    section->nbpt = 0;
    return;
  }

  section->mem_size = sizeof(VERTEX) * section->nbpt  +
                      sizeof(CONTOUR) * MAX_CONTOUR;
  section->mem_base = (char *)malloc(section->mem_size);
  if(section->mem_base == NULL) {
    fprintf(stderr,"mem alloc failed\n");
    exit(1);
  }
  section->mem_ptr = section->mem_base;
  
  section->nb_contours++;
  section->c_ptr =  ((CONTOUR *)section->mem_ptr);
  section->mem_ptr = section->mem_ptr+sizeof(CONTOUR);
  c_ptr = section->c_ptr;
  c_ptr->next = NULL;
  c_ptr->prev = NULL;
  c_ptr->depth = 0;

  vx = ((VERTEX *)section->mem_ptr);
  section->mem_ptr = section->mem_ptr+sizeof(VERTEX);
  c_ptr->v_list = vx;
  fscanf(fp2,"%f %f %f %d %d",&(vx->x),&(vx->y),&z,&s,&p);
  if(section->xmax < vx->x) section->xmax = vx->x;
  if(section->ymax < vx->y) section->ymax = vx->y;
  if(section->xmin > vx->x) section->xmin = vx->x;
  if(section->ymin > vx->y) section->ymin = vx->y;
  vx->nb = global_nb++;
  vx->ident = NULL;
  c_ptr->nb_vertex = 1;
  start = s-1;
  new_contour = 0;


  for (i=1 ; i<section->nbpt ; i++) {
    if(new_contour) {
      vx->succ = c_ptr->v_list;
      (c_ptr->v_list)->pred = vx;
      section->nb_contours++;
      c_ptr->next =  ((CONTOUR *)section->mem_ptr);
      section->mem_ptr = section->mem_ptr+sizeof(CONTOUR);
      c_ptr->next->prev = c_ptr;
      c_ptr->next->next = NULL;
      c_ptr = c_ptr->next;
      vx = ((VERTEX *)section->mem_ptr);
      section->mem_ptr = section->mem_ptr+sizeof(VERTEX);
      vx->ident = NULL;
      c_ptr->v_list = vx;
      c_ptr->depth = 0;
      fscanf(fp2,"%f %f %f %d %d",&(vx->x),&(vx->y),&z,&s,&p);
      if(section->xmax < vx->x) section->xmax = vx->x;
      if(section->ymax < vx->y) section->ymax = vx->y;
      if(section->xmin > vx->x) section->xmin = vx->x;
      if(section->ymin > vx->y) section->ymin = vx->y;
      vx->nb = global_nb++;
      c_ptr->nb_vertex = 1;
      start = s-1;
      new_contour = 0;
    }
    else {
      vx->succ = ((VERTEX *)section->mem_ptr);
      section->mem_ptr = section->mem_ptr+sizeof(VERTEX);
      vx->ident = NULL;
      (vx->succ)->pred = vx;
      vx = vx->succ;
      fscanf(fp2,"%f %f %f %d %d",&(vx->x),&(vx->y),&z,&s,&p);
      if(section->xmax < vx->x) section->xmax = vx->x;
      if(section->ymax < vx->y) section->ymax = vx->y;
      if(section->xmin > vx->x) section->xmin = vx->x;
      if(section->ymin > vx->y) section->ymin = vx->y;
      vx->nb = global_nb++;
      c_ptr->nb_vertex++;
      if(s == start) new_contour = 1;
    }
  }
  vx->succ = c_ptr->v_list;
  (c_ptr->v_list)->pred = vx;
  section->z = z;

  fprintf(stdout,"section #%4d  %6d points   %4d contours\n",
                                 nb+1,section->nbpt,section->nb_contours);
  c_ptr = section->c_ptr;
  for(i=0; i<section->nb_contours ; i++) {
    fprintf(stdout,"      contour %4d    %6d points \n",i+1,c_ptr->nb_vertex);
    c_ptr = c_ptr->next;
  }

}

int write_section(section)
/* messed up by -ajk- */
X_SECTION *section;

{
  int i,j,s;
  CONTOUR *c_ptr;
  VERTEX  *v_ptr;

  s = successor;
  fprintf(fp3,"v %d z %f\n", section->nbpt, section->z);
    c_ptr = section->c_ptr;
    for ( i=0 ; i< section->nb_contours; i++) {
      v_ptr = c_ptr->v_list;
      fprintf(fp3,"{\n");
      for ( j=0 ; j< c_ptr->nb_vertex; j++) {
        fprintf(fp3,"%.2f %.2f\n", v_ptr->x, v_ptr->y);
        v_ptr = v_ptr->succ;
        if( v_ptr->pred->nb == -1)
          free((char *)v_ptr->pred);
      }
      fprintf(fp3,"}\n");
      s = s + j;
      if( c_ptr->next == NULL)
        /*free((char *)c_ptr)*/;
      else {
        c_ptr = c_ptr->next;
      }
    }
  if (old_format_out) successor = successor + section->nbpt;
  free( section->mem_base);
}

Usage(argv)
char **argv;
{
  fprintf(stderr,"Usage: %s in_file out_file\n", argv[0]);
  fprintf(stderr,"        in_file.descr in_file.coord -> outfile\n");
}
