#ifndef lint
static  char *sccsid = "%W% %D%";
#endif

/************************************************************************
 * repros2visu.c   Version 2.0  Oct 14 1993				*
 * repros-output -> obj / off / dxf / vera / act / idx and other format	*
 *									*
 * Copyright 1993-96 INRIA 						*
 *									*
 ***********************************************************************/
/************************************************************************
 * 			Modification History				*
 * Apr 15 1997 in main() initialization of fac0->nb0/1/01               *
 * Apr 10 1997 in memory_alloc cast in size_t instead of int            *
 * Dec 08 1996 Bug in elim_double(), speedup 		                *
 * Aug 13 1996 STL format added				                *
 * Sep 21 1995 VRML  and Openinventor format added                      *
 * Jan 25 1995 translated to ANSI C                                     *
 * Jan 20 1995 -n for OFF, OBJ, IDX format completed			*
 * Dec 29 1994 #ifndef VMS_NUAGES added					*
 * Sep  5 1994  normalization of normals after -matrix			*
 * Jul 15 1994  Several modifications (-n changed, -matrix added)	*
 * Mar  9 1994  bug in idx format removed				*
 *									*
 ************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <math.h>
#include <string.h>
#include <unistd.h>

#ifndef VMS_NUAGES

#include <malloc.h>

#else

#define M_PI 3.141592653589793238462643383279503

#endif

#include<time.h>
#include<sys/time.h>

#ifndef FALSE
#define FALSE 0
#define TRUE  1
#endif
#define ODD(x) ((x) & 1)

/* output format spec */
#define OBJ	0	/* object format */
#define VERA	1	/* vera ray trace format */
#define IDX	2	/* index format */
#define ACT	3	/* act format */
#define OFF	4	/* OFF format */
#define DXF	5	/* Autocad format */
#define AVS	6	/* AVS format */
#define VRML	7	/* VRML format */
#define INV	8	/* Openinventor format */
#define STL     9       /* STL rapid prototyping */

#define LOWER   0
#define UPPER   1
#define ALL     2
#define ADD     0
#define SUB     1

#define EXEPTION_VAL 1000000.0


#define MAXVERTEX 10000               /*max number of points per cross-section*/
#define MAXFACETT (4*(MAXVERTEX - 1)) /*max number of triangles per slice */

/*w = M*v*/
#define MATRIX_MULT(w,M,v)  \
 w[0] = M[0][0]*v[0] + M[0][1]*v[1] + M[0][2]*v[2] + M[0][3]; \
 w[1] = M[1][0]*v[0] + M[1][1]*v[1] + M[1][2]*v[2] + M[1][3]; \
 w[2] = M[2][0]*v[0] + M[2][1]*v[1] + M[2][2]*v[2] + M[2][3]
/*w = M*v no translation*/
#define MATRIX_MULTV(w,M,v)  \
 w[0] = M[0][0]*v[0] + M[0][1]*v[1] + M[0][2]*v[2]; \
 w[1] = M[1][0]*v[0] + M[1][1]*v[1] + M[1][2]*v[2]; \
 w[2] = M[2][0]*v[0] + M[2][1]*v[1] + M[2][2]*v[2]
#define VEC_LEN(v) (sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]))
#define VEC_DIV(v, a) v[0] /= a, v[1] /= a, v[2] /= a;
#define VEC_NORM(v) { double l = VEC_LEN(v); VEC_DIV(v, l); }


typedef float KOORD [MAXVERTEX][2];          /* coordinates x,y */
typedef float POINTNORM [MAXVERTEX][3];      /* normals of each point*/
typedef int   FACETTE [MAXFACETT][3];        /* triangles */
typedef float FACNORM [MAXFACETT][3];        /* normals of triangles*/


typedef
  struct snode {        /* to form list of triangles containing a point */
    int fac;            /* nb of triangle containing the point */
    float angle;        /*  */
    FACNORM *base;      /* indicates plane1 or plane2 */
    struct snode *next; /*pointer to next SNODE */
 } SNODE; 

typedef SNODE  *(SLIST [MAXVERTEX]); /* for each point one list of triangles*/

typedef
  struct plane {        /**** description of one cross-section */
    int start,stop;     /*nb of first and last point of one cross-section*/
    float z;            /*z-coordinate of cross-section*/
    KOORD *point;       /*x,y-coordinates of points*/
    POINTNORM *pnorm;   /*normal of each point - we will calculate them */
    SLIST *simplist;    /*list of triangles containing the points*/
    char *s_ptr;       /*pointer to available memory*/
  } PLANE;

typedef
  struct fac_slice {    /**** description of one slice */
    int nb;             /* nb of triangles */
    int nb0;            /* number of horizontal tris in lower p */
    int nb01;           /* number of non-horizontal tris */
    int nb1;            /* number of horizontal tris in upper p*/
    FACETTE *fac;       /* triangles */
    FACNORM *fnorm;     /* normal of each triangle */
  } FAC_SLICE;

/* globals */

int   Maxvertex, Maxfacett, mv_changed, mf_changed;
int   remove_h[100];
char  *(fnam[6]);
float direction;
char  *vertex_file_name;
char  *tile_file_name;
char  *normidx_file_name;
char  *normal_file_name;
FILE  *koord_file,*fac_file,*out_file;
FILE  *vertex_file, *normal_file, *tile_file, *normidx_file;
int   fac_buffer[3];
float norm_buffer[3];
int   koord_count = 0;
int   fac_count = 0;
short remove_horizontal = FALSE;/*do not remove horizontal triangles*/
short n_remove = 0;
short n_nosmooth = 0;
int   nosmooth[10];
short plane_counter = 0;
int   nb_slices = 0;
int   nb_sections = 0;
int   out_format = OBJ;
int   no_weight = FALSE;
int   obj_offset = 0;
char  *obj_name = "object";
char  *header = "";
int   mmult = FALSE;
float matrix[4][4]={ {1.0, 0.0, 0.0, 0.0},
                     {0.0, 1.0, 0.0, 0.0},
                     {0.0, 0.0, 1.0, 0.0},
                     {0.0, 0.0, 0.0, 1.0} };
int *idx_fac_buffer;
int idx_count = 0;


void vertex_face_open(void);
void vertex_face_close(void);
void vertex_normal_face_open(void);
void vertex_normal_face_close(void);
void read_matrix(char *fn);
void read_points(PLANE *pl);
void read_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2);
void elim_double(FAC_SLICE *fac0, FAC_SLICE *fac1);
void norm_(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2);
void init(PLANE *pl);
void normal(int i, FAC_SLICE *fac, PLANE *pl[2]);
void memory_alloc(FAC_SLICE *fac0, FAC_SLICE *fac1, PLANE *pl0,
                             PLANE *pl1, PLANE *pl2, char **work_buffer);
void norm_2(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2);
void write_act_points(PLANE *pl, int m);
void write_act_facettes(FAC_SLICE *, PLANE *, PLANE *, int m);
void write_vera_facettes(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1, int m);
void grab_arguments(int argc, char **argv);
void write_index_facettes(FAC_SLICE *fac, PLANE *pl1,
                                      PLANE *pl2, int m, int *n, int nb);
void write_index_points(PLANE *pl, int m, int n);
void eliminate_horizontal(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1, int m);
void write_obj_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m);
void write_obj_points(PLANE *pl, int m);
void write_dxf_facettes(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1);
void write_stl_facettes(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1);

void write_avs_points(PLANE *pl, int m);
void write_avs_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m);
void write_off_points(PLANE *pl, int m);
void write_off_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m);
void shift_indices(PLANE *, PLANE *, int);
void save_index_facettes(FAC_SLICE *, PLANE *, PLANE *, int);
void write_saved_facettes(int nb);
int calc_index_facettes(FAC_SLICE *, PLANE *, PLANE *, int);
int equal(int, int, int [][3], int [][3]);
void write_vrml_points(PLANE *, int);
void write_vrml_facettes(FAC_SLICE *, PLANE *, PLANE *, int);
void Usage(void);


main(int argc, char **argv)
/********************************************************************/
/*                                                                  */
/*         main                                                     */
/*                                                                  */
/*                                                                  */
/********************************************************************/

{
  FAC_SLICE facett0, facett1;        /*we need 2 adjacent slices on same time*/
  FAC_SLICE *fac0, *fac1, *help_fac;
  PLANE plane0, plane1, plane2;      /*3 cross-sections for 2 adj. slices*/
  PLANE *pl0, *pl1, *pl2, *help_pl;
  char *work_buffer;
  int i,j,ns = FALSE;
  int nb_idx_fac;
  int do_next = 1;
  char *date;
  char str[10];
#ifndef VMS_NUAGES
  struct timeval t;
#else
  timeb_t t;
#endif

  mf_changed = mv_changed = FALSE;
  

  Maxvertex = MAXVERTEX;
  Maxfacett = 4 * (Maxvertex-1);

  grab_arguments(argc, argv); 

  if ( mv_changed && !mf_changed )
    Maxfacett = 4 * (Maxvertex-1);
 
  fac_file = fopen(fnam[0], "r");
  if (fac_file == NULL) {
    fprintf(stderr , "triangle-file not found\n");
    fflush(stderr);
    exit(1);
  }
  koord_file = fopen(fnam[1], "r");
  if (koord_file == NULL) {
    fprintf(stderr , "point-file not found\n");
    fflush(stderr);
    exit(1);
  }
  fscanf(koord_file, "%s%d",str, &nb_sections);

  out_file = fopen(fnam[2], "w");
  if (out_file == NULL) {
    fprintf(stderr , "cannot open output\n");
    fflush(stderr);
    exit(1);
  }
  fscanf(fac_file,"%d", &nb_slices);
  if (nb_slices != nb_sections-1) {
    fprintf(stderr,"  error: %d sections vs %d slices\n", nb_sections, nb_slices);
    exit(1);
  }

#ifndef VMS_NUAGES
  if (gettimeofday(&t, NULL) == -1)
    perror("gettimeofday");
  date = ctime(&(t.tv_sec));
  /* on DEC, time_t is int!! Probably a bug. */
#else
  ftime(&t);
  date = ctime(&t.time);
#endif

  switch (out_format) {
    case OBJ :
      fprintf( out_file, "# File generated by nuages-repros\n");
      fprintf( out_file, "# %s", date);
      if( strlen(header) != 0 )
        fprintf(out_file, "# %s\n", header);
      fprintf( out_file, "# %d slices\n", nb_slices);
      fprintf( out_file, "g %s\n", obj_name);
      break;
    case VRML :
    case INV :
      if (out_format==INV) {
        fprintf( out_file, "#Inventor V2.0 ascii\n\n");
        out_format = VRML;
      }
      else 
        fprintf( out_file, "#VRML V1.0 ascii\n\n");
      fprintf( out_file, "Separator {\n");
      fprintf( out_file,
         "Info { string \" Generated by NUAGES \n");
      date[24] = ' ';
      fprintf( out_file, " %s \"}\n\n", date);
      if( strlen(header) != 0 )
        fprintf(out_file, "Info { string \" %s \"}\n\n", header);
      fprintf( out_file, "ShapeHints {\n  vertexOrdering  COUNTERCLOCKWISE\n");
      fprintf( out_file, "  faceType CONVEX\n}\n\n");

      fprintf( out_file, "# %d slice[s]\n", nb_slices);
      vertex_normal_face_open();
      fprintf(vertex_file, "Coordinate3{ point[\n");
      fprintf(normal_file, "Normal{ vector [\n");
      fprintf(tile_file, "IndexedFaceSet{ coordIndex[\n");
      fprintf(normidx_file, "normalIndex [\n");
      break;
    case OFF :
      fprintf( out_file, "# File generated by nuages-repros\n");
      fprintf( out_file, "# %s", date);
      if( strlen(header) != 0 )
        fprintf(out_file, "# %s\n", header);
      fprintf( out_file, "# %d slices\n", nb_slices);
      fprintf( out_file, "# off file with per vertex normal\n");
      fprintf( out_file, "NOFF\n");
      vertex_face_open();
      break;
    case STL :
      n_nosmooth = 0; /* STL has no vertex normal output */
      fprintf( out_file, "SOLID\n");
      break;
    case DXF :
      n_nosmooth = 0; /* DXF has no vertex normal output */
      fprintf( out_file, "999\nFile generated by nuages-repros\n");
      fprintf( out_file, "999\n%s", date);
      if( strlen(header) != 0 )
        fprintf( out_file, "999\n%s\n", header);
      fprintf( out_file, "  0\nSECTION\n  2\nHEADER\n  0\nENDSEC\n");
      fprintf( out_file, "  0\nSECTION\n  2\nENTITIES\n  0\n");
      break;
    case VERA :
      fprintf( out_file, "(* File generated by nuages-repros\n");
      fprintf( out_file, "   %s*)\n", date);
      if( strlen(header) != 0 )
        fprintf(out_file, "(* %s *)\n", header);
      break;
    case IDX :
      if (mmult) {
        fprintf(stderr, "IDX format: -matrix not supported\n");
        exit(1);
      }
      if( strlen(header) != 0 )
        fprintf(out_file, "%s\n", header);
      fprintf( out_file, "S %d\n", nb_slices);
      break;
    case ACT :
      vertex_face_open();
      break;
    case AVS :
      /*fprintf( out_file, "# File generated by nuages-repros\n");
      fprintf( out_file, "# %s", date);
      if( strlen(header) != 0 )
        fprintf(out_file, "# %s\n", header);
      fprintf( out_file, "# %d slices\n", nb_slices);
      fprintf( out_file, "# off file with per vertex normal\n");
      fprintf( out_file, "NOFF\n"); */
      fprintf( out_file, "smooth\n"); 
      vertex_face_open();
      break;
  }

  pl0 = &plane0;
  pl1 = &plane1;
  pl2 = &plane2;

  fac0 = &facett0;
  fac1 = &facett1;

  memory_alloc(fac0,fac1,pl0,pl1,pl2,&work_buffer);

  fac0->nb = 0;
  fac0->nb0  = 0;
  fac0->nb01 = 0;
  fac0->nb1  = 0;
  pl0->start = 0;
  pl0->stop = 0;
  fac_buffer[0] = -1;

  read_points(pl1);   /*read points of first cross-section */
  init(pl1);

  for (i=0 ; i<nb_slices ; i++) {
    read_points(pl2); /*read points of following cross-section*/
    init(pl2);
    plane_counter++;
    read_facettes(fac1,pl1,pl2); /*read triangles of one slice*/
    printf("slice #%d\n",i+1);
    elim_double(fac0,fac1); /*delete horizontal triangles that appear twice*/
    for(j=0 ; j<n_nosmooth ; j++) 
      if(nosmooth[j] == plane_counter)  {ns = TRUE; break;} 
    if(ns) { /* don't do normal interpolation across pl1 */
      if (plane_counter == 1) {/*must distinguish between first or later x_sec*/
        switch(out_format) {
          case VERA :
            write_vera_facettes(fac1,pl1,pl2,LOWER);
            eliminate_horizontal(fac1,pl1,pl2,LOWER);
            break;
          case OFF :
            write_off_points(pl1,LOWER); /*duplicate*/
            write_off_facettes(fac1, pl1, pl2, LOWER);
            eliminate_horizontal(fac1,pl1,pl2, LOWER);
            norm_(fac1,pl1,pl2);
            write_off_points(pl1,ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case AVS :
            write_avs_points(pl1, LOWER); /*duplicate*/
            write_avs_facettes(fac1, pl1, pl2, LOWER);
            eliminate_horizontal(fac1,pl1,pl2, LOWER);
            norm_(fac1,pl1,pl2);
            write_avs_points(pl1,ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case ACT :
            write_act_points(pl1,LOWER); /*duplicate*/
            write_act_facettes(fac1, pl1, pl2, LOWER);
            eliminate_horizontal(fac1,pl1,pl2, LOWER);
            norm_(fac1,pl1,pl2);
            write_act_points(pl1,ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case OBJ :
            write_obj_points(pl1,LOWER); /*duplicate*/
            write_obj_facettes(fac1, pl1, pl2, LOWER);
            eliminate_horizontal(fac1,pl1,pl2, LOWER);
            norm_(fac1,pl1,pl2);
            write_obj_points(pl1,ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case VRML :
            write_vrml_points(pl1,LOWER); /*duplicate*/
            write_vrml_facettes(fac1, pl1, pl2, LOWER);
            eliminate_horizontal(fac1,pl1,pl2, LOWER);
            norm_(fac1,pl1,pl2);
            write_vrml_points(pl1,ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case IDX :
            nb_idx_fac = calc_index_facettes(fac1, pl1, pl2, LOWER);
            write_index_points(pl1,LOWER,0); /*duplicate*/
            save_index_facettes(fac1, pl1, pl2, LOWER);
            eliminate_horizontal(fac1,pl1,pl2, LOWER);
            norm_(fac1,pl1,pl2);
            write_index_points(pl1,ALL,-1);
            /*write_index_facettes(fac1, pl1, pl2, LOWER, &do_next , nb_idx_fac);*/
            /*write_saved_facettes(nb_idx_fac);*/
            do_next = FALSE;
            shift_indices(pl1,pl2,ADD);
            break;
          default :
            fprintf(stderr,"option -n currently not supported with first or last section\n");
            exit(1);
        }
      }
      else { /*no smooth, not first or last section */
        norm_2(fac1,pl1,pl2);     /*calculate the normals */
        switch(out_format) {
          case VERA :
            write_vera_facettes(fac0, pl0, pl1, ALL);
            norm_(fac1,pl1,pl2);     /*calculate the normals */
            break;
          case IDX :
            nb_idx_fac = calc_index_facettes(fac0, pl1, pl2, ALL);
            write_index_facettes(fac0, pl0, pl1, ALL, &do_next, nb_idx_fac);
            write_index_points(pl1, ALL, 0);
            norm_(fac1,pl1,pl2);     /*calculate the normals */
            write_index_points(pl1, ALL, -1);
            shift_indices(pl1,pl2,ADD);
            break;
          case AVS :
            write_avs_facettes(fac0, pl0, pl1, ALL);
            write_avs_points(pl1, ALL);
            norm_(fac1,pl1,pl2);     /*calculate the normals */
            write_avs_points(pl1, ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case ACT :
            write_act_facettes(fac0, pl0, pl1, ALL);
            write_act_points(pl1, ALL);
            norm_(fac1,pl1,pl2);     /*calculate the normals */
            write_act_points(pl1, ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case VRML :
            write_vrml_facettes(fac0, pl0, pl1, ALL);
            write_vrml_points(pl1, ALL);
            norm_(fac1,pl1,pl2);     /*calculate the normals */
            write_vrml_points(pl1, ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case OBJ :
            write_obj_facettes(fac0, pl0, pl1, ALL);
            write_obj_points(pl1, ALL);
            norm_(fac1,pl1,pl2);     /*calculate the normals */
            write_obj_points(pl1, ALL);
            shift_indices(pl1,pl2,ADD);
            break;
          case OFF :
            write_off_facettes(fac0, pl0, pl1, ALL);
            write_off_points(pl1, ALL);
            norm_(fac1,pl1,pl2);     /*calculate the normals */
            write_off_points(pl1, ALL);
            shift_indices(pl1,pl2,ADD);
            break;
        }
      }
      ns = FALSE;
    } 
    else {
      norm_(fac1,pl1,pl2);     /*calculate the normals */
      switch(out_format) {
        case VERA :
           write_vera_facettes(fac0, pl0, pl1, ALL);
           break;
        case STL :
           write_stl_facettes(fac0, pl0, pl1);
           break;
        case DXF :
           write_dxf_facettes(fac0, pl0, pl1);
           break;
        case ACT :
          write_act_points(pl1, ALL);
          write_act_facettes(fac0, pl0, pl1, ALL);
          break;
        case IDX :
          nb_idx_fac = calc_index_facettes(fac0, pl1, pl2, ALL);
          if (i>0)
            write_index_facettes(fac0, pl0, pl1, ALL, &do_next, nb_idx_fac);
          write_index_points(pl1, ALL, 1);
          break;
        case OFF :
          write_off_points(pl1, ALL);
          write_off_facettes(fac0, pl0, pl1, ALL);
          break;
        case OBJ :
          write_obj_points(pl1, ALL);
          write_obj_facettes(fac0, pl0, pl1, ALL);
          break;
        case VRML :
          write_vrml_points(pl1, ALL);
          write_vrml_facettes(fac0, pl0, pl1, ALL);
          break;
        case AVS :
          write_avs_points(pl1, ALL);
          write_avs_facettes(fac0, pl0, pl1, ALL);
          break;
      }
    }
    help_fac = fac0; fac0 = fac1; fac1 = help_fac; /*turn around*/
    help_pl = pl0; pl0 = pl1; pl1 = pl2; pl2 = help_pl; /*also*/
  }
  fac1->nb = 0;

  for(j=0 ; j<n_nosmooth ; j++) 
    if(nosmooth[j] == plane_counter+1)  {ns = TRUE; break;}
  if(ns) { /*last !! */
    switch( out_format) {
      case VERA :
        write_vera_facettes(fac0,pl0,pl1, UPPER);
        eliminate_horizontal(fac0,pl0,pl1, UPPER);
        norm_(fac1,pl1,pl2); /*calc. normals of last slice*/
        write_vera_facettes(fac0, pl0, pl1, ALL); /*write last slice*/
        break;
      case OFF :
        shift_indices(pl1,pl2,ADD);
        write_off_facettes(fac0, pl0, pl1, UPPER);
        shift_indices(pl1,pl2,SUB);
        eliminate_horizontal(fac0,pl0,pl1,UPPER);
        norm_(fac1,pl1,pl2); /*calc. normals of last slice*/
        write_off_points(pl1, ALL);
        write_off_facettes(fac0, pl0, pl1, ALL);
        write_off_points(pl1, UPPER); /*duplicate*/
        shift_indices(pl1,pl2,ADD);
        break;
      case OBJ :
        shift_indices(pl1,pl2,ADD);
        write_obj_facettes(fac0, pl0, pl1, UPPER);
        shift_indices(pl1,pl2,SUB);
        eliminate_horizontal(fac0,pl0,pl1,UPPER);
        norm_(fac1,pl1,pl2); /*calc. normals of last slice*/
        write_obj_points(pl1, ALL);
        write_obj_facettes(fac0, pl0, pl1, ALL);
        write_obj_points(pl1, UPPER); /*duplicate*/
        shift_indices(pl1,pl2,ADD);
        break;
      case VRML :
        shift_indices(pl1,pl2,ADD);
        write_vrml_facettes(fac0, pl0, pl1, UPPER);
        shift_indices(pl1,pl2,SUB);
        eliminate_horizontal(fac0,pl0,pl1,UPPER);
        norm_(fac1,pl1,pl2); /*calc. normals of last slice*/
        write_vrml_points(pl1, ALL);
        write_vrml_facettes(fac0, pl0, pl1, ALL);
        write_vrml_points(pl1, UPPER); /*duplicate*/
        shift_indices(pl1,pl2,ADD);
        break;
      case IDX :
        nb_idx_fac = calc_index_facettes(fac0, pl1, pl2, UPPER);
        shift_indices(pl1,pl2,ADD);
        write_index_facettes(fac0, pl0, pl1, UPPER, &do_next, nb_idx_fac);
        do_next = FALSE;
        shift_indices(pl1,pl2,SUB);
        eliminate_horizontal(fac0,pl0,pl1,UPPER);
        norm_(fac1,pl1,pl2); /*calc. normals of last slice*/
        write_index_facettes(fac0, pl0, pl1, ALL, &do_next, nb_idx_fac);
        write_index_points(pl1, ALL, 0);
        write_index_points(pl1, UPPER, -1); /*duplicate*/
        shift_indices(pl1,pl2,ADD);
        break;
      case ACT :
        shift_indices(pl1,pl2,ADD);
        write_act_facettes(fac0, pl0, pl1, UPPER);
        shift_indices(pl1,pl2,SUB);
        eliminate_horizontal(fac0,pl0,pl1,UPPER);
        norm_(fac1,pl1,pl2); /*calc. normals of last slice*/
        write_act_points(pl1, ALL);
        write_act_facettes(fac0, pl0, pl1, ALL);
        write_act_points(pl1, UPPER); /*duplicate*/
        shift_indices(pl1,pl2,ADD);
        break;
      case AVS :
        shift_indices(pl1,pl2,ADD);
        write_avs_facettes(fac0, pl0, pl1, UPPER);
        shift_indices(pl1,pl2,SUB);
        eliminate_horizontal(fac0,pl0,pl1,UPPER);
        norm_(fac1,pl1,pl2); /*calc. normals of last slice*/
        write_avs_points(pl1, ALL);
        write_avs_facettes(fac0, pl0, pl1, ALL);
        write_avs_points(pl1, UPPER); /*duplicate*/
        shift_indices(pl1,pl2,ADD);
        break;
      default :
          fprintf(stderr,"option -n currently not supported with first or last section\n");
          exit(1);
    }
  }
  else { /* smooth */
    norm_(fac1,pl1,pl2);             /*calc. normals of last slice*/
    switch(out_format) {
      case VERA :
         write_vera_facettes(fac0, pl0, pl1, ALL); /*write last slice*/
         break;
      case STL :
         write_stl_facettes(fac0, pl0, pl1);
         break;
      case DXF :
         write_dxf_facettes(fac0, pl0, pl1);
         break;
      case ACT :
        write_act_points(pl1, ALL);
        write_act_facettes(fac0, pl0, pl1, ALL);
        break;
      case IDX :
        nb_idx_fac = calc_index_facettes(fac0, pl1, pl2, ALL);
        write_index_facettes(fac0, pl0, pl1, ALL, &do_next, nb_idx_fac);
        write_index_points(pl1, ALL, 1);
        break;
      case OBJ :
        write_obj_points(pl1, ALL);
        write_obj_facettes(fac0, pl0, pl1, ALL);
        break;
      case VRML :
        write_vrml_points(pl1, ALL);
        write_vrml_facettes(fac0, pl0, pl1, ALL);
        break;
      case OFF :
        write_off_points(pl1, ALL);
        write_off_facettes(fac0, pl0, pl1, ALL);
        break;
      case AVS :
        write_avs_points(pl1, ALL);
        write_avs_facettes(fac0, pl0, pl1, ALL);
        break;
    }
  }
  fclose(koord_file);
  fclose(fac_file);

  switch (out_format) { 
    case ACT :
          fprintf(out_file, "%s = Creer_Polyedre (\"%s\", %d, %d, %d);\n",
                        obj_name, obj_name, fac_count,
                        koord_count, koord_count);
          fprintf(tile_file,"Fin_Poly (%s, ROSE, METALLIQUE, OPAQUE);\n",obj_name);
          vertex_face_close();
          break;
    case OFF :
          fprintf(out_file, "%d %d 1\n", koord_count, fac_count);
          vertex_face_close();
          break;
    case VRML :
          fprintf(out_file, "# %d vertices %d triangles\n\n", koord_count, fac_count);

          fprintf(vertex_file, "] }\n");
          fprintf(normal_file, "] }\n");
          fprintf(tile_file, "]\n");
          fprintf(normidx_file, "] }\n}\n");

          vertex_normal_face_close();
          break;
    case DXF :
          fprintf(out_file, "ENDSEC\n  0\nEOF\n");
          fclose(out_file);
          break;
    case STL :
          fprintf(out_file, "ENDSOLID\n");
          fclose(out_file);
          break;
    case AVS :
          fprintf(out_file, "%d\n", koord_count);
          vertex_face_close();
          break;
    default :
          fclose(out_file);
          break;
  }
  fprintf(stdout,"nb of triangles: %d\n",fac_count); /*XXXXX*/
  exit(0);
}


void read_points(PLANE *pl)
/********************************************************************/
/*   Read points of one cross section.                              */
/********************************************************************/
{
  float z;
  int i;
  int nb_pts;
  char s1[10], s2[10];

  fscanf( koord_file, "%s%d%s%f",s1, &nb_pts, s2, &z );
  if (nb_pts >= Maxvertex) {
    fprintf(stderr,"Vertex overflow (> %d) use option -max_vertex\n", Maxvertex);
    fflush(stderr);
    exit(1);
  }

  pl->start = koord_count;
  pl->z = z;
  for (i=0; i<nb_pts ; i++) {
    if( fscanf(koord_file,"%f",&((*(pl->point))[i][0])) == EOF) {
      fprintf(stderr,"error reading coords (EOF)\n");
      exit(1);
    }
    fscanf( koord_file, "%f", &((*(pl->point))[i][1]));

  }
  koord_count = koord_count + nb_pts;
  pl->stop = koord_count;
}


void read_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2)
/********************************************************************/
/* Read the triangles of one slice.                                 */
/********************************************************************/
{
  int j,i = 0;
  short delete1=0,delete2=0;
  int nb1, nb2;
  int type;
 
  if(pl1->z < pl2->z) direction = 1.0;
  else direction = -1.0;

  fscanf(fac_file,"%d%d%d",&fac->nb, &nb1, &nb2);
  if (fac->nb > Maxfacett) { /*XXXXX*/
    fprintf(stderr,"Triangle overflow (%d)   use option -max_facett\n",fac->nb);
    exit(2);
  }
  fac->nb0 = fac->nb01 = fac->nb1 = 0;
 
  for(i=0 ; i<n_remove; i++) {
    if ( plane_counter  ==  remove_h[i]) delete1 = 1;
    if ( plane_counter+1 ==  remove_h[i]) delete2 = 1;
  }

  for(i=0 ; i<fac->nb ; i++) {
    type = 0;
    fscanf(fac_file, "%d%d%d%f%f%f", &fac_buffer[0], &fac_buffer[1], &fac_buffer[2], 
                   &norm_buffer[0],&norm_buffer[1],&norm_buffer[2]);

    for (j=0 ; j<3; j++)  {
      (*(fac->fac))[i][j] = fac_buffer[j]-2; /* !!!! neu !!!! */
      type = type + ((fac_buffer[j]-2) & 0x1);
    }


    for (j=0 ; j<3; j++) 
      (*(fac->fnorm))[i][j] = norm_buffer[j];

    if( (remove_horizontal && (type == 0 || type == 3) ) ||
             (delete1 && (type == 0)) ||
             (delete2 && (type == 3) )
    ) {
      i--;
      fac->nb--;
      continue;
    }
    switch (type) {
      case 0: fac->nb0++; break;
      case 1:
      case 2: fac->nb01++; break;
      case 3: fac->nb1++; break;
    }

  }
}

void elim_double(FAC_SLICE *fac0, FAC_SLICE *fac1)
/********************************************************************/
/*  Eliminate the horizontal faces between slice0 and slice1        */
/*  which occur twice. The first point of such a triangle           */
/*  is set to -1, the first component of the normal to 100000.0     */
/********************************************************************/
{
 register int i,j,k;
 int old = 0;
  for (i=fac0->nb0 + fac0->nb01 ; i< fac0->nb ; i++)
    for (k=0, j=old ; k<fac1->nb0 ; k++, j=(j==fac1->nb0-1)?0:j+1)
      if((*(fac0->fac))[i][0] == ((*(fac1->fac))[j][0] | 0x1) &&
         (*(fac0->fac))[i][1] == ((*(fac1->fac))[j][1] | 0x1) &&
         (*(fac0->fac))[i][2] == ((*(fac1->fac))[j][2] | 0x1) ) {
        (*(fac0->fac))[i][0] = -1; 
        (*(fac0->fnorm))[i][0] = EXEPTION_VAL; 
        (*(fac1->fac))[j][0] = -1; 
        (*(fac1->fnorm))[j][0] = EXEPTION_VAL; 
        old = j+1;
        break;
      }
}

void norm_(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2)
/********************************************************************/
/*  calculate the average normals of points pl1                     */
/********************************************************************/
{
  int i,j,p, plane;
  PLANE *pl[2];
  int ncount;
  float zahl,norm0,norm1,norm2;
  SNODE *pn;
  double norm,v1[3],v2[3],winkel[3],winkelsumme;

  pl[0] = pl1;
  pl[1] = pl2;
  for (i=0; i<fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      for (j=0; j<3 ; j++) {
        plane = (*(fac->fac))[i][j] & 1;
        p = (*(fac->fac))[i][(j+1)%3] & 1;

        v1[0]=(*(pl[p]->point))[((*(fac->fac))[i][(j+1)%3]>>1)][0]-
                    (*(pl[plane]->point))[((*(fac->fac))[i][j]>>1)][0];
        v1[1]=(*(pl[p]->point))[((*(fac->fac))[i][(j+1)%3]>>1)][1]-
                    (*(pl[plane]->point))[((*(fac->fac))[i][j]>>1)][1];
        v1[2] = pl[p]->z - pl[plane]->z;
        p = (*(fac->fac))[i][(j+2)%3] & 1;
        v2[0]=(*(pl[p]->point))[((*(fac->fac))[i][(j+2)%3]>>1)][0]-
                    (*(pl[plane]->point))[((*(fac->fac))[i][j]>>1)][0];
        v2[1]=(*(pl[p]->point))[((*(fac->fac))[i][(j+2)%3]>>1)][1]-
                    (*(pl[plane]->point))[((*(fac->fac))[i][j]>>1)][1];
        v2[2] = pl[p]->z - pl[plane]->z;
        norm = sqrt((v1[0]*v1[0]+v1[1]*v1[1]+v1[2]*v1[2]) * 
                    (v2[0]*v2[0]+v2[1]*v2[1]+v2[2]*v2[2]));
        if(norm == 0.0) {
          (*(fac->fnorm))[i][0] = EXEPTION_VAL; 
          (*(fac->fac))[i][0] = -1;
          printf("triangle %d flat\n", i+1);
          break;
        }
        winkel[j] = (v1[0] * v2[0] + v1[1]*v2[1] + v1[2]*v2[2]) / norm;
        if (winkel[j] == 1.0 || winkel[j] == -1.0) {
          printf("triangle %d flat\n", i+1);
          (*(fac->fnorm))[i][0] = EXEPTION_VAL; 
          (*(fac->fac))[i][0] = -1;
          break;
        }
      }
    }
    if ( (*(fac->fac))[i][0] >= 0 ) {
      for (j=0; j<3 ; j++) {
        plane = (*(fac->fac))[i][j] & 1;
        pn = (SNODE *)pl[plane]->s_ptr;
        pn->fac = i;
        pn->base = fac->fnorm;
        pn->angle = acos((double)winkel[j])*180.0/M_PI;
        pn->next=(*(pl[plane]->simplist))[((*(fac->fac))[i][j]>>1)];
        (*(pl[plane]->simplist))[((*(fac->fac))[i][j]>>1)] = pn;
        pl[plane]->s_ptr = ((char *)pl[plane]->s_ptr+sizeof(SNODE));
      }
    }
  }

  for ( i=0 ; i< pl1->stop - pl1->start ; ++i ) {
    pn = (*(pl1->simplist))[i];
    ncount = 0;
    norm0 = 0.;
    norm1 = 0.;
    norm2 = 0.;
 
    winkelsumme = 0.0;
    if (no_weight) {
      while ( pn != NULL) {
        pn->angle = 1.0;
        if ((*(pn->base))[pn->fac][0] < EXEPTION_VAL)
          winkelsumme = winkelsumme + pn->angle;
        pn = pn->next;
      }
    }
    else {
      while ( pn != NULL) {
        if ((*(pn->base))[pn->fac][0] < EXEPTION_VAL)
          winkelsumme = winkelsumme + pn->angle;
        pn = pn->next;
      }
    }
    /*printf(" >>>> %f\n", winkelsumme);*/

    pn = (*(pl1->simplist))[i];

    /* calculate average normals in point i */
    while ( pn != NULL) {
      if ((*(pn->base))[pn->fac][0] < EXEPTION_VAL) {
        norm0 = norm0 + (*(pn->base))[pn->fac][0] * pn->angle/winkelsumme;
        norm1 = norm1 + (*(pn->base))[pn->fac][1] * pn->angle/winkelsumme;
        norm2 = norm2 + (*(pn->base))[pn->fac][2] * pn->angle/winkelsumme;
        ++ncount;
      }
      pn = pn->next;
    }
    if (ncount == 0)  ncount = 1;
    /*zahl = (float)ncount;*/
    zahl = sqrt(norm0*norm0 + norm1*norm1 + norm2*norm2);
    if (zahl == 0.0) zahl = 1.0;
    (*(pl1->pnorm))[i][0] = norm0/zahl;
    (*(pl1->pnorm))[i][1] = norm1/zahl;
    (*(pl1->pnorm))[i][2] = norm2/zahl;
  }
}

int equal(int a, int b, int simp1[][3], int simp2[][3])
/************************************************************************
 *returns 1 if triangle a and b are equal ,   else 0                    *
 * Use the fact that if tri are equal, their vertice are in same order  *
 ************************************************************************/

{
  if(simp1[a][0]-1 == simp2[b][0] &&
     simp1[a][1]-1 == simp2[b][1] &&
     simp1[a][2]-1 == simp2[b][2]){
    return(1);
  }
  else return(0);
}


void init(PLANE *pl)
/********************************************************************/
/* initialisation of pl->simplist                                   */
/********************************************************************/
{
  int i;
  for (i=0 ; i< pl->stop - pl->start ; i++)
    (*(pl->simplist))[i] = NULL;
  pl->s_ptr = (char *)pl->simplist + Maxvertex * sizeof(SNODE *);
}


void normal(int i, FAC_SLICE *fac, PLANE *pl[2])
/********************************************************************/
/*  Looks for the correct sens of the points of triangle i with     */
/*  respect to its normal                                           */
/********************************************************************/
{
  int j,h,plane;
  float p[3][3];
  float p1p2[3], p1p3[3];

  for (j=0; j<3 ; j++) {
    plane = (*(fac->fac))[i][j] & 1;
    p[j][0] = (float)(*(pl[plane]->point))[ (*(fac->fac))[i][j]>>1][0];
    p[j][1] = (float)(*(pl[plane]->point))[ (*(fac->fac))[i][j]>>1][1];
    p[j][2] = (float)pl[plane]->z;
  }
  p1p2[0] = p[1][0] - p[0][0];
  p1p2[1] = p[1][1] - p[0][1];
  p1p2[2] = p[1][2] - p[0][2];
 
  p1p3[0] = p[2][0] - p[0][0];
  p1p3[1] = p[2][1] - p[0][1];
  p1p3[2] = p[2][2] - p[0][2];
 
  if( (p1p2[1] * p1p3[2] - p1p2[2] * p1p3[1] ) * (*(fac->fnorm))[i][0] +
      (p1p2[2] * p1p3[0] - p1p2[0] * p1p3[2] ) * (*(fac->fnorm))[i][1] +
      (p1p2[0] * p1p3[1] - p1p2[1] * p1p3[0] ) * (*(fac->fnorm))[i][2] < 0.0) {
  h = (*(fac->fac))[i][0];
  (*(fac->fac))[i][0] = (*(fac->fac))[i][1];
  (*(fac->fac))[i][1] = h;
 }   
}



void memory_alloc(FAC_SLICE *fac0, FAC_SLICE *fac1, PLANE *pl0,
                             PLANE *pl1, PLANE *pl2, char **work_buffer)

{
  int point_size, pnorm_size, simplist_size, fac_size, fnorm_size;
  unsigned int wkb_size;

  point_size =    Maxvertex * 2 * sizeof(float); 
  pnorm_size =    Maxvertex * 3 * sizeof(float);
  fac_size =      Maxfacett * 3 * sizeof(int);
  fnorm_size =    Maxfacett * 3 * sizeof(float);
  simplist_size = Maxvertex*sizeof(SNODE *) + 3*Maxfacett*sizeof(SNODE);
  wkb_size =      3*point_size       /*                      */
                + 3*pnorm_size       /*   3 cross-sections   */
                + 3*simplist_size    /*                      */

                + 2*fac_size         /*   2 slices           */
                + 2*fnorm_size;

  /*memory allocation */
  *work_buffer = (char *)malloc( wkb_size); /* XXXXX */
  if (*work_buffer == NULL) {
    fprintf(stderr,"malloc failed: %d kb not available\n", wkb_size/1024);
    exit(1);
  }


  pl0->point = (KOORD *)(*work_buffer);
  pl0->pnorm = (POINTNORM *)((char *)pl0->point + point_size);
  pl0->simplist = (SLIST *) ((char *)pl0->pnorm + pnorm_size);

  pl1->point = (KOORD *)((char *)pl0->simplist + simplist_size);
  pl1->pnorm = (POINTNORM *)((char *)pl1->point + point_size);
  pl1->simplist = (SLIST *) ((char *)pl1->pnorm + pnorm_size);
  
  pl2->point = (KOORD *)((char *)pl1->simplist + simplist_size);
  pl2->pnorm = (POINTNORM *)((char *)pl2->point + point_size);
  pl2->simplist = (SLIST *) ((char *)pl2->pnorm + pnorm_size);


  fac0->fac = (FACETTE *)((char *)pl2->simplist + simplist_size);
  fac0->fnorm = (FACNORM *)((char *)fac0->fac + fac_size);
  fac1->fac = (FACETTE *)((char *)fac0->fnorm + fnorm_size);
  fac1->fnorm = (FACNORM *)((char *)fac1->fac + fac_size);

  if( (size_t)((char *)fac1->fnorm+fnorm_size)
                      -(size_t)(*work_buffer)>wkb_size ) {
    fprintf(stderr,"error memory alloc\n");
    exit(1);
  }
}

void norm_2(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2)
/********************************************************************/
/*calculate the av. normals of points pl1 without considering fac   */
/********************************************************************/
{
  int i;
  PLANE *pl[2];
  int ncount;
  float zahl,norm0,norm1,norm2;
  SNODE *pn;
  float winkelsumme;

  pl[0] = pl1;
  pl[1] = pl2;

  for ( i=0 ; i< pl1->stop - pl1->start ; ++i ) {
    pn = (*(pl1->simplist))[i];
    ncount = 0;
    norm0 = 0.;
    norm1 = 0.;
    norm2 = 0.;
 
    winkelsumme = 0.0;
    if (no_weight) {
      while ( pn != NULL) {
        pn->angle = 1.0;
        if ((*(pn->base))[pn->fac][0] < EXEPTION_VAL)
          winkelsumme = winkelsumme + pn->angle;
        pn = pn->next;
      }
    }
    else {
      while ( pn != NULL) {
        if ((*(pn->base))[pn->fac][0] < EXEPTION_VAL)
          winkelsumme = winkelsumme + pn->angle;
        pn = pn->next;
      }
    }
    /*printf(" >>>> %f\n", winkelsumme);*/

    pn = (*(pl1->simplist))[i];

    /* calculate average normals in point i */
    while ( pn != NULL) {
      if ((*(pn->base))[pn->fac][0] < EXEPTION_VAL) {
        norm0 = norm0 + (*(pn->base))[pn->fac][0] * pn->angle/winkelsumme;
        norm1 = norm1 + (*(pn->base))[pn->fac][1] * pn->angle/winkelsumme;
        norm2 = norm2 + (*(pn->base))[pn->fac][2] * pn->angle/winkelsumme;
        ++ncount;
      }
      pn = pn->next;
    }
    if (ncount == 0)  ncount = 1;
    /*zahl = (float)ncount;*/
    zahl = sqrt(norm0*norm0 + norm1*norm1 + norm2*norm2);
    if (zahl == 0.0) zahl = 1.0;
    (*(pl1->pnorm))[i][0] = norm0/zahl;
    (*(pl1->pnorm))[i][1] = norm1/zahl;
    (*(pl1->pnorm))[i][2] = norm2/zahl;
  }
  init(pl1);
}

void write_act_points(PLANE *pl, int m)
/********************************************************************/
/* write coords and gouraud-normals to act_file                     */
/*                                                                  */
/********************************************************************/
{
  int i;

  if (!mmult) {
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      fprintf( vertex_file , "Add_Point(%s, %.3f, %.3f, %.3f);\n", obj_name,
        (*(pl->point))[i][0], (*(pl->point))[i][1], pl->z);
      switch (m) {
        case ALL :
          fprintf( vertex_file,"Add_Vecteur(%s, %.3f, %.3f, %.3f);\n",obj_name,
             (*(pl->pnorm))[i][0], (*(pl->pnorm))[i][1], (*(pl->pnorm))[i][2]);
           break;
        case LOWER : /*first xsection*/
           fprintf( vertex_file , "Add_Vecteur(%s, 0.0 0.0 %.1f);\n",
                                                  obj_name, -direction);
           break;
        case UPPER : /*last xsection*/
           fprintf( vertex_file , "Add_Vecteur(%s, 0.0 0.0 %.1f);\n",
                                                  obj_name, direction);
           break;
      }
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      tmp1[0] = (*(pl->point))[i][0];
      tmp1[1] = (*(pl->point))[i][1];
      tmp1[2] = pl->z;
      MATRIX_MULT(tmp,matrix,tmp1);
      fprintf( vertex_file , "Add_Point(%s, %.3f, %.3f, %.3f);\n", obj_name,
        tmp[0],tmp[1],tmp[2]);
      switch (m) {
        case ALL :
          tmp1[0] = (*(pl->pnorm))[i][0];
          tmp1[1] = (*(pl->pnorm))[i][1];
          tmp1[2] = (*(pl->pnorm))[i][2];
          break;
        case LOWER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = -direction;
          break;
        case UPPER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = direction;
          break;
      }
      MATRIX_MULTV(tmp,matrix,tmp1);
      VEC_NORM(tmp);
      fprintf( vertex_file , "Add_Vecteur(%s, %.3f, %.3f, %.3f);\n", obj_name,
        tmp[0],tmp[1],tmp[2]);
    }
  }
}

void write_act_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m)
/********************************************************************/
/* write triangles and gouraud-normals to act_file                  */
/*                                                                  */
/********************************************************************/
{
  int i,j,p;
  int offset[2];
  PLANE *pl[2];
  int p0,p1,p2;

  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;
  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
        normal(i,fac,pl);
        fprintf( tile_file , "Add_Face(%s, 3",obj_name);
        for (j=0; j<3 ; j++) {
          p =  (*(fac->fac))[i][j] & 1;
          fprintf(tile_file, ", %d, %d",((*(fac->fac))[i][j]>>1)+offset[p],
                                       ((*(fac->fac))[i][j]>>1)+offset[p]);
        }
        fprintf( tile_file , ");\n");
        fac_count++;
      }
    }
  }
}

void Usage(void)
{
  fprintf(stderr,"Usage: repros2visu <triangles> <points> <output> [-iv] [-vrml] [-obj] [-off]  [-dxf] [-act] [-idx] [-vera] [-h] [-r <nb>]");
  fprintf(stderr," [-n <nb>] [-o <obj_name>] [-t <string>]");
  fprintf(stderr," [-max_facett <nb>] [-max_vertex <nb>] \n");
  fprintf(stderr,"-vrml   write output in VRML format\n");
  fprintf(stderr,"-iv     write output in inventor format\n");
  fprintf(stderr,"-obj    write output in wavefront object format (default)\n");
  fprintf(stderr,"-off    write output in OFF format\n");
  fprintf(stderr,"-avs    write output in AVS format (polyh)\n");
  fprintf(stderr,"-dxf    write output in DXF format\n");
  fprintf(stderr,"-stl    write output in STL format\n");
  fprintf(stderr,"-act    write output in act format\n");
  fprintf(stderr,"-idx    write output in index format\n");
  fprintf(stderr,"-vera   write output in vera raytrace format\n");
  fprintf(stderr,"-h      remove all horizontal triangles \n");
  fprintf(stderr,"-r <nb> remove horizontal triangles in X-section number <nb>\n");
  fprintf(stderr,"-n <nb> do not interpolate normals at X-section number <nb>\n");
  fprintf(stderr,"-o <obj_name> group name for obj format or object name for act format\n");
  fprintf(stderr,"-t <string>      insert <string> as first line in file <output>\n");
  fprintf(stderr,"-max_facett <nb> max nb of triangles per slice \n");
  fprintf(stderr,"-max_vertex <nb> max nb of vertices per section \n");
  exit(1);
}

void write_vera_facettes(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1, int m)
/********************************************************************/
/* write triangles and gouraud-normals to out_file                  */
/* only write lower horizontal (m=0) or upper horizontal (m=1) faces*/
/********************************************************************/
{
  int i,j,p,p0,p1,p2;
  PLANE *pl[2];

  pl[0] = pl0;
  pl[1] = pl1;
  if (!mmult) {
    for (i=0 ; i< fac->nb ; i++) {
      if ( (*(fac->fac))[i][0] >= 0 ) {
        p0 = (*(fac->fac))[i][0] & 1;
        p1 = (*(fac->fac))[i][1] & 1;
        p2 = (*(fac->fac))[i][2] & 1;
        if ((m== ALL) || (p0 == m && p1 == m && p2 == m)) {
          fprintf( out_file , "PA\n");     /*XXXXX*/
          normal(i,fac,pl);
          for (j=0; j<3 ; j++) {
            p =  (*(fac->fac))[i][j] & 1;
            fprintf(out_file, "%.2f %.2f %.2f\n",      /*XXXXX*/
            (*(pl[p]->point))[ ((*(fac->fac))[i][j]>>1)][0],
            (*(pl[p]->point))[ ((*(fac->fac))[i][j]>>1)][1], 
            pl[p]->z );
          }
          for (j=0; j<3 ; j++) {
            p =  (*(fac->fac))[i][j] & 1;
            fprintf(out_file, " %.3f %.3f %.3f",      /*XXXXX*/
            (*(fac->fnorm))[i][0], (*(fac->fnorm))[i][1], (*(fac->fnorm))[i][2] );
          }
          fprintf( out_file , "\n");     /*XXXXX*/
          fac_count++;
        }
      }
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< fac->nb ; i++) {
      if ( (*(fac->fac))[i][0] >= 0 ) {
        p0 = (*(fac->fac))[i][0] & 1;
        p1=  (*(fac->fac))[i][1] & 1;
        p2 = (*(fac->fac))[i][2] & 1;
        if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
          fprintf( out_file , "PA  ");     /*XXXXX*/
          normal(i,fac,pl);
          for (j=0; j<3 ; j++) {
            p =  (*(fac->fac))[i][j] & 1;
            tmp1[0] = (*(pl[p]->point))[ ((*(fac->fac))[i][j]>>1)][0];
            tmp1[1] = (*(pl[p]->point))[ ((*(fac->fac))[i][j]>>1)][1];
            tmp1[2] = pl[p]->z;
            MATRIX_MULT(tmp,matrix,tmp1);
            fprintf(out_file, "%.2f %.2f %.2f\n    ",      /*XXXXX*/
              tmp[0],tmp[1],tmp[2]);
          }
          for (j=0; j<3 ; j++) {
            p =  (*(fac->fac))[i][j] & 1;
            tmp1[0] = (*(pl[p]->pnorm))[ ((*(fac->fac))[i][j]>>1)][0];
            tmp1[1] = (*(pl[p]->pnorm))[ ((*(fac->fac))[i][j]>>1)][1];
            tmp1[2] = (*(pl[p]->pnorm))[ ((*(fac->fac))[i][j]>>1)][2];
            MATRIX_MULTV(tmp,matrix,tmp1);
            VEC_NORM(tmp);
            fprintf(out_file, " %.3f %.3f %.3f",      /*XXXXX*/
              tmp[0],tmp[1],tmp[2]);
          }
          fprintf( out_file , "\n");     /*XXXXX*/
          fac_count++;
        }
      }
    }
  }
}

void grab_arguments(int argc, char **argv)
{
  int i;

  if (argc < 4)  Usage();
  fnam[0] = argv[1];
  fnam[1] = argv[2];
  fnam[2] = argv[3];

  for (i = 4; i < argc; i++) {
    if (strcmp(argv[i], "-h") == 0) {
      remove_horizontal = TRUE;
      continue;
    }
    if (strcmp(argv[i], "-n") == 0) {
      if (++i >= argc) Usage();
        nosmooth[n_nosmooth++] = atoi(argv[i]);
        continue;
    }
    if (strcmp(argv[i], "-matrix") == 0) {
      mmult = TRUE;
      if (++i >= argc) Usage();
        read_matrix(argv[i]);
        continue;
    }
    if (strcmp(argv[i], "-r") == 0) {
      if (++i >= argc) Usage();
        remove_h[n_remove++] = atoi(argv[i]);
        continue;
    }
    if (strcmp(argv[i], "-act") == 0) {
      out_format = ACT;
      continue;
    }
    if (strcmp(argv[i], "-idx") == 0) {
        out_format = IDX;
        continue;
    }
    if (strcmp(argv[i], "-vera") == 0) {
      out_format = VERA;
      continue;
    }
    if (strcmp(argv[i], "-off") == 0) {
      out_format = OFF;
      continue;
    }
    if (strcmp(argv[i], "-avs") == 0) {
      out_format = AVS;
      continue;
    }
    if (strcmp(argv[i], "-dxf") == 0) {
      out_format = DXF;
      continue;
    }
    if (strcmp(argv[i], "-stl") == 0) {
      out_format = STL;
      continue;
    }
    if (strcmp(argv[i], "-obj") == 0) {
      out_format = OBJ;
      continue;
    }
    if (strcmp(argv[i], "-vrml") == 0) {
      out_format = VRML;
      continue;
    }
    if (strcmp(argv[i], "-iv") == 0) {
      out_format = INV;
      continue;
    }
    if (strcmp(argv[i], "-offset") == 0) {
      if (++i >= argc) Usage();
        obj_offset = atoi(argv[i]);
        continue;
    }
    if (strcmp(argv[i], "-max_vertex") == 0) {
      if (++i >= argc) Usage();
        Maxvertex = atoi(argv[i]);
        mv_changed = TRUE;
        continue;
    }
    if (strcmp(argv[i], "-max_facett") == 0) {
      if (++i >= argc) Usage();
        Maxfacett = atoi(argv[i]);
        mf_changed = TRUE;
        continue;
    }
    if (strcmp(argv[i], "-no_weight") == 0) {
        no_weight = TRUE;
        continue;
    }
    if (strcmp(argv[i], "-o") == 0) {
      if (++i >= argc) Usage();
        obj_name = argv[i];
        continue;
    }
    if (strcmp(argv[i], "-t") == 0) {
      if (++i >= argc) Usage();
        header = argv[i];
        continue;
    }
    if (strcmp(argv[i], "-help") == 0) {
      Usage();
    }
    Usage();
  }
}

void write_index_facettes(FAC_SLICE *fac, PLANE *pl1,
                                PLANE *pl2, int m, int *n, int nb)
/********************************************************************/
/* write triangles and gouraud-normals to index_file                */
/*                                                                  */
/********************************************************************/
{
  int i,j,p;
  int offset[2];
  int count = 0;
  PLANE *pl[2];
  int p0,p1,p2;
 
  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;

  for (i=0 ; i< fac->nb ; i++)
    if ( (*(fac->fac))[i][0] >= 0 )
      count++;
  if ( idx_count != 0 ) { /*print lower hor. tiles */
    write_saved_facettes(count + idx_count);
    *n = 0;
  }

  if (*n == 1) fprintf( out_file, "T %d\n", nb);
  else {
    *n = 1;
  }
  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
        normal(i,fac,pl);
        for (j=0; j<3 ; j++) {
          p =  (*(fac->fac))[i][j] & 1;
          fprintf(out_file, " %d", ((*(fac->fac))[i][j]>>1)+offset[p]);
        }
        fprintf( out_file , "\n");
        fac_count++;
      }
    }
  }
}

void write_index_points(PLANE *pl, int m, int n)
/********************************************************************/
/* write coords and gouraud-normals to index_file                   */
/*  duplicates the vertices				            */
/********************************************************************/
{
  int i;

  switch (n) {
    case 0:
      fprintf( out_file, "V %d  z  %.3f\n", 2*(pl->stop - pl->start), pl->z );
      break;
    case 1:
      fprintf( out_file, "V %d  z  %.3f\n", pl->stop - pl->start, pl->z );
      break;
  }
  for (i=0 ; i< pl->stop - pl->start ; i++) {
    fprintf( out_file , "%.3f %.3f ",
      (*(pl->point))[i][0], (*(pl->point))[i][1]);
    switch (m) {
      case ALL :
        fprintf( out_file , "%.3f %.3f %.3f\n",
          (*(pl->pnorm))[i][0], (*(pl->pnorm))[i][1], (*(pl->pnorm))[i][2]);
        break;
      case LOWER : /*first xsection*/
        fprintf( out_file , " 0.0 0.0 %.1f\n", -direction);
        break;
      case UPPER : /*last xsection*/
        fprintf( out_file , " 0.0 0.0 %.1f\n", direction);
        break;
    }
  }
}

void eliminate_horizontal(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1, int m)
/********************************************************************/
/* eliminate lower horizontal (m=0) or upper horizontal (m=1) faces*/
/********************************************************************/
{
  int i,p0,p1,p2;
  PLANE *pl[2];

  pl[0] = pl0;
  pl[1] = pl1;
  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if (p0 == m && p1 == m && p2 == m) {
        (*(fac->fac))[i][0] = -1;
        (*(fac->fnorm))[i][0] = EXEPTION_VAL; 
      }
    }
  }
}

void write_obj_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m)
/********************************************************************/
/* write triangles and gouraud-normals to index_file                */
/*                                                                  */
/********************************************************************/
{
  int i,j,p;
  int offset[2];
  int count = 0;
  PLANE *pl[2];
  int p0,p1,p2;
 
  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;
  if ( fac->nb == 0 ) return;

  for (i=0 ; i< fac->nb ; i++)
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
      count++;
    }
  }

  fprintf( out_file, "#%d triangles\n", count);
  fprintf( out_file, "s 1\n");
  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
        normal(i,fac,pl);
        fprintf( out_file , "f");
        for (j=0; j<3 ; j++) {
          p =  (*(fac->fac))[i][j] & 1;
          fprintf(out_file, " %d//%d", 
            ((*(fac->fac))[i][j]>>1)+offset[p]+1 + obj_offset,
            ((*(fac->fac))[i][j]>>1)+offset[p]+1 + obj_offset);
        }
        fprintf( out_file , "\n");
        fac_count++;
      }
    }
  }
}

void write_obj_points(PLANE *pl, int m)
/********************************************************************/
/* write coords and gouraud-normals to index_file                   */
/* m=Upper/LOWER/ALL                                                */
/********************************************************************/
{
  int i;

  fprintf( out_file, "# %d vertices  z= %f\n", pl->stop - pl->start, pl->z );

  if (!mmult) {
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      fprintf( out_file , "v %.3f %.3f %.3f\n",
        (*(pl->point))[i][0], (*(pl->point))[i][1], pl->z);
      switch (m) {
        case ALL :
          fprintf( out_file , "vn %.3f %.3f %.3f\n",
          (*(pl->pnorm))[i][0], (*(pl->pnorm))[i][1], (*(pl->pnorm))[i][2]);
          break;
        case LOWER : /*first xsection*/
           fprintf( out_file , "vn 0.0 0.0 %.1f\n", -direction);
           break;
        case UPPER : /*last xsection*/
           fprintf( out_file , "vn 0.0 0.0 %.1f\n", direction);
           break;
      }
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      tmp1[0] = (*(pl->point))[i][0];
      tmp1[1] = (*(pl->point))[i][1];
      tmp1[2] = pl->z;
      MATRIX_MULT(tmp,matrix,tmp1);
      fprintf( out_file , "v %.3f %.3f %.3f\n", tmp[0],tmp[1],tmp[2]);
      switch (m) {
        case ALL :
          tmp1[0] = (*(pl->pnorm))[i][0];
          tmp1[1] = (*(pl->pnorm))[i][1];
          tmp1[2] = (*(pl->pnorm))[i][2];
          break;
        case LOWER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = -direction;
          break;
        case UPPER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = direction;
          break;
      }
      MATRIX_MULTV(tmp,matrix,tmp1);
      VEC_NORM(tmp);
      fprintf( out_file , "vn %.3f %.3f %.3f\n", tmp[0],tmp[1],tmp[2]);
    }
  }
}

void vertex_face_open(void)
{

  vertex_file_name = (char *)malloc( strlen(fnam[2]) + 20);
  if (vertex_file_name == NULL) {
    perror("malloc");
    exit(1);
  }
  tile_file_name = (char *)malloc( strlen(fnam[2]) + 20);
  if (tile_file_name == NULL) {
    perror("malloc");
    exit(1);
  }

  strcpy(vertex_file_name,fnam[2]);
  strcat(vertex_file_name,"_vertices");
  vertex_file = fopen(vertex_file_name, "w");
  if (vertex_file == NULL) {
    perror("fopen");
    exit(1);
  }
  strcpy(tile_file_name,fnam[2]);
  strcat(tile_file_name,"_faces");
  tile_file = fopen(tile_file_name, "w");
  if (tile_file == NULL) {
    perror("fopen");
    exit(1);
  }
}

void vertex_normal_face_open(void)
{
  vertex_face_open();

  normal_file_name = (char *)malloc( strlen(fnam[2]) + 20);
  if (normal_file_name == NULL) {
    perror("malloc");
    exit(1);
  }
  normidx_file_name = (char *)malloc( strlen(fnam[2]) + 20);
  if (normidx_file_name == NULL) {
    perror("malloc");
    exit(1);
  }
  strcpy(normal_file_name,fnam[2]);
  strcat(normal_file_name,"_normals");
  normal_file = fopen(normal_file_name, "w");
  if (normal_file == NULL) {
    perror("fopen");
    exit(1);
  }
  strcpy(normidx_file_name,fnam[2]);
  strcat(normidx_file_name,"_normidx");
  normidx_file = fopen(normidx_file_name, "w");
  if (normidx_file == NULL) {
    perror("fopen");
    exit(1);
  }
}

void delete_file(char *fname)
{
#ifndef VMS_NUAGES
  if ( unlink(fname) == -1) {
    perror("unlink") ;
    exit(1);
  }
#else
  remove (fname);
#endif
}

void vertex_face_close(void)
{
  char command[512];
  fclose(out_file);
  fclose(tile_file);
  fclose(vertex_file);

  sprintf(command, "cat %s >> %s\n", vertex_file_name, fnam[2]);
  system(command);
  delete_file(vertex_file_name);

  sprintf(command, "cat %s >> %s\n", tile_file_name, fnam[2]);
  system(command);
  delete_file(tile_file_name);
}


void vertex_normal_face_close(void)
{
  char command[512];
  fclose(out_file);
  fclose(tile_file);
  fclose(vertex_file);
  fclose(normal_file);
  fclose(normidx_file);

  sprintf(command, "cat %s >> %s\n", vertex_file_name, fnam[2]);
  system(command);
  delete_file(vertex_file_name);

  sprintf(command, "cat %s >> %s\n", normal_file_name, fnam[2]);
  system(command);
  delete_file(normal_file_name);

  sprintf(command, "cat %s >> %s\n", tile_file_name, fnam[2]);
  system(command);
  delete_file(tile_file_name);

  sprintf(command, "cat %s >> %s\n", normidx_file_name, fnam[2]);
  system(command);
  delete_file(normidx_file_name);
}


void write_dxf_facettes(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1)
/********************************************************************/
/* write triangles  to out_file                  */
/*                                                                  */
/********************************************************************/
{
  int i, p;
  PLANE *pl[2];
 
  pl[0] = pl0;
  pl[1] = pl1;
  if (!mmult) {
    for (i=0 ; i< fac->nb ; i++) {
      if ( (*(fac->fac))[i][0] >= 0 ) {
        fprintf( out_file , "3DFACE\n  8\n%s\n",obj_name);     /*XXXXX*/

        normal(i,fac,pl);
 
        p =  (*(fac->fac))[i][0] & 1;
        fprintf(out_file, " 10\n%.2f\n 20\n%.2f\n 30\n%.2f\n",
                   (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][0],
                   (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][1], 
                   pl[p]->z );
        p =  (*(fac->fac))[i][1] & 1;
        fprintf(out_file, " 11\n%.2f\n 21\n%.2f\n 31\n%.2f\n",
                   (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][0],
                   (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][1], 
                   pl[p]->z );
        p =  (*(fac->fac))[i][2] & 1;
        fprintf(out_file, " 12\n%.2f\n 22\n%.2f\n 32\n%.2f\n",
                   (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][0],
                   (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][1], 
                   pl[p]->z );
        fprintf(out_file, " 13\n%.2f\n 23\n%.2f\n 33\n%.2f\n  0\n",
                   (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][0],
                   (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][1], 
                   pl[p]->z );
        fac_count++;
      }
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< fac->nb ; i++) {
      if ( (*(fac->fac))[i][0] >= 0 ) {
        fprintf( out_file , "3DFACE\n  8\n%s\n",obj_name);     /*XXXXX*/
        normal(i,fac,pl);
        p =  (*(fac->fac))[i][0] & 1;
        tmp1[0] = (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][0];
        tmp1[1] = (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][1];
        tmp1[2] = pl[p]->z;
        MATRIX_MULT(tmp,matrix,tmp1);

        fprintf(out_file, " 10\n%.2f\n 20\n%.2f\n 30\n%.2f\n",
           tmp[0],tmp[1],tmp[2]);
        p =  (*(fac->fac))[i][1] & 1;
        tmp1[0] = (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][0];
        tmp1[1] = (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][1];
        tmp1[2] = pl[p]->z;
        MATRIX_MULT(tmp,matrix,tmp1);
        fprintf(out_file, " 11\n%.2f\n 21\n%.2f\n 31\n%.2f\n",
           tmp[0],tmp[1],tmp[2]);
        p =  (*(fac->fac))[i][2] & 1;
        tmp1[0] = (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][0];
        tmp1[1] = (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][1];
        tmp1[2] = pl[p]->z;
        MATRIX_MULT(tmp,matrix,tmp1);
        fprintf(out_file, " 12\n%.2f\n 22\n%.2f\n 32\n%.2f\n",
           tmp[0],tmp[1],tmp[2]);
        fprintf(out_file, " 13\n%.2f\n 23\n%.2f\n 33\n%.2f\n  0\n",
           tmp[0],tmp[1],tmp[2]);
        fac_count++;
      }
    }
  }
}

void read_matrix(char *fn)
{
  int i,j;
  FILE *matrix_file;

  matrix_file = fopen(fn, "r");
  if (matrix_file == NULL) {
    perror("fopen");
    exit(1);
  }
  for (i=0 ; i<4 ; i++)
    for (j=0 ; j<4 ; j++)
      fscanf(matrix_file, "%f", &(matrix[i][j]));

  fclose(matrix_file);
}

void write_avs_points(PLANE *pl, int m)
/********************************************************************/
/* write coords and gouraud-normals to out_file                     */
/*                                                                  */
/********************************************************************/
{
  int i;

  if (!mmult) {
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      fprintf( vertex_file , "%.3f %.3f %.3f\n",
        (*(pl->point))[i][0], (*(pl->point))[i][1], pl->z);
      /*fprintf( vertex_file , " %.3f %.3f %.3f\n",
        (*(pl->pnorm))[i][0], (*(pl->pnorm))[i][1], (*(pl->pnorm))[i][2]);
      */
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      tmp1[0] = (*(pl->point))[i][0];
      tmp1[1] = (*(pl->point))[i][1];
      tmp1[2] = pl->z;
      MATRIX_MULT(tmp,matrix,tmp1);
      fprintf( vertex_file , "O6 %.3f %.3f %.3f", tmp[0],tmp[1],tmp[2]);
      /*
      tmp1[0] = (*(pl->pnorm))[i][0];
      tmp1[1] = (*(pl->pnorm))[i][1];
      tmp1[2] = (*(pl->pnorm))[i][2];
      MATRIX_MULTV(tmp,matrix,tmp1);
      VEC_NORM(tmp);
      fprintf( vertex_file , " %.3f %.3f %.3f\n", tmp[0],tmp[1],tmp[2]);
      */
    }
  }
}

void write_avs_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m)
/********************************************************************/
/* write triangles and gouraud-normals to index_file                */
/*                                                                  */
/********************************************************************/
{
  int i,j,p;
  int offset[2];
  int count = 0;
  PLANE *pl[2];
  int p0,p1,p2;
 
  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;
  if ( fac->nb == 0 ) return;
/*
  for (i=0 ; i< fac->nb ; i++)
    if ( (*(fac->fac))[i][0] >= 0 )
      count++;
*/
  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
        normal(i,fac,pl);
        fprintf( tile_file , "3\n");
        for (j=0; j<3 ; j++) {
          p =  (*(fac->fac))[i][j] & 1;
          fprintf(tile_file, " %d", ((*(fac->fac))[i][j]>>1)+offset[p]+1);
        }
        fprintf( tile_file , "\n");
        fac_count++;
      }
    }
  }
}

void write_off_points(PLANE *pl, int m)
/********************************************************************/
/* write coords and gouraud-normals to off_file                     */
/* duplicate points                                                 */
/********************************************************************/
{
  int i;

  if (!mmult) {
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      fprintf( vertex_file , "%.3f %.3f %.3f",
        (*(pl->point))[i][0], (*(pl->point))[i][1], pl->z);
      switch (m) {
        case ALL :
           fprintf( vertex_file , " %.3f %.3f %.3f\n",
             (*(pl->pnorm))[i][0], (*(pl->pnorm))[i][1], (*(pl->pnorm))[i][2]);
           break;
        case LOWER : /*first xsection*/
           fprintf( vertex_file , " 0.0 0.0 %.1f\n", -direction);
           break;
        case UPPER : /*last xsection*/
           fprintf( vertex_file , " 0.0 0.0 %.1f\n", direction);
           break;
      }
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      tmp1[0] = (*(pl->point))[i][0];
      tmp1[1] = (*(pl->point))[i][1];
      tmp1[2] = pl->z;
      MATRIX_MULT(tmp,matrix,tmp1);
      fprintf( vertex_file , "%.3f %.3f %.3f", tmp[0],tmp[1],tmp[2]);
      switch (m) {
        case ALL :
          tmp1[0] = (*(pl->pnorm))[i][0];
          tmp1[1] = (*(pl->pnorm))[i][1];
          tmp1[2] = (*(pl->pnorm))[i][2];
          break;
        case LOWER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = -direction;
          break;
        case UPPER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = direction;
          break;
      }
      MATRIX_MULTV(tmp,matrix,tmp1);
      VEC_NORM(tmp);
      fprintf( vertex_file , " %.3f %.3f %.3f\n", tmp[0],tmp[1],tmp[2]);
    }
  }
}

void write_off_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m)
/****************************************************************/
/* write triangles and gouraud-normals to off_file		*/
/********************************************************************/
{
  int i,j,p;
  int offset[2];
  PLANE *pl[2];
  int p0,p1,p2;
 
  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;
  if ( fac->nb == 0 ) return;
  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
        normal(i,fac,pl);
        fprintf( tile_file , "3");
        for (j=0; j<3 ; j++) {
          p =  (*(fac->fac))[i][j] & 1;
          fprintf(tile_file, " %d", ((*(fac->fac))[i][j]>>1)+offset[p]);
        }
        fprintf( tile_file , "\n");
        fac_count++;
      }
    }
  }
}

void
shift_indices(PLANE *pl1,PLANE *pl2, int m)
{
  int num;
  num = pl1->stop - pl1->start;
  if (m==0) {
    pl1->start = pl1->start  + num;
    pl2->start = pl2->start  + num;
    pl1->stop = pl1->stop  + num;
    pl2->stop = pl2->stop  + num;
    koord_count = koord_count + num;
  }
  else {
    pl1->start = pl1->start  - num;
    pl2->start = pl2->start  - num;
    pl1->stop = pl1->stop  - num;
    pl2->stop = pl2->stop  - num;
    koord_count = koord_count - num;
  }
}

int
calc_index_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m)
{
  int i;
  int offset[2];
  int count = 0;
  PLANE *pl[2];
 
  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;
  for (i=0 ; i< fac->nb ; i++)
    if ( (*(fac->fac))[i][0] >= 0 )
      count++;
  return( count);
}

void save_index_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m)
{
  int i;
  int offset[2];
  int count = 0;
  PLANE *pl[2];
  int p0,p1,p2;
 
  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;

  switch (m) {
  case LOWER:
  case UPPER:
    for (i=0 ; i< fac->nb ; i++) {
      if ( (*(fac->fac))[i][0] >= 0 ) {
        p0 = (*(fac->fac))[i][0] & 1;
        p1=  (*(fac->fac))[i][1] & 1;
        p2 = (*(fac->fac))[i][2] & 1;
        if (p0 == m && p1 == m && p2 == m) 
          count++;
      }
    }
    break;
  }

  idx_fac_buffer = (int *)malloc(3*count*sizeof(int));
  if (idx_fac_buffer == NULL) {
    perror("malloc");
    exit(1);
  }
  idx_count = count;
  count = 0;
  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ( (p0 == m && p1 == m && p2 == m)) {
        normal(i,fac,pl);
        *(idx_fac_buffer + 3*count  ) = ((*(fac->fac))[i][0]>>1)+offset[p0];
        *(idx_fac_buffer + 3*count+1) = ((*(fac->fac))[i][1]>>1)+offset[p1];
        *(idx_fac_buffer + 3*count+2) = ((*(fac->fac))[i][2]>>1)+offset[p2];
        count++;
      }
    }
  }
}

void write_saved_facettes(int nb)
{
  int i;
  fprintf( out_file, "T %d\n", nb);
  for (i=0 ; i< idx_count ; i++) {
    fprintf(out_file, "%d %d %d\n",
               *(idx_fac_buffer + 3*i  ),
               *(idx_fac_buffer + 3*i+1),
               *(idx_fac_buffer + 3*i+2) );
    fac_count++;
  }
  free( (char *)idx_fac_buffer);
  idx_count = 0;
}

void write_vrml_facettes(FAC_SLICE *fac, PLANE *pl1, PLANE *pl2, int m)
/********************************************************************/
/*                                                                  */
/********************************************************************/
{
  int i,j,p;
  int offset[2];
  int count = 0;
  PLANE *pl[2];
  int p0,p1,p2;
 
  pl[0] = pl1;
  pl[1] = pl2;

  offset[0] = pl1->start;
  offset[1] = pl2->start;
  if ( fac->nb == 0 ) return;

  for (i=0 ; i< fac->nb ; i++)
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
      count++;
    }
  }

  for (i=0 ; i< fac->nb ; i++) {
    if ( (*(fac->fac))[i][0] >= 0 ) {
      p0 = (*(fac->fac))[i][0] & 1;
      p1=  (*(fac->fac))[i][1] & 1;
      p2 = (*(fac->fac))[i][2] & 1;
      if ((m == ALL) || (p0 == m && p1 == m && p2 == m)) {
        normal(i,fac,pl);
        fprintf( tile_file , " ");
        fprintf( normidx_file , " ");
        for (j=0; j<3 ; j++) {
          p =  (*(fac->fac))[i][j] & 1;
          fprintf(tile_file, " %d,", 
            ((*(fac->fac))[i][j]>>1)+offset[p] + obj_offset);
          fprintf(normidx_file, " %d,", 
            ((*(fac->fac))[i][j]>>1)+offset[p] + obj_offset);
        }
        fprintf( tile_file , "-1,\n");
        fprintf( normidx_file , "-1,\n");
        fac_count++;
      }
    }
  }
}

void write_vrml_points(PLANE *pl, int m)
/********************************************************************/
/* write coords and gouraud-normals to index_file                   */
/* m=Upper/LOWER/ALL                                                */
/********************************************************************/
{
  int i;

  if (!mmult) {
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      fprintf( vertex_file , "%.3f %.3f %.3f,\n",
        (*(pl->point))[i][0], (*(pl->point))[i][1], pl->z);
      switch (m) {
        case ALL :
          fprintf( normal_file , "%.3f %.3f %.3f,\n",
          (*(pl->pnorm))[i][0], (*(pl->pnorm))[i][1], (*(pl->pnorm))[i][2]);
          break;
        case LOWER : /*first xsection*/
           fprintf( normal_file , "0.0 0.0 %.1f,\n", -direction);
           break;
        case UPPER : /*last xsection*/
           fprintf( normal_file , "0.0 0.0 %.1f,\n", direction);
           break;
      }
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< pl->stop - pl->start ; i++) {
      tmp1[0] = (*(pl->point))[i][0];
      tmp1[1] = (*(pl->point))[i][1];
      tmp1[2] = pl->z;
      MATRIX_MULT(tmp,matrix,tmp1);
      fprintf( vertex_file , "%.3f %.3f %.3f,\n", tmp[0],tmp[1],tmp[2]);
      switch (m) {
        case ALL :
          tmp1[0] = (*(pl->pnorm))[i][0];
          tmp1[1] = (*(pl->pnorm))[i][1];
          tmp1[2] = (*(pl->pnorm))[i][2];
          break;
        case LOWER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = -direction;
          break;
        case UPPER :
          tmp1[0] = tmp1[1] = 0.0;
          tmp1[2] = direction;
          break;
      }
      MATRIX_MULTV(tmp,matrix,tmp1);
      VEC_NORM(tmp);
      fprintf( normal_file , "%.3f %.3f %.3f,\n", tmp[0],tmp[1],tmp[2]);
    }
  }
}

void write_stl_facettes(FAC_SLICE *fac, PLANE *pl0, PLANE *pl1)
/********************************************************************/
/* write triangles  to out_file                  */
/*                                                                  */
/********************************************************************/
{
  int i, p;
  PLANE *pl[2];
 
  pl[0] = pl0;
  pl[1] = pl1;
  if (!mmult) {
    for (i=0 ; i< fac->nb ; i++) {
      if ( (*(fac->fac))[i][0] >= 0 ) {

        normal(i,fac,pl);
 
        fprintf(out_file, "  FACET NORMAL %e %e %e\n",
          (*(fac->fnorm))[i][0], (*(fac->fnorm))[i][1], (*(fac->fnorm))[i][2]);
        fprintf( out_file , "    OUTER LOOP\n");     /*XXXXX*/

        p =  (*(fac->fac))[i][0] & 1;
        fprintf(out_file, "      VERTEX   %e %e %e\n",
                   (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][0],
                   (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][1], 
                   pl[p]->z );
        p =  (*(fac->fac))[i][1] & 1;
        fprintf(out_file, "      VERTEX   %e %e %e\n",
                   (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][0],
                   (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][1], 
                   pl[p]->z );
        p =  (*(fac->fac))[i][2] & 1;
        fprintf(out_file, "      VERTEX   %e %e %e\n",
                   (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][0],
                   (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][1], 
                   pl[p]->z );
        fac_count++;
        fprintf( out_file , "    ENDLOOP\n");     /*XXXXX*/
        fprintf( out_file , "  ENDFACET\n");     /*XXXXX*/
      }
    }
  }
  else {
    float tmp[3], tmp1[3];
    for (i=0 ; i< fac->nb ; i++) {
      if ( (*(fac->fac))[i][0] >= 0 ) {
        fprintf(out_file, "  FACET NORMAL %e %e %e\n",
          (*(fac->fnorm))[i][0], (*(fac->fnorm))[i][1], (*(fac->fnorm))[i][2]);
        fprintf( out_file , "    OUTER LOOP\n");     /*XXXXX*/
        normal(i,fac,pl);
        p =  (*(fac->fac))[i][0] & 1;
        tmp1[0] = (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][0];
        tmp1[1] = (*(pl[p]->point))[ ((*(fac->fac))[i][0]>>1)][1];
        tmp1[2] = pl[p]->z;
        MATRIX_MULT(tmp,matrix,tmp1);

        fprintf(out_file, "      VERTEX   %e %e %e\n",
           tmp[0],tmp[1],tmp[2]);
        p =  (*(fac->fac))[i][1] & 1;
        tmp1[0] = (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][0];
        tmp1[1] = (*(pl[p]->point))[ ((*(fac->fac))[i][1]>>1)][1];
        tmp1[2] = pl[p]->z;
        MATRIX_MULT(tmp,matrix,tmp1);
        fprintf(out_file, "      VERTEX   %e %e %e\n",
           tmp[0],tmp[1],tmp[2]);
        p =  (*(fac->fac))[i][2] & 1;
        tmp1[0] = (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][0];
        tmp1[1] = (*(pl[p]->point))[ ((*(fac->fac))[i][2]>>1)][1];
        tmp1[2] = pl[p]->z;
        MATRIX_MULT(tmp,matrix,tmp1);
        fprintf(out_file, "      VERTEX   %e %e %e\n",
           tmp[0],tmp[1],tmp[2]);
        fac_count++;
        fprintf( out_file , "    ENDLOOP\n");
        fprintf( out_file , "  ENDFACET\n");     /*XXXXX*/
      }
    }
  }
}
